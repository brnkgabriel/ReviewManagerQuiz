-- phpMyAdmin SQL Dump
-- version 2.11.11.3
-- http://www.phpmyadmin.net
--
-- Host: 68.178.143.2
-- Generation Time: May 22, 2017 at 04:05 AM
-- Server version: 5.5.43
-- PHP Version: 5.1.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hpmyouths`
--

-- --------------------------------------------------------

--
-- Table structure for table `ayoadewusiscores`
--

CREATE TABLE `ayoadewusiscores` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `exercise` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `source` varchar(200) NOT NULL,
  `score` mediumint(9) NOT NULL,
  `currentage` mediumint(9) NOT NULL,
  `aggregate` varchar(200) NOT NULL,
  `tableName` varchar(50) NOT NULL,
  `currentTotalAggregate` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=44 ;

--
-- Dumping data for table `ayoadewusiscores`
--

INSERT INTO `ayoadewusiscores` VALUES(1, '2016-01-03', 'Eternal Life', 'Review', 'Andrew Wommack', 0, 13, '0.000', 'ayoadewusiscores', '0');
INSERT INTO `ayoadewusiscores` VALUES(2, '2016-01-10', 'Close Encounter of the God Kind', 'Review', 'Jesse Duplantis', 6, 13, '0.462', 'ayoadewusiscores', '0.462');
INSERT INTO `ayoadewusiscores` VALUES(3, '2016-01-31', 'Growing Up Spiritually', 'Review', 'Kenneth E Hagin', 0, 13, '0.000', 'ayoadewusiscores', '0.462');
INSERT INTO `ayoadewusiscores` VALUES(4, '2016-02-07', 'The Cost of a Crown', 'Quiz', 'Bishop David Oyedepo', 0, 13, '0.000', 'ayoadewusiscores', '0.462');
INSERT INTO `ayoadewusiscores` VALUES(5, '2016-02-14', 'The Love Walk', 'Review', 'Kenneth E Hagin', 16, 13, '1.231', 'ayoadewusiscores', '1.693');
INSERT INTO `ayoadewusiscores` VALUES(6, '2016-02-21', 'Opted for Group Discussion', 'Group Discussion', 'Youths', 0, 13, '0.000', 'ayoadewusiscores', '1.693');
INSERT INTO `ayoadewusiscores` VALUES(7, '2016-03-13', 'Repositioning for Exploits', 'Review', 'Bishop David Oyedepo', 0, 13, '0.000', 'ayoadewusiscores', '1.693');
INSERT INTO `ayoadewusiscores` VALUES(8, '2016-03-27', '1John 4:4', 'Synonyms', 'Lanre Ibironke', 31, 13, '2.385', 'ayoadewusiscores', '4.078');
INSERT INTO `ayoadewusiscores` VALUES(9, '2016-04-03', 'Hand Sequence', 'Focus Test', 'Lanre Ibironke', 41, 13, '3.154', 'ayoadewusiscores', '7.232');
INSERT INTO `ayoadewusiscores` VALUES(10, '2016-04-10', 'Yesterday, Today and Tomorrow', 'Annotation and Silence Half Hour', 'Lanre Ibironke', 52, 13, '4.000', 'ayoadewusiscores', '11.232');
INSERT INTO `ayoadewusiscores` VALUES(11, '2016-04-17', 'Your Abilities', 'Annotation & Hand Sequence', 'Lanre Ibironke', 4, 13, '0.308', 'ayoadewusiscores', '11.54');
INSERT INTO `ayoadewusiscores` VALUES(12, '2016-04-27', 'Maximizing Your Most Valuable Asset', 'Home Work', 'Lanre Ibironke', 0, 13, '0.000', 'ayoadewusiscores', '11.54');
INSERT INTO `ayoadewusiscores` VALUES(13, '2016-05-01', 'Character Custodian of Destiny', 'Quiz', 'Bishop David Oyedepo', 0, 13, '0.000', 'ayoadewusiscores', '11.54');
INSERT INTO `ayoadewusiscores` VALUES(14, '2016-05-08', 'The Myth of Singleness', 'Questions', 'Dr Myles Munroe', 0, 13, '0.000', 'ayoadewusiscores', '11.54');
INSERT INTO `ayoadewusiscores` VALUES(15, '2016-05-15', 'Being Still (Psalms 46vs10)', 'Chicken on Egg Scenario', 'Lanre Ibironke', 3, 13, '0.231', 'ayoadewusiscores', '11.771');
INSERT INTO `ayoadewusiscores` VALUES(16, '2016-05-22', 'Selecting the Most Appropriate Word Replacement', 'Quiz', 'Lanre Ibironke', 0, 13, '0.000', 'ayoadewusiscores', '11.771');
INSERT INTO `ayoadewusiscores` VALUES(17, '2016-05-29', 'Personalizing Scripture', 'Theory Question', 'Lanre Ibironke', 0, 13, '0', 'ayoadewusiscores', '11.771');
INSERT INTO `ayoadewusiscores` VALUES(19, '2016-06-05', 'Inner Counsel', 'Annotation', 'Lanre Ibironke', 35, 13, '2.692', 'ayoadewusiscores', '14.463');
INSERT INTO `ayoadewusiscores` VALUES(20, '2016-06-12', 'Bible Questions', 'General Quiz', 'Lanre Ibironke', 0, 13, '0', 'ayoadewusiscores', '14.463');
INSERT INTO `ayoadewusiscores` VALUES(21, '2016-06-19', 'Marathon Question', 'General Quiz 2', 'Lanre Ibironke', 0, 13, '0', 'ayoadewusiscores', '14.463');
INSERT INTO `ayoadewusiscores` VALUES(22, '2016-06-26', 'Uzziah''s Story', 'Annotation', 'Lanre Ibironke', 8, 13, '0.615', 'ayoadewusiscores', '15.078');
INSERT INTO `ayoadewusiscores` VALUES(23, '2016-07-03', 'Multiple Choice', 'General Quiz 3', 'Lanre Ibironke', 0, 13, '0', 'ayoadewusiscores', '15.078');
INSERT INTO `ayoadewusiscores` VALUES(24, '2016-07-10', '4-Cards', 'Bible Game', 'Lanre Ibironke', 45, 14, '3.214', 'ayoadewusiscores', '18.292');
INSERT INTO `ayoadewusiscores` VALUES(25, '2016-07-24', 'Memory Test', 'Theory Questions', 'Lanre Ibironke', 35, 14, '2.5', 'ayoadewusiscores', '20.792');
INSERT INTO `ayoadewusiscores` VALUES(26, '2016-07-31', 'Scripture Expansion', 'Presentation', 'Lanre Ibironke', 15, 14, '1.071', 'ayoadewusiscores', '21.863');
INSERT INTO `ayoadewusiscores` VALUES(27, '2016-08-07', 'Multiple Choice', 'General Quiz 4', 'Lanre Ibironke', 31, 14, '2.214', 'ayoadewusiscores', '24.077');
INSERT INTO `ayoadewusiscores` VALUES(28, '2016-08-14', 'Tower of Hanoi & Marriage', 'Puzzle  & Annotation', 'Lanre Ibironke', 0, 14, '0', 'ayoadewusiscores', '24.077');
INSERT INTO `ayoadewusiscores` VALUES(29, '2016-08-21', 'The Innovative Demands of Leadership', 'Quiz 5', 'Myles Munroe', 14, 14, '1', 'ayoadewusiscores', '25.077');
INSERT INTO `ayoadewusiscores` VALUES(30, '2016-08-28', 'The Best Kept Secret', 'Quiz 6 & Annotation', 'Lanre Ibironke', 39, 14, '2.786', 'ayoadewusiscores', '27.863');
INSERT INTO `ayoadewusiscores` VALUES(31, '2016-09-04', 'Divine Secrets', 'Annotation', 'Lanre Ibironke', 0, 14, '0', 'ayoadewusiscores', '27.863');
INSERT INTO `ayoadewusiscores` VALUES(32, '2016-09-11', 'Repositioning for Exploits', 'Online Quiz', 'Bishop David Oyedepo', 0, 14, '0', 'ayoadewusiscores', '27.863');
INSERT INTO `ayoadewusiscores` VALUES(37, '2016-10-09', 'The Ten Attitudes for Leadership Development', 'Online Quiz', 'Myles Munroe & David Oyedepo', 66, 14, '4.712', 'ayoadewusiscores', '32.575');
INSERT INTO `ayoadewusiscores` VALUES(38, '2016-10-30', 'The Media Mandate of the Kingdom', 'Online Quiz', 'Myles Munroe', 40, 14, '2.856', 'ayoadewusiscores', '35.431');
INSERT INTO `ayoadewusiscores` VALUES(39, '2016-12-11', 'The Stronghold of Faith', 'Online Quiz', 'Bishop David Oyedepo', 60, 14, '4.284', 'ayoadewusiscores', '39.715');
INSERT INTO `ayoadewusiscores` VALUES(40, '2016-12-18', 'How to Deal With Grief 1', 'Online Quiz', 'Andrew Wommack', 188, 14, '13.418', 'ayoadewusiscores', '53.133');
INSERT INTO `ayoadewusiscores` VALUES(41, '2017-01-08', 'Christmas Jubilee and Direction', 'Online Quiz', 'Myles Munroe', 55, 14, '3.927', 'ayoadewusiscores', '57.06');
INSERT INTO `ayoadewusiscores` VALUES(42, '2017-01-22', 'Eternal Life', 'Online Quiz', 'Andrew Wommack', 60, 14, '4.284', 'ayoadewusiscores', '61.344');
INSERT INTO `ayoadewusiscores` VALUES(43, '2017-02-05', 'God''s Kind of Love To You', 'Online Quiz', 'Andrew Wommack', 5, 14, '0.357', 'ayoadewusiscores', '61.701');

-- --------------------------------------------------------

--
-- Table structure for table `boluayodelescores`
--

CREATE TABLE `boluayodelescores` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `exercise` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `source` varchar(200) NOT NULL,
  `score` mediumint(9) NOT NULL,
  `currentage` mediumint(9) NOT NULL,
  `aggregate` varchar(200) NOT NULL,
  `tableName` varchar(50) NOT NULL,
  `currentTotalAggregate` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `boluayodelescores`
--

INSERT INTO `boluayodelescores` VALUES(1, '2017-04-16', 'Joined (DOB Feb 26 2005)', 'Joined', 'Youth Instructor', 348, 12, '29', 'boluayodelescores', '29');
INSERT INTO `boluayodelescores` VALUES(2, '2017-04-28', 'The Last Reformation(30:27-The End)', 'Online Quiz', 'Akatio Films', 153, 12, '12.755', 'boluayodelescores', '41.755');
INSERT INTO `boluayodelescores` VALUES(3, '2017-05-05', 'The Principles of Creation', 'Online Quiz', 'Myles Munroe', 11, 12, '0.917', 'boluayodelescores', '42.672');
INSERT INTO `boluayodelescores` VALUES(4, '2017-05-12', 'Drive Through History Holy Land 1', 'Online Quiz', 'Myles Munroe', 309, 12, '25.749', 'boluayodelescores', '68.421');
INSERT INTO `boluayodelescores` VALUES(5, '2017-05-19', 'The Principles of Creation', 'Online Quiz', 'Myles Munroe', 89, 12, '7.421', 'boluayodelescores', '75.842');

-- --------------------------------------------------------

--
-- Table structure for table `charlesabiolascores`
--

CREATE TABLE `charlesabiolascores` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `exercise` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `source` varchar(200) NOT NULL,
  `score` mediumint(9) NOT NULL,
  `currentage` mediumint(9) NOT NULL,
  `aggregate` varchar(200) NOT NULL,
  `tableName` varchar(50) NOT NULL,
  `currentTotalAggregate` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `charlesabiolascores`
--

INSERT INTO `charlesabiolascores` VALUES(1, '2017-04-16', 'Joined (DOB May 27 2005)', 'Joined', 'Youth Instructor', 319, 11, '29', 'charlesabiolascores', '29');
INSERT INTO `charlesabiolascores` VALUES(2, '2017-05-05', 'The Principles of Creation', 'Online Quiz', 'Myles Munroe', 95, 11, '8.645', 'charlesabiolascores', '37.645');
INSERT INTO `charlesabiolascores` VALUES(3, '2017-05-12', 'Drive Through History Holy Land 1', 'Online Quiz', 'Myles Munroe', 501, 11, '45.591', 'charlesabiolascores', '83.236');
INSERT INTO `charlesabiolascores` VALUES(4, '2017-05-19', 'How to Walk in Confidence', 'Online Quiz', 'Myles Munroe', 667, 11, '60.697', 'charlesabiolascores', '143.933');

-- --------------------------------------------------------

--
-- Table structure for table `davidalamuscores`
--

CREATE TABLE `davidalamuscores` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `exercise` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `source` varchar(200) NOT NULL,
  `score` mediumint(9) NOT NULL,
  `currentage` mediumint(9) NOT NULL,
  `aggregate` varchar(200) NOT NULL,
  `tableName` varchar(50) NOT NULL DEFAULT 'davidalamuscores',
  `currentTotalAggregate` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=47 ;

--
-- Dumping data for table `davidalamuscores`
--

INSERT INTO `davidalamuscores` VALUES(1, '2016-01-03', 'Eternal Life', 'Review', 'Andrew Wommack', 0, 15, '0.000', 'davidalamuscores', '0');
INSERT INTO `davidalamuscores` VALUES(2, '2016-01-10', 'Close Encounter of the God Kind', 'Review', 'Jesse Duplantis', 0, 15, '0.000', 'davidalamuscores', '0');
INSERT INTO `davidalamuscores` VALUES(3, '2016-01-31', 'Growing Up Spiritually', 'Review', 'Kenneth E Hagin', 0, 15, '0.000', 'davidalamuscores', '0');
INSERT INTO `davidalamuscores` VALUES(4, '2016-02-07', 'The Cost of a Crown', 'Quiz', 'Bishop David Oyedepo', 0, 15, '0.000', 'davidalamuscores', '0');
INSERT INTO `davidalamuscores` VALUES(5, '2016-02-14', 'The Love Walk', 'Review', 'Kenneth E Hagin', 0, 15, '0.000', 'davidalamuscores', '0');
INSERT INTO `davidalamuscores` VALUES(6, '2016-02-21', 'Opted for Group Discussion', 'Group Discussion', 'Youth', 0, 15, '0.000', 'davidalamuscores', '0');
INSERT INTO `davidalamuscores` VALUES(7, '2016-03-13', 'Repositioning for Exploits', 'Review', 'Bishop David Oyedepo', 0, 15, '0.000', 'davidalamuscores', '0');
INSERT INTO `davidalamuscores` VALUES(8, '2016-03-27', '1John 4:4', 'Synonyms', 'Lanre Ibironke', 0, 15, '0.000', 'davidalamuscores', '0');
INSERT INTO `davidalamuscores` VALUES(9, '2016-04-03', 'Hand Sequence', 'Focus Test', 'Lanre Ibironke', 0, 15, '0.000', 'davidalamuscores', '0');
INSERT INTO `davidalamuscores` VALUES(10, '2016-04-10', 'Yesterday, Today and Tomorrow', 'Annotation and Silence Half Hour', 'Lanre Ibironke', 0, 15, '0.000', 'davidalamuscores', '0');
INSERT INTO `davidalamuscores` VALUES(11, '2016-04-17', 'Your Abilities', 'Annotation and Hand Sequence', 'Lanre Ibironke', 0, 15, '0.000', 'davidalamuscores', '0');
INSERT INTO `davidalamuscores` VALUES(12, '2016-04-24', 'Maximizing Your Most Valuable Asset', 'Home Work', 'Lanre Ibironke', 0, 15, '0.000', 'davidalamuscores', '0');
INSERT INTO `davidalamuscores` VALUES(13, '2016-05-01', 'Character Custodian of Destiny', 'Quiz', 'Bishop David Oyedepo', 0, 15, '0.000', 'davidalamuscores', '0');
INSERT INTO `davidalamuscores` VALUES(14, '2016-05-08', 'The Myth of Singleness', 'Questions', 'Dr Myles Munroe', 0, 15, '0.000', 'davidalamuscores', '0');
INSERT INTO `davidalamuscores` VALUES(15, '2016-05-15', 'Being Still (Psalms 46vs10)', 'Chicken on Egg Scenario', 'Lanre Ibironke', 9, 15, '0.600', 'davidalamuscores', '0.6');
INSERT INTO `davidalamuscores` VALUES(16, '2016-05-22', 'Selecting the Most Appropriate Word Replacement', 'Quiz', 'Lanre Ibironke', 45, 15, '3.000', 'davidalamuscores', '3.6');
INSERT INTO `davidalamuscores` VALUES(17, '2016-05-29', 'Personalizing Scripture', 'Theory Question', 'Lanre Ibironke', 31, 15, '2.067', 'davidalamuscores', '5.667');
INSERT INTO `davidalamuscores` VALUES(18, '2016-06-05', 'Inner Counsel', 'Annotation', 'Lanre Ibironke', 35, 15, '2.333', 'davidalamuscores', '8');
INSERT INTO `davidalamuscores` VALUES(19, '2016-06-12', 'Bible Questions', 'General Quiz', 'Lanre Ibironke', 0, 15, '0', 'davidalamuscores', '8');
INSERT INTO `davidalamuscores` VALUES(20, '2016-06-19', 'Marathon Question', 'General Quiz 2', 'Lanre Ibironke', 0, 15, '0', 'davidalamuscores', '8');
INSERT INTO `davidalamuscores` VALUES(21, '2016-06-26', 'Uzziah''s Story', 'Annotation', 'Lanre Ibironke', 0, 15, '0', 'davidalamuscores', '8');
INSERT INTO `davidalamuscores` VALUES(22, '2016-07-03', 'Multiple Choice', 'General Quiz 3', 'Lanre Ibironke', 57, 15, '3.8', 'davidalamuscores', '11.8');
INSERT INTO `davidalamuscores` VALUES(23, '2016-07-10', '4-Cards', 'Bible Game', 'Lanre Ibironke', 11, 15, '0.733', 'davidalamuscores', '12.533');
INSERT INTO `davidalamuscores` VALUES(24, '2016-07-24', 'Memory Test', 'Theory Questions', 'Lanre Ibironke', 0, 15, '0', 'davidalamuscores', '12.533');
INSERT INTO `davidalamuscores` VALUES(25, '2016-07-31', 'Scripture Expansion', 'Presentation', 'Lanre Ibironke', 0, 15, '0', 'davidalamuscores', '12.533');
INSERT INTO `davidalamuscores` VALUES(26, '2016-08-07', 'Multiple Choice', 'General Quiz 4', 'Lanre Ibironke', 53, 15, '3.533', 'davidalamuscores', '16.066');
INSERT INTO `davidalamuscores` VALUES(27, '2016-08-14', 'Tower of Hanoi & Marriage', 'Puzzle  & Annotation', 'Lanre Ibironke', 0, 15, '0', 'davidalamuscores', '16.066');
INSERT INTO `davidalamuscores` VALUES(28, '2016-08-21', 'The Innovative Demands of Leadership', 'Quiz 5', 'Myles Munroe', 16, 15, '1.067', 'davidalamuscores', '17.133');
INSERT INTO `davidalamuscores` VALUES(29, '2016-08-28', 'The Best Kept Secret', 'Quiz 6 & Annotation', 'Lanre Ibironke', 14, 15, '0.933', 'davidalamuscores', '18.066');
INSERT INTO `davidalamuscores` VALUES(30, '2016-09-04', 'Divine Secrets', 'Annotation', 'Lanre Ibironke', 30, 15, '2', 'davidalamuscores', '20.066');
INSERT INTO `davidalamuscores` VALUES(31, '2016-09-11', 'Repositioning for Exploits', 'Online Quiz', 'Bishop David Oyedepo', 33, 15, '2.196', 'davidalamuscores', '22.262');
INSERT INTO `davidalamuscores` VALUES(32, '2016-10-02', 'The Encounter', 'Online Quiz', 'Pure Flix Entertainment', 231, 15, '15.405', 'davidalamuscores', '37.667');
INSERT INTO `davidalamuscores` VALUES(33, '2016-10-09', 'The Ten Attitudes for Leadership Development', 'Online Quiz', 'Myles Munroe & David Oyedepo', 395, 15, '26.351', 'davidalamuscores', '64.018');
INSERT INTO `davidalamuscores` VALUES(34, '2016-10-16', 'What is Faith?', 'Online Quiz', 'David Oyedepo', 131, 15, '8.743', 'davidalamuscores', '72.761');
INSERT INTO `davidalamuscores` VALUES(35, '2016-10-30', 'Engaging the Armour of Light for Total Deliverance', 'Online Quiz', 'Bishop David Oyedepo', 128, 15, '8.536', 'davidalamuscores', '81.297');
INSERT INTO `davidalamuscores` VALUES(36, '2016-11-06', 'Vital Keys to Achieving Your Vision', 'Online Quiz', 'Myles Munroe', 397, 15, '26.483', 'davidalamuscores', '107.78');
INSERT INTO `davidalamuscores` VALUES(37, '2016-11-27', 'Engaging Violent Faith for Supernatural Turnaround', 'Online Quiz', 'Bishop David Oyedepo', 249, 15, '16.609', 'davidalamuscores', '124.389');
INSERT INTO `davidalamuscores` VALUES(38, '2017-01-29', 'The Holy Spirit', 'Online Quiz', 'Pastor E.A. Adeboye & Andrew Wommack', 111, 16, '6.963', 'davidalamuscores', '131.352');
INSERT INTO `davidalamuscores` VALUES(39, '2017-02-05', 'God''s Kind of Love To You', 'Online Quiz', 'Andrew Wommack', 381, 16, '23.879', 'davidalamuscores', '155.231');
INSERT INTO `davidalamuscores` VALUES(40, '2017-03-05', 'Spirituality the Master Key to a World of Exploits', 'Online Quiz', 'Bishop David Oyedepo', 408, 16, '25.58', 'davidalamuscores', '180.811');
INSERT INTO `davidalamuscores` VALUES(41, '2017-03-12', 'The Kingdom Power of Self Government', 'Online Quiz', 'Myles Munroe', 198, 16, '12.418', 'davidalamuscores', '193.229');
INSERT INTO `davidalamuscores` VALUES(42, '2017-03-19', 'Life 2', 'Online Quiz', 'Bishop David Oyedepo', 49, 16, '3.073', 'davidalamuscores', '196.302');
INSERT INTO `davidalamuscores` VALUES(43, '2017-03-26', 'Marriage Prep 101', 'Online Quiz', 'Myles Munroe', 7, 16, '0.439', 'davidalamuscores', '196.741');
INSERT INTO `davidalamuscores` VALUES(44, '2017-04-02', 'Salvation Testimony', 'Online Quiz', 'Kenneth Erwin Hagin', 241, 16, '15.101', 'davidalamuscores', '211.842');
INSERT INTO `davidalamuscores` VALUES(45, '2017-04-23', 'The Power of Spiritual Depth', 'Online Quiz', 'Bishop David Oyedepo', 97, 16, '6.073', 'davidalamuscores', '217.915');
INSERT INTO `davidalamuscores` VALUES(46, '2017-04-28', 'The Last Reformation(30:27-The End)', 'Online Quiz', 'Akatio Films', 1, 16, '0.063', 'davidalamuscores', '217.978');

-- --------------------------------------------------------

--
-- Table structure for table `demiladeoladipuposcores`
--

CREATE TABLE `demiladeoladipuposcores` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `exercise` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `source` varchar(200) NOT NULL,
  `score` mediumint(9) NOT NULL,
  `currentage` mediumint(9) NOT NULL,
  `aggregate` varchar(200) NOT NULL,
  `tableName` varchar(50) NOT NULL DEFAULT 'demiladeoladipuposcores',
  `currentTotalAggregate` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=52 ;

--
-- Dumping data for table `demiladeoladipuposcores`
--

INSERT INTO `demiladeoladipuposcores` VALUES(1, '2016-01-03', 'Eternal Life', 'Review', 'Andrew Wommack', 0, 14, '0.000', 'demiladeoladipuposcores', '0');
INSERT INTO `demiladeoladipuposcores` VALUES(2, '2016-01-10', 'Close Encounter of the God Kind', 'Review', 'Jesse Duplantis', 10, 14, '0.714', 'demiladeoladipuposcores', '0.714');
INSERT INTO `demiladeoladipuposcores` VALUES(3, '2016-01-31', 'Growing Up Spiritually', 'Review', 'Kenneth E Hagin', 0, 14, '0.000', 'demiladeoladipuposcores', '0.714');
INSERT INTO `demiladeoladipuposcores` VALUES(4, '2016-02-07', 'The Cost of a Crown', 'Quiz', 'Bishop David Oyedepo', 0, 14, '0.000', 'demiladeoladipuposcores', '0.714');
INSERT INTO `demiladeoladipuposcores` VALUES(5, '2016-02-14', 'The Love Walk', 'Review', 'Kenneth E Hagin', 0, 14, '0.000', 'demiladeoladipuposcores', '0.714');
INSERT INTO `demiladeoladipuposcores` VALUES(6, '2016-02-21', 'Opted for Group Discussion', 'Group Discussion', 'Youths', 0, 14, '0.000', 'demiladeoladipuposcores', '0.714');
INSERT INTO `demiladeoladipuposcores` VALUES(7, '2016-03-13', 'Repositioning for Exploits', 'Review', 'Bishop David Oyedepo', 17, 14, '1.214', 'demiladeoladipuposcores', '1.928');
INSERT INTO `demiladeoladipuposcores` VALUES(8, '2016-03-27', '1John 4:4', 'Synonyms', 'Lanre Ibironke', 0, 14, '0.000', 'demiladeoladipuposcores', '1.928');
INSERT INTO `demiladeoladipuposcores` VALUES(9, '2016-04-03', 'Hand Sequence ', 'Focus Test', 'Lanre Ibironke', 0, 14, '0.000', 'demiladeoladipuposcores', '1.928');
INSERT INTO `demiladeoladipuposcores` VALUES(10, '2016-04-10', 'Yesterday, Today and Tomorrow', 'Annotation and Silence Half Hour', 'Lanre Ibironke', 71, 14, '5.071', 'demiladeoladipuposcores', '6.999');
INSERT INTO `demiladeoladipuposcores` VALUES(11, '2016-04-17', 'Your Abilities', 'Annotation and Hand Sequence', 'Lanre Ibironke', 60, 14, '4.286', 'demiladeoladipuposcores', '11.285');
INSERT INTO `demiladeoladipuposcores` VALUES(12, '2016-04-24', 'Maximizing Your Most Valuable Asset', 'Home Work', 'Lanre Ibironke', 0, 14, '0.000', 'demiladeoladipuposcores', '11.285');
INSERT INTO `demiladeoladipuposcores` VALUES(13, '2016-05-01', 'Character Custodian of Destiny', 'Quiz', 'Bishop David Oyedepo', 0, 14, '0.000', 'demiladeoladipuposcores', '11.285');
INSERT INTO `demiladeoladipuposcores` VALUES(14, '2016-05-08', 'The Myth of Singleness', 'Question', 'Dr Myles Munroe', 0, 14, '0.000', 'demiladeoladipuposcores', '11.285');
INSERT INTO `demiladeoladipuposcores` VALUES(15, '2016-05-15', 'Being Still (Psalms 46vs10)', 'Chicken on Egg Scenario', 'Lanre Ibironke', 0, 14, '0.000', 'demiladeoladipuposcores', '11.285');
INSERT INTO `demiladeoladipuposcores` VALUES(16, '2016-05-22', 'Selecting the Most Appropriate Word Replacement', 'Quiz', 'Lanre Ibironke', 0, 14, '0.000', 'demiladeoladipuposcores', '11.285');
INSERT INTO `demiladeoladipuposcores` VALUES(17, '2016-05-29', 'Personalizing Scripture', 'Theory Question', 'Lanre Ibironke', 0, 14, '0', 'demiladeoladipuposcores', '11.285');
INSERT INTO `demiladeoladipuposcores` VALUES(18, '2016-06-05', 'Inner Counsel', 'Annotation', 'Lanre Ibironke', 35, 14, '2.5', 'demiladeoladipuposcores', '13.785');
INSERT INTO `demiladeoladipuposcores` VALUES(19, '2016-06-12', 'Bible Questions', 'General Quiz', 'Lanre ibironke', 51, 14, '3.643', 'demiladeoladipuposcores', '17.428');
INSERT INTO `demiladeoladipuposcores` VALUES(20, '2016-06-19', 'Marathon Question', 'Quiz 3', 'Lanre Ibironke', 112, 14, '8', 'demiladeoladipuposcores', '25.428');
INSERT INTO `demiladeoladipuposcores` VALUES(21, '2016-06-26', 'Uzziah''s Story', 'Annotation', 'Lanre Ibironke', 10, 15, '0.667', 'demiladeoladipuposcores', '26.095');
INSERT INTO `demiladeoladipuposcores` VALUES(22, '2016-07-03', 'Multiple Choice', 'General Quiz 3', 'Lanre Ibironke', 0, 15, '0', 'demiladeoladipuposcores', '26.095');
INSERT INTO `demiladeoladipuposcores` VALUES(23, '2016-07-10', '4-Cards', 'Bible Game', 'Lanre Ibironke', 0, 15, '0', 'demiladeoladipuposcores', '26.095');
INSERT INTO `demiladeoladipuposcores` VALUES(24, '2016-07-24', 'Memory Test', 'Theory Questions', 'Lanre Ibironke', 0, 15, '0', 'demiladeoladipuposcores', '26.095');
INSERT INTO `demiladeoladipuposcores` VALUES(25, '2016-07-31', 'Scripture Expansion', 'Presentation', 'Lanre Ibironke', 0, 15, '0', 'demiladeoladipuposcores', '26.095');
INSERT INTO `demiladeoladipuposcores` VALUES(26, '2016-08-07', 'Multiple Choice', 'General Quiz 4', 'Lanre Ibironke', 0, 15, '0', 'demiladeoladipuposcores', '26.095');
INSERT INTO `demiladeoladipuposcores` VALUES(27, '2016-08-14', 'Tower of Hanoi & Marriage', 'Puzzle  & Annotation', 'Lanre Ibironke', 80, 15, '5.333', 'demiladeoladipuposcores', '31.428');
INSERT INTO `demiladeoladipuposcores` VALUES(28, '2016-08-21', 'The Innovative Demands of Leadership', 'Quiz 5', 'Myles Munroe', 54, 15, '3.6', 'demiladeoladipuposcores', '35.028');
INSERT INTO `demiladeoladipuposcores` VALUES(29, '2016-08-28', 'The Best Kept Secret', 'Quiz 6 & Annotation', 'Lanre Ibironke', 70, 15, '4.667', 'demiladeoladipuposcores', '39.695');
INSERT INTO `demiladeoladipuposcores` VALUES(30, '2016-09-04', 'Divine Secrets', 'Annotation', 'Lanre Ibironke', 68, 15, '4.533', 'demiladeoladipuposcores', '44.228');
INSERT INTO `demiladeoladipuposcores` VALUES(31, '2016-09-11', 'Repositioning for Exploits', 'Online Quiz', 'Bishop David Oyedepo', 462, 15, '30.766', 'demiladeoladipuposcores', '74.994');
INSERT INTO `demiladeoladipuposcores` VALUES(32, '2016-09-18', 'Kingdom Keys to Successful Relationships', 'Online Quiz', 'Myles Munroe', 489, 15, '32.566', 'demiladeoladipuposcores', '107.56');
INSERT INTO `demiladeoladipuposcores` VALUES(33, '2016-10-02', 'The Encounter', 'Online Quiz', 'Pure Flix Entertainment', 257, 15, '17.127', 'demiladeoladipuposcores', '124.687');
INSERT INTO `demiladeoladipuposcores` VALUES(35, '2016-10-16', 'What is Faith?', 'Online Quiz', 'David Oyedepo', 67, 15, '4.469', 'demiladeoladipuposcores', '129.156');
INSERT INTO `demiladeoladipuposcores` VALUES(36, '2016-11-06', 'Vital Keys to Achieving Your Vision', 'Online Quiz', 'Myles Munroe', 113, 15, '7.531', 'demiladeoladipuposcores', '136.687');
INSERT INTO `demiladeoladipuposcores` VALUES(37, '2016-11-13', 'Engaging Violent Faith for Supernatural Turnaround', 'Online Quiz', 'Bishop David Oyedepo', 152, 15, '10.132', 'demiladeoladipuposcores', '146.819');
INSERT INTO `demiladeoladipuposcores` VALUES(38, '2016-12-18', 'How to Deal With Grief 1', 'Online Quiz', 'Andrew Wommack', 133, 15, '8.865', 'demiladeoladipuposcores', '155.684');
INSERT INTO `demiladeoladipuposcores` VALUES(39, '2016-12-25', 'How to Deal with Grief 2/4', 'Online Quiz', 'Andrew Wommack', 80, 15, '5.334', 'demiladeoladipuposcores', '161.018');
INSERT INTO `demiladeoladipuposcores` VALUES(40, '2017-01-01', 'The Life and Power of Words', 'Online Quiz', 'Charles Capps', 447, 15, '29.773', 'demiladeoladipuposcores', '190.791');
INSERT INTO `demiladeoladipuposcores` VALUES(41, '2017-02-05', 'God''s Kind of Love to You', 'Online Quiz', 'Andrew Wommack', 253, 15, '16.863', 'demiladeoladipuposcores', '207.654');
INSERT INTO `demiladeoladipuposcores` VALUES(42, '2017-02-26', 'Ultimate Myles Munroe 2016 Collection', 'Online Quiz', 'Myles Munroe', 761, 15, '50.725', 'demiladeoladipuposcores', '258.379');
INSERT INTO `demiladeoladipuposcores` VALUES(43, '2017-03-05', 'Spirituality the Master Key to a World of Exploits', 'Online Quiz', 'Bishop David Oyedepo', 102, 15, '6.8', 'demiladeoladipuposcores', '265.179');
INSERT INTO `demiladeoladipuposcores` VALUES(44, '2017-03-19', 'Life 2', 'Online Quiz', 'Bishop David Oyedepo', 718, 15, '47.822', 'demiladeoladipuposcores', '313.001');
INSERT INTO `demiladeoladipuposcores` VALUES(45, '2017-04-02', 'Salvation Testimony', 'Online Quiz', 'Kenneth Erwin Hagin', 802, 15, '53.416', 'demiladeoladipuposcores', '366.417');
INSERT INTO `demiladeoladipuposcores` VALUES(46, '2017-04-09', 'God\\''s Love (Love Series 3)', 'Online Quiz', 'Andrew Wommack', 451, 15, '30.333', 'demiladeoladipuposcores', '396.75');
INSERT INTO `demiladeoladipuposcores` VALUES(47, '2017-04-16', 'The Last Reformation 1(0:00-30:27)', 'Online Quiz', 'Akatio Films', 217, 15, '14.453', 'demiladeoladipuposcores', '411.203');
INSERT INTO `demiladeoladipuposcores` VALUES(48, '2017-04-23', 'The Power of Spiritual Depth', 'Online Quiz', 'Bishop David Oyedepo', 288, 15, '19.182', 'demiladeoladipuposcores', '430.385');
INSERT INTO `demiladeoladipuposcores` VALUES(49, '2017-04-28', 'The Last Reformation(30:27-The End)', 'Online Quiz', 'Akatio Films', 1641, 15, '109.303', 'demiladeoladipuposcores', '539.688');
INSERT INTO `demiladeoladipuposcores` VALUES(50, '2017-05-12', 'Drive Through History Holy Land 1', 'Online Quiz', 'Myles Munroe', 951, 15, '63.369', 'demiladeoladipuposcores', '603.057');
INSERT INTO `demiladeoladipuposcores` VALUES(51, '2017-05-19', 'How to Walk in Confidence', 'Online Quiz', 'Myles Munroe', 436, 15, '29.04', 'demiladeoladipuposcores', '632.097');

-- --------------------------------------------------------

--
-- Table structure for table `desolaoladipuposcores`
--

CREATE TABLE `desolaoladipuposcores` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `exercise` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `source` varchar(200) NOT NULL,
  `score` mediumint(9) NOT NULL,
  `currentage` mediumint(9) NOT NULL,
  `aggregate` varchar(200) NOT NULL,
  `tableName` varchar(50) NOT NULL DEFAULT 'desolaoladipuposcores',
  `currentTotalAggregate` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=72 ;

--
-- Dumping data for table `desolaoladipuposcores`
--

INSERT INTO `desolaoladipuposcores` VALUES(1, '2016-01-03', 'Eternal Life', 'Review', 'Andrew Wommack', 0, 16, '0.000', 'desolaoladipuposcores', '0');
INSERT INTO `desolaoladipuposcores` VALUES(2, '2016-01-10', 'Close Encounter of the God Kind', 'Review', 'Jesse Duplantis', 9, 16, '0.563', 'desolaoladipuposcores', '0.563');
INSERT INTO `desolaoladipuposcores` VALUES(3, '2016-01-31', 'Growing Up Spiritually', 'Review', 'Kenneth E Hagin', 0, 16, '0.000', 'desolaoladipuposcores', '0.563');
INSERT INTO `desolaoladipuposcores` VALUES(4, '2016-02-07', 'The Cost of a Crown', 'Quiz', 'Bishop David Oyedepo', 0, 16, '0.000', 'desolaoladipuposcores', '0.563');
INSERT INTO `desolaoladipuposcores` VALUES(5, '2016-02-14', 'The Love Walk', 'Review', 'Kenneth E Hagin', 0, 16, '0.000', 'desolaoladipuposcores', '0.563');
INSERT INTO `desolaoladipuposcores` VALUES(6, '2016-02-21', 'Opted for Group Discussion', 'Group Discussion', 'Youths', 0, 16, '0.000', 'desolaoladipuposcores', '0.563');
INSERT INTO `desolaoladipuposcores` VALUES(7, '2016-03-13', 'Repositioning for Exploits', 'Review', 'Bishop David Oyedepo', 21, 16, '1.313', 'desolaoladipuposcores', '1.876');
INSERT INTO `desolaoladipuposcores` VALUES(8, '2016-03-27', '1John 4:4', 'Synonyms', 'Lanre Ibironke', 0, 16, '0.000', 'desolaoladipuposcores', '1.876');
INSERT INTO `desolaoladipuposcores` VALUES(9, '2016-04-03', 'Hand Sequence', 'Focus Test', 'Lanre Ibironke', 0, 16, '0.000', 'desolaoladipuposcores', '1.876');
INSERT INTO `desolaoladipuposcores` VALUES(10, '2016-04-10', 'Yesterday, Today and Tomorrow', 'Annotation and Silence Half Hour', 'Lanre Ibironke', 90, 16, '5.625', 'desolaoladipuposcores', '7.501');
INSERT INTO `desolaoladipuposcores` VALUES(11, '2016-04-17', 'Your Abilities', 'Annotation & Hand Sequence', 'Lanre Ibironke', 107, 16, '6.688', 'desolaoladipuposcores', '14.189');
INSERT INTO `desolaoladipuposcores` VALUES(12, '2016-04-24', 'Maximizing Your Most Valuable Asset', 'Home Work', 'Lanre Ibironke', 31, 16, '1.938', 'desolaoladipuposcores', '16.127');
INSERT INTO `desolaoladipuposcores` VALUES(13, '2016-05-01', 'Character Custodian of Destiny', 'Quiz', 'Bishop David Oyedepo', 0, 16, '0.000', 'desolaoladipuposcores', '16.127');
INSERT INTO `desolaoladipuposcores` VALUES(14, '2016-05-08', 'The Myth of Singleness', 'Question', 'Dr Myles Munroe', 0, 16, '0.000', 'desolaoladipuposcores', '16.127');
INSERT INTO `desolaoladipuposcores` VALUES(15, '2016-05-15', 'Being Still (Psalms 46vs10)', 'Chicken on Egg Scenario', 'Lanre Ibironke', 0, 16, '0.000', 'desolaoladipuposcores', '16.127');
INSERT INTO `desolaoladipuposcores` VALUES(16, '2016-05-22', 'Selecting the Most Appropriate Word Replacement', 'Quiz', 'Lanre Ibironke', 0, 16, '0.000', 'desolaoladipuposcores', '16.127');
INSERT INTO `desolaoladipuposcores` VALUES(17, '2016-05-29', 'Personalizing Scripture', 'Theory Question', 'Lanre Ibironke', 0, 16, '0', 'desolaoladipuposcores', '16.127');
INSERT INTO `desolaoladipuposcores` VALUES(18, '2016-06-05', 'Inner Counsel', 'Annotation', 'Lanre Ibironke', 55, 16, '3.438', 'desolaoladipuposcores', '19.565');
INSERT INTO `desolaoladipuposcores` VALUES(19, '2016-06-12', 'Bible Questions', 'General Quiz', 'Lanre Ibironke', 39, 16, '2.438', 'desolaoladipuposcores', '22.003');
INSERT INTO `desolaoladipuposcores` VALUES(20, '2016-06-19', 'Marathon Question', 'General Quiz 2', 'Lanre Ibironke', 156, 16, '9.75', 'desolaoladipuposcores', '31.753');
INSERT INTO `desolaoladipuposcores` VALUES(21, '2016-06-26', 'Uzziah''s Story', 'Annotation', 'Lanre Ibironke', 34, 16, '2.125', 'desolaoladipuposcores', '33.878');
INSERT INTO `desolaoladipuposcores` VALUES(22, '2016-07-03', 'Multiple Choice', 'General Quiz 3', 'Lanre Ibironke', 0, 16, '0', 'desolaoladipuposcores', '33.878');
INSERT INTO `desolaoladipuposcores` VALUES(23, '2016-07-10', '4-Cards', 'Bible Game', 'Lanre Ibironke', 0, 16, '0', 'desolaoladipuposcores', '33.878');
INSERT INTO `desolaoladipuposcores` VALUES(24, '2016-07-24', 'Memory Test', 'Theory Questions', 'Lanre Ibironke', 0, 16, '0', 'desolaoladipuposcores', '33.878');
INSERT INTO `desolaoladipuposcores` VALUES(25, '2016-07-31', 'Scripture Expansion', 'Presentation', 'Lanre Ibironke', 0, 16, '0', 'desolaoladipuposcores', '33.878');
INSERT INTO `desolaoladipuposcores` VALUES(26, '2016-08-07', 'Multiple Choice', 'General Quiz 4', 'Lanre Ibironke', 0, 16, '0', 'desolaoladipuposcores', '33.878');
INSERT INTO `desolaoladipuposcores` VALUES(27, '2016-08-14', 'Tower of Hanoi & Marriage', 'Puzzle  & Annotation', 'Lanre Ibironke', 59, 16, '3.688', 'desolaoladipuposcores', '37.566');
INSERT INTO `desolaoladipuposcores` VALUES(28, '2016-08-21', 'The Innovative Demands of Leadership', 'Quiz 5', 'Myles Munroe', 77, 16, '4.813', 'desolaoladipuposcores', '42.379');
INSERT INTO `desolaoladipuposcores` VALUES(29, '2016-08-28', 'The Best Kept Secret', 'Quiz 6 & Annotation', 'Lanre Ibironke', 115, 17, '6.765', 'desolaoladipuposcores', '49.144');
INSERT INTO `desolaoladipuposcores` VALUES(30, '2016-09-04', 'Divine Secrets', 'Annotation', 'Lanre Ibironke', 65, 17, '3.824', 'desolaoladipuposcores', '52.967999999999996');
INSERT INTO `desolaoladipuposcores` VALUES(33, '2016-09-11', 'Repositioning for Exploits', 'Online Quiz', 'Bishop David Oyedepo', 495, 17, '29.108', 'desolaoladipuposcores', '82.076');
INSERT INTO `desolaoladipuposcores` VALUES(34, '2016-09-18', 'Kingdom Keys to Successful Relationships', 'Online Quiz', 'Myles Munroe', 480, 17, '28.228', 'desolaoladipuposcores', '110.304');
INSERT INTO `desolaoladipuposcores` VALUES(35, '2016-09-25', 'Heralding the Emergence of World Changers', 'Online Quiz', 'Bishop David Oyedepo', 1048, 17, '61.627', 'desolaoladipuposcores', '171.931');
INSERT INTO `desolaoladipuposcores` VALUES(36, '2016-10-02', 'The Encounter', 'Online Quiz', 'Pure Flix Entertainment', 367, 17, '21.583', 'desolaoladipuposcores', '193.514');
INSERT INTO `desolaoladipuposcores` VALUES(37, '2016-10-09', 'The Ten Attitudes for Leadership Development', 'Online Quiz', 'Myles Munroe & David Oyedepo', 725, 17, '42.637', 'desolaoladipuposcores', '236.151');
INSERT INTO `desolaoladipuposcores` VALUES(38, '2016-10-16', 'What is Faith?', 'Online Quiz', 'David Oyedepo', 309, 17, '18.171', 'desolaoladipuposcores', '254.322');
INSERT INTO `desolaoladipuposcores` VALUES(39, '2016-10-23', 'The Media Mandate of the Kingdom', 'Online Quiz', 'Myles Munroe', 525, 17, '30.876', 'desolaoladipuposcores', '285.198');
INSERT INTO `desolaoladipuposcores` VALUES(40, '2016-10-30', 'Engaging the Armour of Light for Total Deliverance', 'Online Quiz', 'David Oyedepo', 495, 17, '29.112', 'desolaoladipuposcores', '314.31');
INSERT INTO `desolaoladipuposcores` VALUES(41, '2016-11-07', 'Vital Keys to Achieving Your Vision', 'Online Quiz', 'Myles Munroe', 39, 17, '2.295', 'desolaoladipuposcores', '316.605');
INSERT INTO `desolaoladipuposcores` VALUES(42, '2016-11-13', 'Engaging Violent Faith for Supernatural Turnaround', 'Online Quiz', 'Bishop David Oyedepo', 504, 17, '29.648', 'desolaoladipuposcores', '346.253');
INSERT INTO `desolaoladipuposcores` VALUES(43, '2016-11-20', 'The Source of the Leadership Spirit', 'Online Quiz', 'Myles Munroe', 415, 17, '24.414', 'desolaoladipuposcores', '370.667');
INSERT INTO `desolaoladipuposcores` VALUES(45, '2016-11-27', 'How to Excel in Your Field', 'Online Quiz', 'Bishop David Oyedepo', 473, 17, '27.814', 'desolaoladipuposcores', '398.481');
INSERT INTO `desolaoladipuposcores` VALUES(46, '2016-12-11', 'The Stronghold of Faith', 'Online Quiz', 'Bishop David Oyedepo', 800, 17, '47.045', 'desolaoladipuposcores', '445.526');
INSERT INTO `desolaoladipuposcores` VALUES(47, '2016-12-18', 'How to Deal With Grief 1', 'Online Quiz', 'Andrew Wommack', 424, 17, '24.934', 'desolaoladipuposcores', '470.46');
INSERT INTO `desolaoladipuposcores` VALUES(48, '2016-12-25', 'How to Deal with Grief 2/4', 'Online Quiz', 'Andrew Wommack', 446, 17, '26.232', 'desolaoladipuposcores', '496.692');
INSERT INTO `desolaoladipuposcores` VALUES(49, '2017-01-01', 'The Life and Power of Words', 'Online Quiz', 'Charles Capps', 435, 17, '25.58', 'desolaoladipuposcores', '522.272');
INSERT INTO `desolaoladipuposcores` VALUES(50, '2017-01-08', 'Christmas Jubilee and Direction', 'Online Quiz', 'Myles Munroe', 599, 17, '35.227', 'desolaoladipuposcores', '557.499');
INSERT INTO `desolaoladipuposcores` VALUES(51, '2017-01-15', 'Life', 'Online Quiz', 'David Oyedepo', 55, 17, '3.234', 'desolaoladipuposcores', '560.733');
INSERT INTO `desolaoladipuposcores` VALUES(52, '2017-01-22', 'Eternal Life', 'Online Quiz', 'Andrew Wommack', 443, 17, '26.053', 'desolaoladipuposcores', '586.786');
INSERT INTO `desolaoladipuposcores` VALUES(53, '2017-01-29', 'The Holy Spirit', 'Online Quiz', 'Pastor Adeboye & Andrew Wommack', 294, 17, '17.297', 'desolaoladipuposcores', '604.083');
INSERT INTO `desolaoladipuposcores` VALUES(54, '2017-02-05', 'God''s Kind of Love to You', 'Online Quiz', 'Andrew Wommack', 364, 17, '21.417', 'desolaoladipuposcores', '625.5');
INSERT INTO `desolaoladipuposcores` VALUES(55, '2017-02-12', '7 Mistakes to avoid before marriage & End of the Harvest', 'Online Quiz', 'Pastor E.A. Adeboye & Christiano Film Group', 341, 17, '20.054', 'desolaoladipuposcores', '645.554');
INSERT INTO `desolaoladipuposcores` VALUES(56, '2017-02-19', 'Deepening your Relationship with God & 3 Types of Friends', 'Online Quiz', 'TD Jakes', 330, 17, '19.413', 'desolaoladipuposcores', '664.967');
INSERT INTO `desolaoladipuposcores` VALUES(57, '2017-02-26', 'Ultimate Myles Munroe 2016 Collection', 'Online Quiz', 'Myles Munroe', 741, 17, '43.593', 'desolaoladipuposcores', '708.56');
INSERT INTO `desolaoladipuposcores` VALUES(58, '2017-03-05', 'Spirituality the Master Key to a World of Exploits', 'Online Quiz', 'Bishop David Oyedepo', 90, 17, '5.292', 'desolaoladipuposcores', '713.852');
INSERT INTO `desolaoladipuposcores` VALUES(59, '2017-03-12', 'The Kingdom Power of Self Government', 'Online Quiz', 'Myles Munroe', 884, 17, '51.98', 'desolaoladipuposcores', '765.832');
INSERT INTO `desolaoladipuposcores` VALUES(60, '2017-03-19', 'Life 2', 'Online Quiz', 'Bishop David Oyedepo', 714, 17, '41.985', 'desolaoladipuposcores', '807.817');
INSERT INTO `desolaoladipuposcores` VALUES(61, '2017-03-26', 'Marriage Prep 101', 'Online Quiz', 'Myles Munroe', 1130, 17, '66.445', 'desolaoladipuposcores', '874.262');
INSERT INTO `desolaoladipuposcores` VALUES(62, '2017-04-02', 'Salvation Testimony', 'Online Quiz', 'Kenneth Erwin Hagin', 814, 17, '47.873', 'desolaoladipuposcores', '922.135');
INSERT INTO `desolaoladipuposcores` VALUES(63, '2017-04-09', 'God\\''s Love (Love Series 3)', 'Online Quiz', 'Andrew Wommack', 1426, 17, '83.854', 'desolaoladipuposcores', '1005.989');
INSERT INTO `desolaoladipuposcores` VALUES(64, '2017-04-16', 'The Last Reformation 1(0:00-30:27)', 'Online Quiz', 'Akatio Films', 1043, 17, '61.329', 'desolaoladipuposcores', '1067.318');
INSERT INTO `desolaoladipuposcores` VALUES(66, '2017-04-22', 'The Power of Spiritual Depth', 'Online Quiz', 'Bishop David Oyedepo', 2043, 17, '120.13', 'desolaoladipuposcores', '1187.448');
INSERT INTO `desolaoladipuposcores` VALUES(68, '2017-04-28', 'The Last Reformation(30:27-The End)', 'Online Quiz', 'Akatio Films', 1741, 17, '102.412', 'desolaoladipuposcores', '1289.86');
INSERT INTO `desolaoladipuposcores` VALUES(69, '2017-05-05', 'The Principles of Creation', 'Online Quiz', 'Myles Munroe', 995, 17, '58.512', 'desolaoladipuposcores', '1348.372');
INSERT INTO `desolaoladipuposcores` VALUES(70, '2017-05-12', 'Drive Through History Holy Land 1', 'Online Quiz', 'Myles Munroe', 926, 17, '54.473', 'desolaoladipuposcores', '1402.845');
INSERT INTO `desolaoladipuposcores` VALUES(71, '2017-05-19', 'How to Walk in Confidence', 'Online Quiz', 'Myles Munroe', 931, 17, '54.75', 'desolaoladipuposcores', '1457.595');

-- --------------------------------------------------------

--
-- Table structure for table `ebubechukwuigwegbescores`
--

CREATE TABLE `ebubechukwuigwegbescores` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `exercise` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `source` varchar(200) NOT NULL,
  `score` mediumint(9) NOT NULL,
  `currentage` mediumint(9) NOT NULL,
  `aggregate` varchar(200) NOT NULL,
  `tableName` varchar(50) NOT NULL DEFAULT 'ebubechukwuigwegbescores',
  `currentTotalAggregate` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=41 ;

--
-- Dumping data for table `ebubechukwuigwegbescores`
--

INSERT INTO `ebubechukwuigwegbescores` VALUES(1, '2016-01-03', 'Eternal Life', 'Review', 'Andrew Wommack', 0, 12, '0.000', 'ebubechukwuigwegbescores', '0');
INSERT INTO `ebubechukwuigwegbescores` VALUES(2, '2016-01-10', 'Close Encounter of the God Kind', 'Review', 'Jesse Duplantis', 0, 12, '0.000', 'ebubechukwuigwegbescores', '0');
INSERT INTO `ebubechukwuigwegbescores` VALUES(3, '2016-01-31', 'Growing Up Spiritually', 'Review', 'Kenneth E Hagin', 0, 12, '0.000', 'ebubechukwuigwegbescores', '0');
INSERT INTO `ebubechukwuigwegbescores` VALUES(4, '2016-02-07', 'The Cost of a Crown', 'Quiz', 'Bishop David Oyedepo', 0, 13, '0.000', 'ebubechukwuigwegbescores', '0');
INSERT INTO `ebubechukwuigwegbescores` VALUES(5, '2016-02-14', 'The Love Walk', 'Review', 'Kenneth E Hagin', 0, 13, '0.000', 'ebubechukwuigwegbescores', '0');
INSERT INTO `ebubechukwuigwegbescores` VALUES(6, '2016-02-21', 'Opted for Group Discussion', 'Group Discussion', 'Youths', 0, 13, '0.000', 'ebubechukwuigwegbescores', '0');
INSERT INTO `ebubechukwuigwegbescores` VALUES(7, '2016-03-13', 'Repositioning for Exploits', 'Review', 'Bishop David Oyedepo', 0, 13, '0.000', 'ebubechukwuigwegbescores', '0');
INSERT INTO `ebubechukwuigwegbescores` VALUES(8, '2016-03-27', '1John 4:4', 'Synonyms', 'Lanre Ibironke', 0, 13, '0.000', 'ebubechukwuigwegbescores', '0');
INSERT INTO `ebubechukwuigwegbescores` VALUES(9, '2016-04-03', 'Hand Sequence', 'Focus Test', 'Lanre Ibironke', 18, 13, '1.385', 'ebubechukwuigwegbescores', '1.385');
INSERT INTO `ebubechukwuigwegbescores` VALUES(10, '2016-04-10', 'Yesterday, Today and Tomorrow', 'Annotation and Silence Half Hour', 'Lanre Ibironke', 0, 13, '0.000', 'ebubechukwuigwegbescores', '1.385');
INSERT INTO `ebubechukwuigwegbescores` VALUES(11, '2016-04-17', 'Your Abilities', 'Annotation and Hand Sequence', 'Lanre Ibironke', 0, 13, '0.000', 'ebubechukwuigwegbescores', '1.385');
INSERT INTO `ebubechukwuigwegbescores` VALUES(12, '2016-04-24', 'Maximizing Your Most Valuable Asset', 'Home Work', 'Lanre Ibironke', 0, 13, '0.000', 'ebubechukwuigwegbescores', '1.385');
INSERT INTO `ebubechukwuigwegbescores` VALUES(13, '2016-05-01', 'Character, Custodian of Destiny', 'Quiz', 'Bishop David Oyedepo', 0, 13, '0.000', 'ebubechukwuigwegbescores', '1.385');
INSERT INTO `ebubechukwuigwegbescores` VALUES(14, '2016-05-08', 'The Myth of Singleness', 'Questions', 'Myles Munroe', 0, 13, '0.000', 'ebubechukwuigwegbescores', '1.385');
INSERT INTO `ebubechukwuigwegbescores` VALUES(15, '2016-05-15', 'Being Still (Psalms 46vs10)', 'Chicken on Egg Scenario', 'Lanre Ibironke', 0, 13, '0.000', 'ebubechukwuigwegbescores', '1.385');
INSERT INTO `ebubechukwuigwegbescores` VALUES(16, '2016-05-22', 'Selecting the Most Appropriate Word Replacement', 'Quiz', 'Lanre Ibironke', 0, 13, '0.000', 'ebubechukwuigwegbescores', '1.385');
INSERT INTO `ebubechukwuigwegbescores` VALUES(17, '2016-05-29', 'Personalizing Scripture', 'Theory Question', 'Lanre Ibironke', 0, 13, '0', 'ebubechukwuigwegbescores', '1.385');
INSERT INTO `ebubechukwuigwegbescores` VALUES(18, '2016-06-05', 'Inner Counsel', 'Annotation', 'Lanre Ibironke', 0, 13, '0', 'ebubechukwuigwegbescores', '1.385');
INSERT INTO `ebubechukwuigwegbescores` VALUES(19, '2016-06-12', 'Bible Questions', 'General Quiz', 'Lanre Ibironke', 0, 13, '0', 'ebubechukwuigwegbescores', '1.385');
INSERT INTO `ebubechukwuigwegbescores` VALUES(20, '2016-06-19', 'Marathon Question', 'General Quiz 2', 'Lanre Ibironke', 0, 13, '0', 'ebubechukwuigwegbescores', '1.385');
INSERT INTO `ebubechukwuigwegbescores` VALUES(21, '2016-06-26', 'Uzziah''s Story', 'Annotation', 'Lanre Ibironke', 0, 13, '0', 'ebubechukwuigwegbescores', '1.385');
INSERT INTO `ebubechukwuigwegbescores` VALUES(22, '2016-07-03', 'Multiple Choice', 'General Quiz 3', 'Lanre Ibironke', 0, 13, '0', 'ebubechukwuigwegbescores', '1.385');
INSERT INTO `ebubechukwuigwegbescores` VALUES(23, '2016-07-10', '4-Cards', 'Bible Game', 'Lanre Ibironke', 0, 13, '0', 'ebubechukwuigwegbescores', '1.385');
INSERT INTO `ebubechukwuigwegbescores` VALUES(24, '2016-07-24', 'Memory Test', 'Theory Questions', 'Lanre Ibironke', 0, 13, '0', 'ebubechukwuigwegbescores', '1.385');
INSERT INTO `ebubechukwuigwegbescores` VALUES(25, '2016-07-31', 'Scripture Expansion', 'Presentation', 'Lanre Ibironke', 0, 13, '0', 'ebubechukwuigwegbescores', '1.385');
INSERT INTO `ebubechukwuigwegbescores` VALUES(26, '2016-08-07', 'Multiple Choice', 'General Quiz 4', 'Lanre Ibironke', 0, 13, '0', 'ebubechukwuigwegbescores', '1.385');
INSERT INTO `ebubechukwuigwegbescores` VALUES(27, '2016-08-14', 'Tower of Hanoi & Marriage', 'Puzzle  & Annotation', 'Lanre Ibironke', 0, 13, '0', 'ebubechukwuigwegbescores', '1.385');
INSERT INTO `ebubechukwuigwegbescores` VALUES(28, '2016-08-21', 'The Innovative Demands of Leadership', 'Quiz 5', 'Myles Munroe', 0, 13, '0', 'ebubechukwuigwegbescores', '1.385');
INSERT INTO `ebubechukwuigwegbescores` VALUES(29, '2016-08-28', 'The Best Kept Secret', 'Quiz 6 & Annotation', 'Lanre Ibironke', 0, 13, '0', 'ebubechukwuigwegbescores', '1.385');
INSERT INTO `ebubechukwuigwegbescores` VALUES(30, '2016-09-04', 'Divine Secrets', 'Annotation', 'Lanre Ibironke', 0, 13, '0', 'ebubechukwuigwegbescores', '1.385');
INSERT INTO `ebubechukwuigwegbescores` VALUES(36, '2016-10-16', 'Joined', 'Online Quiz', 'Lanre Ibironke', 157, 13, '12.089', 'ebubechukwuigwegbescores', '13.474');
INSERT INTO `ebubechukwuigwegbescores` VALUES(37, '2016-10-23', 'What is Faith?', 'Online Quiz', 'David Oyedepo', 5, 13, '0.385', 'ebubechukwuigwegbescores', '13.859');
INSERT INTO `ebubechukwuigwegbescores` VALUES(40, '2017-02-19', 'Deepening your Relationship with God & 3 Types of Friends', 'Online Quiz', 'TD Jakes', 226, 13, '17.402', 'ebubechukwuigwegbescores', '31.261');

-- --------------------------------------------------------

--
-- Table structure for table `ebunoluwaajiboyescores`
--

CREATE TABLE `ebunoluwaajiboyescores` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `exercise` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `source` varchar(200) NOT NULL,
  `score` mediumint(9) NOT NULL,
  `currentage` mediumint(9) NOT NULL,
  `aggregate` varchar(200) NOT NULL,
  `tableName` varchar(50) NOT NULL,
  `currentTotalAggregate` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=55 ;

--
-- Dumping data for table `ebunoluwaajiboyescores`
--

INSERT INTO `ebunoluwaajiboyescores` VALUES(35, '2016-01-15', 'Arrived', 'Default', 'Lanre Ibironke', 167, 13, '12.859', 'ebunoluwaajiboyescores', '12.859');
INSERT INTO `ebunoluwaajiboyescores` VALUES(36, '2017-01-22', 'Eternal Life', 'Online Quiz', 'Andrew Wommack', 56, 13, '4.312', 'ebunoluwaajiboyescores', '17.171');
INSERT INTO `ebunoluwaajiboyescores` VALUES(37, '2017-01-29', 'The Holy Spirit', 'Online Quiz', 'Pastor E.A. Adeboye & Andrew Wommack', 286, 13, '22.022', 'ebunoluwaajiboyescores', '39.193');
INSERT INTO `ebunoluwaajiboyescores` VALUES(38, '2017-02-05', 'God''s Kind of Love To You', 'Online Quiz', 'Andrew Wommack', 425, 13, '32.725', 'ebunoluwaajiboyescores', '71.918');
INSERT INTO `ebunoluwaajiboyescores` VALUES(39, '2017-02-12', '7 Mistakes to avoid before Marriage & End of the Harvest', 'Online Quiz', 'Pastor E.A. Adeboye & Christiano Film Group', 301, 13, '23.177', 'ebunoluwaajiboyescores', '95.095');
INSERT INTO `ebunoluwaajiboyescores` VALUES(40, '2017-02-19', 'Deepening your Relationship with God & 3 Types of Friends', 'Online Quiz', 'TD Jakes', 334, 13, '25.718', 'ebunoluwaajiboyescores', '120.813');
INSERT INTO `ebunoluwaajiboyescores` VALUES(41, '2017-02-26', 'Ultimate Myles Munroe 2016 Collection', 'Online Quiz', 'Myles Munroe', 178, 13, '13.706', 'ebunoluwaajiboyescores', '134.519');
INSERT INTO `ebunoluwaajiboyescores` VALUES(42, '2017-03-05', 'Spirituality the Master Key to a World of Exploits', 'Online Quiz', 'Bishop David Oyedepo', 232, 13, '17.864', 'ebunoluwaajiboyescores', '152.383');
INSERT INTO `ebunoluwaajiboyescores` VALUES(43, '2017-03-12', 'The Kingdom Power of Self Government', 'Online Quiz', 'Myles Munroe', 616, 14, '43.978', 'ebunoluwaajiboyescores', '196.361');
INSERT INTO `ebunoluwaajiboyescores` VALUES(44, '2017-03-19', 'Life 2', 'Online Quiz', 'Bishop David Oyedepo', 638, 14, '45.542', 'ebunoluwaajiboyescores', '241.903');
INSERT INTO `ebunoluwaajiboyescores` VALUES(45, '2017-03-26', 'Marriage Prep 101', 'Online Quiz', 'Myles Munroe', 1014, 14, '72.386', 'ebunoluwaajiboyescores', '314.289');
INSERT INTO `ebunoluwaajiboyescores` VALUES(46, '2017-04-02', 'Salvation Testimony', 'Online Quiz', 'Kenneth Erwin Hagin', 673, 14, '48.049', 'ebunoluwaajiboyescores', '362.338');
INSERT INTO `ebunoluwaajiboyescores` VALUES(47, '2017-04-09', 'God\\''s Love (Love Series 3)', 'Online Quiz', 'Andrew Wommack', 1138, 14, '81.234', 'ebunoluwaajiboyescores', '443.572');
INSERT INTO `ebunoluwaajiboyescores` VALUES(48, '2017-04-16', 'The Last Reformation 1(0:00-30:27)', 'Online Quiz', 'Akatio Films', 955, 14, '68.177', 'ebunoluwaajiboyescores', '511.749');
INSERT INTO `ebunoluwaajiboyescores` VALUES(49, '2017-04-23', 'The Power of Spiritual Depth', 'Online Quiz', 'Bishop David Oyedepo', 1872, 14, '133.644', 'ebunoluwaajiboyescores', '645.393');
INSERT INTO `ebunoluwaajiboyescores` VALUES(51, '2017-04-28', 'The Last Reformation(30:27-The End)', 'Online Quiz', 'Akatio Films', 1637, 14, '116.869', 'ebunoluwaajiboyescores', '762.262');
INSERT INTO `ebunoluwaajiboyescores` VALUES(52, '2017-05-05', 'The Principles of Creation', 'Online Quiz', 'Myles Munroe', 1027, 14, '73.319', 'ebunoluwaajiboyescores', '835.581');
INSERT INTO `ebunoluwaajiboyescores` VALUES(53, '2017-05-12', 'Drive Through History Holy Land 1', 'Online Quiz', 'Myles Munroe', 1803, 14, '128.729', 'ebunoluwaajiboyescores', '964.31');
INSERT INTO `ebunoluwaajiboyescores` VALUES(54, '2017-05-19', 'The Principles of Creation', 'Online Quiz', 'Myles Munroe', 1769, 14, '126.289', 'ebunoluwaajiboyescores', '1090.599');

-- --------------------------------------------------------

--
-- Table structure for table `elijahshondescores`
--

CREATE TABLE `elijahshondescores` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `exercise` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `source` varchar(200) NOT NULL,
  `score` mediumint(9) NOT NULL,
  `currentage` mediumint(9) NOT NULL,
  `aggregate` varchar(200) NOT NULL,
  `tableName` varchar(50) NOT NULL DEFAULT 'elijahshondescores',
  `currentTotalAggregate` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=46 ;

--
-- Dumping data for table `elijahshondescores`
--

INSERT INTO `elijahshondescores` VALUES(1, '2016-01-03', 'Eternal Life', 'Review', 'Andrew Wommack', 0, 12, '0.000', 'elijahshondescores', '0');
INSERT INTO `elijahshondescores` VALUES(2, '2016-01-10', 'Close Encounter of the God Kind', 'Review ', 'Jesse Duplantis', 0, 12, '0.000', 'elijahshondescores', '0');
INSERT INTO `elijahshondescores` VALUES(3, '2016-01-31', 'Growing Up Spiritually', 'Review', 'Kenneth E Hagin', 0, 12, '0.000', 'elijahshondescores', '0');
INSERT INTO `elijahshondescores` VALUES(4, '2016-02-07', 'The Cost of a Crown', 'Quiz', 'Bishop David Oyedepo', 0, 12, '0.000', 'elijahshondescores', '0');
INSERT INTO `elijahshondescores` VALUES(5, '2016-02-14', 'The Love Walk', 'Review', 'Kenneth E Hagin', 0, 12, '0.000', 'elijahshondescores', '0');
INSERT INTO `elijahshondescores` VALUES(6, '2016-02-21', 'Opted for Group Discussion', 'Group Discussion', 'Youths', 0, 13, '0.000', 'elijahshondescores', '0');
INSERT INTO `elijahshondescores` VALUES(7, '2016-03-13', 'Repositioning for Exploits', 'Review', 'Bishop David Oyedepo', 0, 13, '0.000', 'elijahshondescores', '0');
INSERT INTO `elijahshondescores` VALUES(8, '2016-03-27', '1John 4:4', 'Synonyms', 'Lanre Ibironke', 26, 13, '2.000', 'elijahshondescores', '2');
INSERT INTO `elijahshondescores` VALUES(9, '2016-04-03', 'Hand Sequence', 'Focus Test', 'Lanre Ibironke', 0, 13, '0.000', 'elijahshondescores', '2');
INSERT INTO `elijahshondescores` VALUES(10, '2016-04-10', 'Yesterday, Today and Tomorrow', 'Annotation and Silence Half Hour', 'Lanre Ibironke', 33, 13, '2.538', 'elijahshondescores', '4.538');
INSERT INTO `elijahshondescores` VALUES(11, '2016-04-17', 'Your Abilities', 'Annotation and Hand Sequence', 'Lanre Ibironke', 0, 13, '0.000', 'elijahshondescores', '4.538');
INSERT INTO `elijahshondescores` VALUES(12, '2016-04-24', 'Maximizing Your Most Valuable Asset', 'Home Work', 'Lanre Ibironke', 0, 13, '0.000', 'elijahshondescores', '4.538');
INSERT INTO `elijahshondescores` VALUES(13, '2016-05-01', 'Character Custodian of Destiny', 'Quiz', 'Bishop David Oyedepo', 0, 13, '0.000', 'elijahshondescores', '4.538');
INSERT INTO `elijahshondescores` VALUES(14, '2016-05-08', 'The Myth of Singleness', 'Question', 'The Myth of Singleness', 25, 13, '1.923', 'elijahshondescores', '6.461');
INSERT INTO `elijahshondescores` VALUES(15, '2016-05-15', 'Being Still (Psalms 46vs10)', 'Chicken on Egg Scenario', 'Lanre Ibironke', 5, 13, '0.385', 'elijahshondescores', '6.846');
INSERT INTO `elijahshondescores` VALUES(16, '2016-05-22', 'Selecting the Most Appropriate Word Replacement', 'Quiz', 'Lanre Ibironke', 45, 13, '3.462', 'elijahshondescores', '10.308');
INSERT INTO `elijahshondescores` VALUES(17, '2016-05-29', 'Personalizing Scripture', 'Theory Question', 'Lanre Ibironke', 4, 13, '0.308', 'elijahshondescores', '10.616');
INSERT INTO `elijahshondescores` VALUES(18, '2016-06-05', 'Inner Counsel', 'Annotation', 'Lanre Ibironke', 0, 13, '0', 'elijahshondescores', '10.616');
INSERT INTO `elijahshondescores` VALUES(19, '2016-06-12', 'Bible Questions', 'General Quiz', 'Lanre Ibironke', 0, 13, '0', 'elijahshondescores', '10.616');
INSERT INTO `elijahshondescores` VALUES(20, '2016-06-19', 'Marathon Question', 'General Quiz 2', 'Lanre Ibironke', 0, 13, '0', 'elijahshondescores', '10.616');
INSERT INTO `elijahshondescores` VALUES(21, '2016-06-26', 'Uzziah''s Story', 'Annotation', 'Lanre Ibironke', 0, 13, '0', 'elijahshondescores', '10.616');
INSERT INTO `elijahshondescores` VALUES(22, '2016-07-03', 'Multiple Choice', 'General Quiz 3', 'Lanre Ibironke', 0, 13, '0', 'elijahshondescores', '10.616');
INSERT INTO `elijahshondescores` VALUES(23, '2016-07-10', '4-Cards', 'Bible Game', 'Lanre Ibironke', 19, 13, '1.462', 'elijahshondescores', '12.078');
INSERT INTO `elijahshondescores` VALUES(24, '2016-07-24', 'Memory Test', 'Theory Questions', 'Lanre Ibironke', 0, 13, '0', 'elijahshondescores', '12.078');
INSERT INTO `elijahshondescores` VALUES(25, '2016-07-31', 'Scripture Expansion', 'Presentation', 'Lanre Ibironke', 24, 13, '1.846', 'elijahshondescores', '13.924');
INSERT INTO `elijahshondescores` VALUES(26, '2016-08-07', 'Multiple Choice', 'General Quiz 4', 'Lanre Ibironke', 58, 13, '4.462', 'elijahshondescores', '18.386');
INSERT INTO `elijahshondescores` VALUES(27, '2016-08-14', 'Tower of Hanoi & Marriage', 'Puzzle  & Annotation', 'Lanre Ibironke', 0, 13, '0', 'elijahshondescores', '18.386');
INSERT INTO `elijahshondescores` VALUES(28, '2016-08-21', 'The Innovative Demands of Leadership', 'Quiz 5', 'Myles Munroe', 25, 13, '1.923', 'elijahshondescores', '20.309');
INSERT INTO `elijahshondescores` VALUES(29, '2016-08-28', 'The Best Kept Secret', 'Quiz 6 & Annotation', 'Lanre Ibironke', 15, 13, '1.154', 'elijahshondescores', '21.463');
INSERT INTO `elijahshondescores` VALUES(30, '2016-09-04', 'Divine Secrets', 'Annotation', 'Lanre Ibironke', 60, 13, '4.615', 'elijahshondescores', '26.078000000000003');
INSERT INTO `elijahshondescores` VALUES(31, '2016-09-11', 'Repositioning for Exploits', 'Online Quiz', 'Bishop David Oyedepo', 0, 13, '0', 'elijahshondescores', '26.078');
INSERT INTO `elijahshondescores` VALUES(32, '2016-09-18', 'Kingdom Keys to Successful Relationships', 'Online Quiz', 'Myles Munroe', 291, 13, '22.407', 'elijahshondescores', '48.485');
INSERT INTO `elijahshondescores` VALUES(33, '2016-09-25', 'Heralding the Emergence of World Changers', 'Online Quiz', 'Bishop David Oyedepo', 83, 13, '6.391', 'elijahshondescores', '54.876');
INSERT INTO `elijahshondescores` VALUES(34, '2016-10-02', 'The Encounter', 'Online Quiz', 'Pure Flix Entertainment', 219, 13, '16.863', 'elijahshondescores', '71.739');
INSERT INTO `elijahshondescores` VALUES(35, '2016-11-06', 'Vital Keys to Achieving Your Vision', 'Online Quiz', 'Myles Munroe', 466, 13, '35.882', 'elijahshondescores', '107.621');
INSERT INTO `elijahshondescores` VALUES(36, '2017-01-15', 'Life', 'Online Quiz', 'David Oyedepo', 29, 13, '2.233', 'elijahshondescores', '109.854');
INSERT INTO `elijahshondescores` VALUES(37, '2017-01-22', 'Eternal Life', 'Online Quiz', 'Andrew Wommack', 80, 13, '6.16', 'elijahshondescores', '116.014');
INSERT INTO `elijahshondescores` VALUES(38, '2017-01-29', 'The Holy Spirit', 'Online Quiz', 'Pastor Adeboye & Andrew Wommack', 282, 13, '21.714', 'elijahshondescores', '137.728');
INSERT INTO `elijahshondescores` VALUES(39, '2017-02-12', '7 Mistakes to avoid before marriage & End of the Harvest', 'Online Quiz', 'Pastor E.A. Adeboye & Christiano Film Group', 253, 13, '19.481', 'elijahshondescores', '157.209');
INSERT INTO `elijahshondescores` VALUES(40, '2017-02-19', 'Deepening your Relationship with God & 3 Types of Friends', 'Online Quiz', 'TD Jakes', 286, 14, '20.429', 'elijahshondescores', '177.638');
INSERT INTO `elijahshondescores` VALUES(41, '2017-03-26', 'Marriage Prep 101', 'Online Quiz', 'Myles Munroe', 152, 14, '10.842', 'elijahshondescores', '188.48');
INSERT INTO `elijahshondescores` VALUES(42, '2017-04-16', 'The Last Reformation 1(0:00-30:27)', 'Online Quiz', 'Akatio Films', 812, 14, '57.958', 'elijahshondescores', '246.438');
INSERT INTO `elijahshondescores` VALUES(43, '2017-04-23', 'The Power of Spiritual Depth', 'Online Quiz', 'Bishop David Oyedepo', 1730, 14, '123.5', 'elijahshondescores', '369.938');
INSERT INTO `elijahshondescores` VALUES(44, '2017-04-28', 'The Last Reformation(30:27-The End)', 'Online Quiz', 'Akatio Films', 175, 14, '12.495', 'elijahshondescores', '382.433');
INSERT INTO `elijahshondescores` VALUES(45, '2017-05-05', 'The Principles of Creation', 'Online Quiz', 'Myles Munroe', 321, 14, '22.909', 'elijahshondescores', '405.342');

-- --------------------------------------------------------

--
-- Table structure for table `elizabethshondescores`
--

CREATE TABLE `elizabethshondescores` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `exercise` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `source` varchar(200) NOT NULL,
  `score` mediumint(9) NOT NULL,
  `currentage` mediumint(9) NOT NULL,
  `aggregate` varchar(200) NOT NULL,
  `tableName` varchar(50) NOT NULL DEFAULT 'elizabethshondescores',
  `currentTotalAggregate` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=48 ;

--
-- Dumping data for table `elizabethshondescores`
--

INSERT INTO `elizabethshondescores` VALUES(1, '2016-01-03', 'Eternal Life', 'Review', 'Andrew Wommack', 0, 10, '0.000', 'elizabethshondescores', '0');
INSERT INTO `elizabethshondescores` VALUES(2, '2016-01-10', 'Close Encounter of the God Kind', 'Review', 'Jesse Duplantis', 0, 10, '0.000', 'elizabethshondescores', '0');
INSERT INTO `elizabethshondescores` VALUES(3, '2016-01-31', 'Growing Up Spiritually', 'Review', 'Kenneth E Hagin', 0, 10, '0.000', 'elizabethshondescores', '0');
INSERT INTO `elizabethshondescores` VALUES(4, '2016-02-07', 'The Cost of a Crown', 'Quiz', 'Bishop David Oyedepo', 0, 10, '0.000', 'elizabethshondescores', '0');
INSERT INTO `elizabethshondescores` VALUES(5, '2016-02-14', 'The Love Walk', 'Review', 'Kenneth E Hagin', 0, 10, '0.000', 'elizabethshondescores', '0');
INSERT INTO `elizabethshondescores` VALUES(6, '2016-02-21', 'Opted for Group Discussion', 'Group Discussion', 'Youth', 0, 10, '0.000', 'elizabethshondescores', '0');
INSERT INTO `elizabethshondescores` VALUES(7, '2016-03-13', 'Repositioning for Exploits', 'Review', 'Bishop David Oyedepo', 0, 11, '0.000', 'elizabethshondescores', '0');
INSERT INTO `elizabethshondescores` VALUES(8, '2016-03-27', '1John 4:4', 'Synonyms', 'Lanre Ibironke', 19, 11, '1.727', 'elizabethshondescores', '1.727');
INSERT INTO `elizabethshondescores` VALUES(9, '2016-04-03', 'Hand Sequence', 'Focus Test', 'Lanre Ibironke', 0, 11, '0.000', 'elizabethshondescores', '1.727');
INSERT INTO `elizabethshondescores` VALUES(10, '2016-04-10', 'Yesterday, Today and Tomorrow', 'Annotation and Silence Half Hour', 'Lanre Ibironke', 35, 11, '3.182', 'elizabethshondescores', '4.909');
INSERT INTO `elizabethshondescores` VALUES(11, '2016-04-17', 'Your Abilities', 'Annotation and Hand Sequence', 'Lanre Ibironke', 0, 11, '0.000', 'elizabethshondescores', '4.909');
INSERT INTO `elizabethshondescores` VALUES(12, '2016-04-24', 'Maximizing Your Most Valuable Asset', 'Home Work', 'Lanre Ibironke', 0, 11, '0.000', 'elizabethshondescores', '4.909');
INSERT INTO `elizabethshondescores` VALUES(13, '2016-05-01', 'Character Custodian of Destiny', 'Quiz', 'Bishop David Oyedepo', 0, 11, '0.000', 'elizabethshondescores', '4.909');
INSERT INTO `elizabethshondescores` VALUES(14, '2016-05-08', 'The Myth of Singleness', 'Questions', 'Dr Myles Munroe', 17, 11, '1.545', 'elizabethshondescores', '6.454');
INSERT INTO `elizabethshondescores` VALUES(15, '2016-05-15', 'Being Still (Psalms 46vs10)', 'Chicken on Egg Scenario', 'Lanre Ibironke', 7, 11, '0.636', 'elizabethshondescores', '7.09');
INSERT INTO `elizabethshondescores` VALUES(16, '2016-05-22', 'Selecting the Most Appropriate Word Replacement', 'Quiz', 'Lanre Ibironke', 50, 11, '4.545', 'elizabethshondescores', '11.635');
INSERT INTO `elizabethshondescores` VALUES(17, '2016-05-29', 'Personalizing Scripture', 'Theory Question', 'Lanre Ibironke', 4, 11, '0.364', 'elizabethshondescores', '11.999');
INSERT INTO `elizabethshondescores` VALUES(18, '2016-06-05', 'Inner Counsel', 'Annotation', 'Lanre Ibironke', 0, 11, '0', 'elizabethshondescores', '11.999');
INSERT INTO `elizabethshondescores` VALUES(19, '2016-06-12', 'Bible Questions', 'General Quiz', 'Lanre Ibironke', 0, 11, '0', 'elizabethshondescores', '11.999');
INSERT INTO `elizabethshondescores` VALUES(20, '2016-06-19', 'Marathon Question', 'General Quiz 2', 'Lanre Ibironke', 0, 11, '0', 'elizabethshondescores', '11.999');
INSERT INTO `elizabethshondescores` VALUES(21, '2016-06-26', 'Uzziah''s Story', 'Annotation', 'Lanre Ibironke', 12, 11, '1.091', 'elizabethshondescores', '13.09');
INSERT INTO `elizabethshondescores` VALUES(22, '2016-07-03', 'Multiple Choice', 'General Quiz 3', 'Lanre Ibironke', 0, 11, '0', 'elizabethshondescores', '13.09');
INSERT INTO `elizabethshondescores` VALUES(23, '2016-07-10', '4-Cards', 'Bible Game', 'Lanre Ibironke', 20, 11, '1.818', 'elizabethshondescores', '14.908');
INSERT INTO `elizabethshondescores` VALUES(24, '2016-07-24', 'Memory Test', 'Theory Questions', 'Lanre Ibironke', 0, 11, '0', 'elizabethshondescores', '14.908');
INSERT INTO `elizabethshondescores` VALUES(25, '2016-07-31', 'Scripture Expansion', 'Presentation', 'Lanre Ibironke', 25, 11, '2.273', 'elizabethshondescores', '17.181');
INSERT INTO `elizabethshondescores` VALUES(26, '2016-08-07', 'Multiple Choice', 'General Quiz 4', 'Lanre Ibironke', 48, 11, '4.364', 'elizabethshondescores', '21.545');
INSERT INTO `elizabethshondescores` VALUES(27, '2016-08-14', 'Tower of Hanoi & Marriage', 'Puzzle  & Annotation', 'Lanre Ibironke', 0, 11, '0', 'elizabethshondescores', '21.545');
INSERT INTO `elizabethshondescores` VALUES(28, '2016-08-21', 'The Innovative Demands of Leadership', 'Quiz 5', 'Myles Munroe', 22, 11, '2', 'elizabethshondescores', '23.545');
INSERT INTO `elizabethshondescores` VALUES(29, '2016-08-28', 'The Best Kept Secret', 'Quiz 6 & Annotation', 'Lanre Ibironke', 12, 11, '1.091', 'elizabethshondescores', '24.636');
INSERT INTO `elizabethshondescores` VALUES(30, '2016-09-04', 'Divine Secrets', 'Annotation', 'Lanre Ibironke', 32, 11, '2.909', 'elizabethshondescores', '27.544999999999998');
INSERT INTO `elizabethshondescores` VALUES(31, '2016-09-11', 'Repositioning for Exploits', 'Online Quiz', 'Bishop David Oyedepo', 0, 11, '0', 'elizabethshondescores', '27.545');
INSERT INTO `elizabethshondescores` VALUES(32, '2016-09-18', 'Kingdom Keys to Successful Relationships', 'Online Quiz', 'Myles Munroe', 130, 11, '11.83', 'elizabethshondescores', '39.375');
INSERT INTO `elizabethshondescores` VALUES(33, '2016-09-25', 'Heralding the Emergence of World Changers', 'Online Quiz', 'Bishop David Oyedepo', 23, 11, '2.093', 'elizabethshondescores', '41.468');
INSERT INTO `elizabethshondescores` VALUES(34, '2016-10-02', 'The Encounter', 'Online Quiz', 'Pure Flix Entertainment', 54, 11, '4.914', 'elizabethshondescores', '46.382');
INSERT INTO `elizabethshondescores` VALUES(35, '2016-10-16', 'What is Faith?', 'Online Quiz', 'David Oyedepo', 18, 11, '1.638', 'elizabethshondescores', '48.02');
INSERT INTO `elizabethshondescores` VALUES(36, '2016-11-06', 'Vital Keys to Achieving Your Vision', 'Online Quiz', 'Myles Munroe', 27, 11, '2.457', 'elizabethshondescores', '50.477');
INSERT INTO `elizabethshondescores` VALUES(37, '2016-11-13', 'Engaging Violent Faith for Supernatural Turnaround', 'Online Quiz', 'Bishop David Oyedepo', 348, 11, '31.668', 'elizabethshondescores', '82.145');
INSERT INTO `elizabethshondescores` VALUES(38, '2016-12-11', 'The Stronghold of Faith', 'Online Quiz', 'Bishop David Oyedepo', 47, 11, '4.277', 'elizabethshondescores', '86.422');
INSERT INTO `elizabethshondescores` VALUES(39, '2017-01-15', 'The Life and Power of Words', 'Online Quiz', 'Charles Capps', 411, 11, '37.401', 'elizabethshondescores', '123.823');
INSERT INTO `elizabethshondescores` VALUES(40, '2017-01-22', 'Eternal Life', 'Online Quiz', 'Andrew Wommack', 275, 11, '25.025', 'elizabethshondescores', '148.848');
INSERT INTO `elizabethshondescores` VALUES(41, '2017-01-29', 'The Holy Spirit', 'Online Quiz', 'Pastor Adeboye & Andrew Wommack', 270, 11, '24.57', 'elizabethshondescores', '173.418');
INSERT INTO `elizabethshondescores` VALUES(42, '2017-02-05', 'God''s Kind of Love To You', 'Online Quiz', 'Andrew Wommack', 353, 11, '32.123', 'elizabethshondescores', '205.541');
INSERT INTO `elizabethshondescores` VALUES(43, '2017-02-12', '7 Mistakes to avoid before marriage & End of the Harvest', 'Online Quiz', 'Pastor E.A. Adeboye & Christiano Film Group', 211, 11, '19.201', 'elizabethshondescores', '224.742');
INSERT INTO `elizabethshondescores` VALUES(44, '2017-02-19', 'Deepening your Relationship with God & 3 Types of Friends (Birthday Mar. 7)', 'Online Quiz', 'TD Jakes', 326, 12, '29.666', 'elizabethshondescores', '254.408');
INSERT INTO `elizabethshondescores` VALUES(45, '2017-04-16', 'The Last Reformation 1(0:00-30:27)', 'Online Quiz', 'Akatio Films', 371, 12, '30.939', 'elizabethshondescores', '285.347');
INSERT INTO `elizabethshondescores` VALUES(46, '2017-04-23', 'The Power of Spiritual Depth', 'Online Quiz', 'Bishop David Oyedepo', 1296, 12, '108.02', 'elizabethshondescores', '393.367');
INSERT INTO `elizabethshondescores` VALUES(47, '2017-04-28', 'The Last Reformation(30:27-The End)', 'Online Quiz', 'Akatio Films', 126, 12, '10.508', 'elizabethshondescores', '403.875');

-- --------------------------------------------------------

--
-- Table structure for table `eniolaadewunmiscores`
--

CREATE TABLE `eniolaadewunmiscores` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `exercise` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `source` varchar(200) NOT NULL,
  `score` mediumint(9) NOT NULL,
  `currentage` mediumint(9) NOT NULL,
  `aggregate` varchar(200) NOT NULL,
  `tableName` varchar(50) NOT NULL DEFAULT 'eniolaadewunmiscores',
  `currentTotalAggregate` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=47 ;

--
-- Dumping data for table `eniolaadewunmiscores`
--

INSERT INTO `eniolaadewunmiscores` VALUES(1, '2016-01-03', 'Eternal Life', 'Review', 'Andrew Wommack', 15, 15, '1.000', 'eniolaadewunmiscores', '1');
INSERT INTO `eniolaadewunmiscores` VALUES(2, '2016-01-10', 'Close Encounter of the God Kind', 'Review', 'Jesse Duplantis', 0, 15, '0.000', 'eniolaadewunmiscores', '1');
INSERT INTO `eniolaadewunmiscores` VALUES(3, '2016-01-31', 'Growing Up Spiritually', 'Review', 'Kenneth E Hagin', 6, 15, '0.400', 'eniolaadewunmiscores', '1.4');
INSERT INTO `eniolaadewunmiscores` VALUES(4, '2016-02-07', 'The Cost of a Crown', 'Quiz', 'Bishop David Oyedepo', 51, 15, '3.400', 'eniolaadewunmiscores', '4.8');
INSERT INTO `eniolaadewunmiscores` VALUES(5, '2016-02-14', 'The Love Walk', 'Review', 'Kenneth E Hagin', 23, 15, '1.533', 'eniolaadewunmiscores', '6.333');
INSERT INTO `eniolaadewunmiscores` VALUES(6, '2016-02-21', 'Opted for Group Discussion', 'Group Discussion', 'Youths', 0, 15, '0.000', 'eniolaadewunmiscores', '6.333');
INSERT INTO `eniolaadewunmiscores` VALUES(7, '2016-03-13', 'Repositioning for Exploits', 'Review', 'Bishop David Oyedepo', 0, 15, '0.000', 'eniolaadewunmiscores', '6.333');
INSERT INTO `eniolaadewunmiscores` VALUES(8, '2016-03-27', '1John 4:4', 'Synonyms', 'Lanre Ibironke', 36, 16, '2.250', 'eniolaadewunmiscores', '8.583');
INSERT INTO `eniolaadewunmiscores` VALUES(9, '2016-04-03', 'Hand Sequence', 'Focus Test', 'Lanre Ibironke', 41, 16, '2.563', 'eniolaadewunmiscores', '11.146');
INSERT INTO `eniolaadewunmiscores` VALUES(10, '2016-04-10', 'Yesterday, Today and Tomorrow', 'Annotation and Silence Half Hour', 'Lanre Ibironke', 60, 16, '3.750', 'eniolaadewunmiscores', '14.896');
INSERT INTO `eniolaadewunmiscores` VALUES(11, '2016-04-17', 'Your Abilities', 'Annotation and Hand Sequence', 'Lanre Ibironke', 28, 16, '1.750', 'eniolaadewunmiscores', '16.646');
INSERT INTO `eniolaadewunmiscores` VALUES(12, '2016-04-24', 'Maximizing Your Most Valuable Asset', 'Home Work', 'Lanre Ibironke', 0, 16, '0.000', 'eniolaadewunmiscores', '16.646');
INSERT INTO `eniolaadewunmiscores` VALUES(13, '2016-05-01', 'Character Custodian of Destiny', 'Quiz', 'Bishop David Oyedepo', 47, 16, '2.938', 'eniolaadewunmiscores', '19.584');
INSERT INTO `eniolaadewunmiscores` VALUES(14, '2016-05-08', 'The Myth of Singleness', 'Questions', 'Dr Myles Munroe', 0, 16, '0.000', 'eniolaadewunmiscores', '19.584');
INSERT INTO `eniolaadewunmiscores` VALUES(15, '2016-05-15', 'Being Still (Psalms 46v10)', 'Chicken on Egg Scenario', 'Lanre Ibironke', 2, 16, '0.125', 'eniolaadewunmiscores', '19.709');
INSERT INTO `eniolaadewunmiscores` VALUES(16, '2016-05-22', 'Selecting the Most Appropriate Word Replacement', 'Quiz', 'Lanre Ibironke', 40, 16, '2.500', 'eniolaadewunmiscores', '22.209');
INSERT INTO `eniolaadewunmiscores` VALUES(17, '2016-05-29', 'Personalizing Scripture', 'Theory Question', 'Lanre Ibironke', 0, 16, '0', 'eniolaadewunmiscores', '22.209');
INSERT INTO `eniolaadewunmiscores` VALUES(18, '2016-06-05', 'Inner Counsel', 'Annotation', 'Lanre Ibironke', 65, 16, '4.063', 'eniolaadewunmiscores', '26.272');
INSERT INTO `eniolaadewunmiscores` VALUES(19, '2016-06-12', 'Bible Questions', 'General Quiz', 'Lanre Ibironke', 45, 16, '2.813', 'eniolaadewunmiscores', '29.085');
INSERT INTO `eniolaadewunmiscores` VALUES(20, '2016-06-19', 'Marathon Question', 'General Quiz 2', 'Lanre Ibironke', 120, 16, '7.5', 'eniolaadewunmiscores', '36.585');
INSERT INTO `eniolaadewunmiscores` VALUES(21, '2016-06-26', 'Uzziah''s Story', 'Annotation', 'Lanre Ibironke', 40, 16, '2.5', 'eniolaadewunmiscores', '39.085');
INSERT INTO `eniolaadewunmiscores` VALUES(22, '2016-07-03', 'Multiple Choice', 'General Quiz 3', 'Lanre Ibironke', 60, 16, '3.75', 'eniolaadewunmiscores', '42.835');
INSERT INTO `eniolaadewunmiscores` VALUES(23, '2016-07-10', '4-Cards', 'Bible Game', 'Lanre Ibironke', 45, 16, '2.813', 'eniolaadewunmiscores', '45.648');
INSERT INTO `eniolaadewunmiscores` VALUES(24, '2016-07-24', 'Memory Test', 'Theory Questions', 'Lanre Ibironke', 78, 16, '4.875', 'eniolaadewunmiscores', '50.523');
INSERT INTO `eniolaadewunmiscores` VALUES(25, '2016-07-31', 'Scripture Expansion', 'Presentation', 'Lanre Ibironke', 75, 16, '4.688', 'eniolaadewunmiscores', '55.211');
INSERT INTO `eniolaadewunmiscores` VALUES(26, '2016-08-07', 'Multiple Choice', 'General Quiz 4', 'Lanre Ibironke', 0, 16, '0', 'eniolaadewunmiscores', '55.211');
INSERT INTO `eniolaadewunmiscores` VALUES(27, '2016-08-14', 'Tower of Hanoi & Marriage', 'Puzzle  & Annotation', 'Lanre Ibironke', 49, 16, '3.063', 'eniolaadewunmiscores', '58.274');
INSERT INTO `eniolaadewunmiscores` VALUES(28, '2016-08-21', 'The Innovative Demands of Leadership', 'Quiz 5', 'Myles Munroe', 50, 16, '3.125', 'eniolaadewunmiscores', '61.399');
INSERT INTO `eniolaadewunmiscores` VALUES(29, '2016-08-28', 'The Best Kept Secret', 'Quiz 6 & Annotation', 'Lanre Ibironke', 45, 16, '2.813', 'eniolaadewunmiscores', '64.212');
INSERT INTO `eniolaadewunmiscores` VALUES(30, '2016-09-04', 'Divine Secrets', 'Annotation', 'Lanre Ibironke', 110, 16, '6.875', 'eniolaadewunmiscores', '71.087');
INSERT INTO `eniolaadewunmiscores` VALUES(31, '2016-09-11', 'Repositioning for Exploits', 'Online Quiz', 'Bishop David Oyedepo', 16, 16, '1.001', 'eniolaadewunmiscores', '72.088');
INSERT INTO `eniolaadewunmiscores` VALUES(32, '2016-09-18', 'Kingdom Keys to Successful Relationships', 'Online Quiz', 'Myles Munroe', 36, 16, '2.252', 'eniolaadewunmiscores', '74.34');
INSERT INTO `eniolaadewunmiscores` VALUES(33, '2016-09-25', 'Heralding the Emergence of World Changers', 'Online Quiz', 'Bishop David Oyedepo', 16, 16, '1.002', 'eniolaadewunmiscores', '75.342');
INSERT INTO `eniolaadewunmiscores` VALUES(34, '2016-10-02', 'The Encounter', 'Online Quiz', 'Pure Flix Entertainment', 63, 16, '3.945', 'eniolaadewunmiscores', '79.287');
INSERT INTO `eniolaadewunmiscores` VALUES(35, '2016-10-09', 'The Ten Attitudes for Leadership Development', 'Online Quiz', 'Myles Munroe & David Oyedepo', 465, 16, '29.149', 'eniolaadewunmiscores', '108.436');
INSERT INTO `eniolaadewunmiscores` VALUES(36, '2016-10-16', 'What is Faith?', 'Online Quiz', 'David Oyedepo', 333, 16, '20.847', 'eniolaadewunmiscores', '129.283');
INSERT INTO `eniolaadewunmiscores` VALUES(37, '2016-10-23', 'The Media Mandate of the Kingdom', 'Online Quiz', 'Myles Munroe', 593, 16, '37.127', 'eniolaadewunmiscores', '166.41');
INSERT INTO `eniolaadewunmiscores` VALUES(38, '2016-10-30', 'Engaging the Armour of Light for Total Deliverance', 'Online Quiz', 'David Oyedepo', 58, 16, '3.632', 'eniolaadewunmiscores', '170.042');
INSERT INTO `eniolaadewunmiscores` VALUES(39, '2016-11-06', 'Vital Keys to Achieving Your Vision', 'Online Quiz', 'Myles Munroe', 458, 16, '28.68', 'eniolaadewunmiscores', '198.722');
INSERT INTO `eniolaadewunmiscores` VALUES(40, '2016-11-27', 'How to Excel in Your Field', 'Online Quiz', 'Bishop David Oyedepo', 309, 16, '19.363', 'eniolaadewunmiscores', '218.085');
INSERT INTO `eniolaadewunmiscores` VALUES(41, '2016-12-18', 'How to Deal With Grief 1', 'Online Quiz', 'Andrew Wommack', 360, 16, '22.548', 'eniolaadewunmiscores', '240.633');
INSERT INTO `eniolaadewunmiscores` VALUES(42, '2017-01-08', 'Christmas Jubilee and Direction', 'Online Quiz', 'Myles Munroe', 89, 16, '5.577', 'eniolaadewunmiscores', '246.21');
INSERT INTO `eniolaadewunmiscores` VALUES(43, '2017-01-22', 'Eternal Life', 'Online Quiz', 'Andrew Wommack', 52, 16, '3.256', 'eniolaadewunmiscores', '249.466');
INSERT INTO `eniolaadewunmiscores` VALUES(44, '2017-02-12', '7 Mistakes to avoid before marriage & End of the Harvest', 'Online Quiz', 'Pastor E.A. Adeboye & Christiano Film Group', 309, 16, '19.353', 'eniolaadewunmiscores', '268.819');
INSERT INTO `eniolaadewunmiscores` VALUES(45, '2017-03-12', 'The Kingdom Power of Self Government', 'Online Quiz', 'Myles Munroe', 15, 16, '0.939', 'eniolaadewunmiscores', '269.758');
INSERT INTO `eniolaadewunmiscores` VALUES(46, '2017-03-19', 'Life 2 (Birthday Mar 20)', 'Online Quiz', 'Bishop David Oyedepo', 212, 17, '13.284', 'eniolaadewunmiscores', '283.042');

-- --------------------------------------------------------

--
-- Table structure for table `esthershondescores`
--

CREATE TABLE `esthershondescores` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `exercise` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `source` varchar(200) NOT NULL,
  `score` mediumint(9) NOT NULL,
  `currentage` mediumint(9) NOT NULL,
  `aggregate` varchar(200) NOT NULL,
  `tableName` varchar(50) NOT NULL DEFAULT 'esthershondescores',
  `currentTotalAggregate` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=49 ;

--
-- Dumping data for table `esthershondescores`
--

INSERT INTO `esthershondescores` VALUES(1, '2016-01-03', 'Eternal Life', 'Review', 'Andrew Wommack', 0, 14, '0.000', 'esthershondescores', '0');
INSERT INTO `esthershondescores` VALUES(2, '2016-01-10', 'Close Encounter of the God Kind', 'Review', 'Jesse Duplantis', 0, 14, '0.000', 'esthershondescores', '0');
INSERT INTO `esthershondescores` VALUES(3, '2016-01-31', 'Growing Up Spiritually', 'Review', 'Kenneth E Hagin', 0, 14, '0.000', 'esthershondescores', '0');
INSERT INTO `esthershondescores` VALUES(4, '2016-02-07', 'The Cost of a Crown', 'Quiz', 'Bishop David Oyedepo', 0, 14, '0.000', 'esthershondescores', '0');
INSERT INTO `esthershondescores` VALUES(5, '2016-02-14', 'The Love Walk', 'Review', 'Kenneth E Hagin', 0, 14, '0.000', 'esthershondescores', '0');
INSERT INTO `esthershondescores` VALUES(6, '2016-02-21', 'Opted for Group Discussion', 'Group Discussion', 'Youths', 0, 14, '0.000', 'esthershondescores', '0');
INSERT INTO `esthershondescores` VALUES(7, '2016-03-13', 'Repositioning for Exploits', 'Review', 'Bishop David Oyedepo', 0, 14, '0.000', 'esthershondescores', '0');
INSERT INTO `esthershondescores` VALUES(8, '2016-03-27', '1John 4:4', 'Synonyms', 'Lanre Ibironke', 22, 14, '1.571', 'esthershondescores', '1.571');
INSERT INTO `esthershondescores` VALUES(9, '2016-04-03', 'Hand Sequence', 'Focus Test', 'Lanre Ibironke', 0, 14, '0.000', 'esthershondescores', '1.571');
INSERT INTO `esthershondescores` VALUES(10, '2016-04-10', 'Yesterday, Today and Tomorrow', 'Annotation and Silence Half Hour', 'Lanre Ibironke', 49, 14, '3.500', 'esthershondescores', '5.071');
INSERT INTO `esthershondescores` VALUES(11, '2016-04-17', 'Your Abilities', 'Annotation and Hand Sequence', 'Lanre Ibironke', 0, 14, '0.000', 'esthershondescores', '5.071');
INSERT INTO `esthershondescores` VALUES(12, '2016-04-24', 'Maximizing Your Most Valuable Asset', 'Home Work', 'Lanre Ibironke', 0, 14, '0.000', 'esthershondescores', '5.071');
INSERT INTO `esthershondescores` VALUES(13, '2016-05-01', 'Character Custodian of Destiny', 'Quiz', 'Bishop David Oyedepo', 0, 14, '0.000', 'esthershondescores', '5.071');
INSERT INTO `esthershondescores` VALUES(14, '2016-05-08', 'The Myth of Singleness', 'Questions', 'Dr Myles Munroe', 20, 14, '1.429', 'esthershondescores', '6.5');
INSERT INTO `esthershondescores` VALUES(15, '2016-05-15', 'Being Still (Psalms 46vs10)', 'Chicken on Egg Scenario', 'Lanre Ibironke', 7, 14, '0.5', 'esthershondescores', '7');
INSERT INTO `esthershondescores` VALUES(16, '2016-05-22', 'Selecting the Most Appropriate Word Replacement', 'Quiz', 'Lanre Ibironke', 30, 14, '2.143', 'esthershondescores', '9.143');
INSERT INTO `esthershondescores` VALUES(17, '2016-05-29', 'Personalizing Scripture', 'Theory Question', 'Lanre Ibironke', 10, 14, '0.714', 'esthershondescores', '9.857');
INSERT INTO `esthershondescores` VALUES(19, '2016-06-05', 'Inner Counsel', 'Annotation', 'Lanre Ibironke', 0, 14, '0', 'esthershondescores', '9.857');
INSERT INTO `esthershondescores` VALUES(20, '2016-06-12', 'Bible Questions', 'General Quiz', 'Lanre Ibironke', 0, 15, '0', 'esthershondescores', '9.857');
INSERT INTO `esthershondescores` VALUES(21, '2016-06-19', 'Marathon Question', 'General Quiz 2', 'Lanre Ibironke', 0, 15, '0', 'esthershondescores', '9.857');
INSERT INTO `esthershondescores` VALUES(22, '2016-06-26', 'Uzziah''s Story', 'Annotation', 'Lanre Ibironke', 14, 15, '0.933', 'esthershondescores', '10.79');
INSERT INTO `esthershondescores` VALUES(23, '2016-07-03', 'Multiple Choice', 'General Quiz 3', 'Lanre Ibironke', 0, 15, '0', 'esthershondescores', '10.79');
INSERT INTO `esthershondescores` VALUES(24, '2016-07-10', '4-Cards', 'Bible Game', 'Lanre Ibironke', 21, 15, '1.4', 'esthershondescores', '12.19');
INSERT INTO `esthershondescores` VALUES(25, '2016-07-24', 'Memory Test', 'Theory Questions', 'Lanre Ibironke', 0, 15, '0', 'esthershondescores', '12.19');
INSERT INTO `esthershondescores` VALUES(26, '2016-07-31', 'Scripture Expansion', 'Presentation', 'Lanre Ibironke', 45, 15, '3', 'esthershondescores', '15.19');
INSERT INTO `esthershondescores` VALUES(27, '2016-08-07', 'Multiple Choice', 'General Quiz 4', 'Lanre Ibironke', 62, 15, '4.133', 'esthershondescores', '19.323');
INSERT INTO `esthershondescores` VALUES(28, '2016-08-14', 'Tower of Hanoi & Marriage', 'Puzzle  & Annotation', 'Lanre Ibironke', 0, 15, '0', 'esthershondescores', '19.323');
INSERT INTO `esthershondescores` VALUES(29, '2016-08-21', 'The Innovative Demands of Leadership', 'Quiz 5', 'Myles Munroe', 29, 15, '1.933', 'esthershondescores', '21.256');
INSERT INTO `esthershondescores` VALUES(30, '2016-08-28', 'The Best Kept Secret', 'Quiz 6 & Annotation', 'Lanre Ibironke', 27, 15, '1.8', 'esthershondescores', '23.056');
INSERT INTO `esthershondescores` VALUES(31, '2016-09-04', 'Divine Secrets', 'Annotation', 'Lanre Ibironke', 40, 15, '2.667', 'esthershondescores', '25.723');
INSERT INTO `esthershondescores` VALUES(32, '2016-09-11', 'Repositioning for Exploits', 'Online Quiz', 'Bishop David Oyedepo', 128, 15, '8.52', 'esthershondescores', '34.243');
INSERT INTO `esthershondescores` VALUES(33, '2016-09-18', 'Kingdom Keys to Successful Relationships', 'Online Quiz', 'Myles Munroe', 61, 15, '4.06', 'esthershondescores', '38.303');
INSERT INTO `esthershondescores` VALUES(34, '2016-10-02', 'The Encounter', 'Online Quiz', 'Pure Flix Entertainment', 259, 15, '17.267', 'esthershondescores', '55.57');
INSERT INTO `esthershondescores` VALUES(35, '2016-10-16', 'What is Faith?', 'Online Quiz', 'David Oyedepo', 12, 15, '0.8', 'esthershondescores', '56.37');
INSERT INTO `esthershondescores` VALUES(36, '2016-10-30', 'Engaging the Armour of Light for Total Deliverance', 'Online Quiz', 'Bishop David Oyedepo', 4, 15, '0.268', 'esthershondescores', '56.638');
INSERT INTO `esthershondescores` VALUES(37, '2016-11-13', 'Engaging Violent Faith for Supernatural Turnaround', 'Online Quiz', 'Bishop David Oyedepo', 294, 15, '19.61', 'esthershondescores', '76.248');
INSERT INTO `esthershondescores` VALUES(38, '2016-12-11', 'The Stronghold of Faith', 'Online Quiz', 'Bishop David Oyedepo', 131, 15, '8.737', 'esthershondescores', '84.985');
INSERT INTO `esthershondescores` VALUES(39, '2017-01-15', 'Life', 'Online Quiz', 'David Oyedepo', 656, 15, '43.7', 'esthershondescores', '128.685');
INSERT INTO `esthershondescores` VALUES(40, '2017-01-22', 'Eternal Life', 'Online Quiz', 'Andrew Wommack', 115, 15, '7.663', 'esthershondescores', '136.348');
INSERT INTO `esthershondescores` VALUES(41, '2017-01-29', 'The Holy Spirit', 'Online Quiz', 'Pastor Adeboye & Andrew Wommack', 5, 15, '0.333', 'esthershondescores', '136.681');
INSERT INTO `esthershondescores` VALUES(42, '2017-02-05', 'God''s Kind of Love To You', 'Online Quiz', 'Andrew Wommack', 126, 15, '8.4', 'esthershondescores', '145.081');
INSERT INTO `esthershondescores` VALUES(43, '2017-02-12', '7 Mistakes to avoid before marriage & End of the Harvest', 'Online Quiz', 'Pastor E.A. Adeboye & Christiano Film Group', 349, 15, '23.249', 'esthershondescores', '168.33');
INSERT INTO `esthershondescores` VALUES(44, '2017-03-26', 'Marriage Prep 101', 'Online Quiz', 'Myles Munroe', 481, 15, '32.039', 'esthershondescores', '200.369');
INSERT INTO `esthershondescores` VALUES(45, '2017-04-16', 'The Last Reformation 1(0:00-30:27)', 'Online Quiz', 'Akatio Films', 970, 15, '64.604', 'esthershondescores', '264.973');
INSERT INTO `esthershondescores` VALUES(46, '2017-04-23', 'The Power of Spiritual Depth', 'Online Quiz', 'Bishop David Oyedepo', 1362, 15, '90.718', 'esthershondescores', '355.691');
INSERT INTO `esthershondescores` VALUES(47, '2017-04-28', 'The Last Reformation(30:27-The End)', 'Online Quiz', 'Akatio Films', 1585, 15, '105.567', 'esthershondescores', '461.258');
INSERT INTO `esthershondescores` VALUES(48, '2017-05-05', 'The Principles of Creation', 'Online Quiz', 'Myles Munroe', 96, 15, '6.394', 'esthershondescores', '467.652');

-- --------------------------------------------------------

--
-- Table structure for table `folaadeniyiscores`
--

CREATE TABLE `folaadeniyiscores` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `exercise` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `source` varchar(200) NOT NULL,
  `score` mediumint(9) NOT NULL,
  `currentage` mediumint(9) NOT NULL,
  `aggregate` varchar(200) NOT NULL,
  `tableName` varchar(50) NOT NULL DEFAULT 'folaadeniyiscores',
  `currentTotalAggregate` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=51 ;

--
-- Dumping data for table `folaadeniyiscores`
--

INSERT INTO `folaadeniyiscores` VALUES(1, '2016-01-03', 'Eternal Life', 'Review', 'Andrew Wommack', 0, 9, '0.000', 'folaadeniyiscores', '0');
INSERT INTO `folaadeniyiscores` VALUES(2, '2016-01-10', 'Close Encounter of the God Kind', 'Review', 'Jesse Duplantis', 0, 9, '0.000', 'folaadeniyiscores', '0');
INSERT INTO `folaadeniyiscores` VALUES(3, '2016-01-31', 'Growing Up Spiritually', 'Review', 'Kenneth E Hagin', 0, 9, '0.000', 'folaadeniyiscores', '0');
INSERT INTO `folaadeniyiscores` VALUES(4, '2016-02-07', 'The Cost of a Crown', 'Quiz', 'Bishop David Oyedepo', 0, 9, '0.000', 'folaadeniyiscores', '0');
INSERT INTO `folaadeniyiscores` VALUES(5, '2016-02-14', 'The Love Walk', 'Review', 'Kenneth E Hagin', 0, 9, '0.000', 'folaadeniyiscores', '0');
INSERT INTO `folaadeniyiscores` VALUES(6, '2016-02-21', 'Opted for Group Discussion', 'Group Discussion', 'Youths', 0, 9, '0.000', 'folaadeniyiscores', '0');
INSERT INTO `folaadeniyiscores` VALUES(7, '2016-03-13', 'Repositioning for Exploits', 'Review', 'Bishop David Oyedepo', 0, 9, '0.000', 'folaadeniyiscores', '0');
INSERT INTO `folaadeniyiscores` VALUES(8, '2016-03-27', '1John 4:4', 'Synonyms', 'Lanre Ibironke', 37, 10, '3.700', 'folaadeniyiscores', '3.7');
INSERT INTO `folaadeniyiscores` VALUES(9, '2016-04-03', 'Hand Sequence ', 'Focus Test', 'Lanre Ibironke', 43, 10, '4.300', 'folaadeniyiscores', '8');
INSERT INTO `folaadeniyiscores` VALUES(10, '2016-04-10', 'Yesterday, Today and Tomorrow', 'Annotation and Silence Half Hour', 'Lanre Ibironke', 0, 10, '0.000', 'folaadeniyiscores', '8');
INSERT INTO `folaadeniyiscores` VALUES(11, '2016-04-17', 'Your Abilities', 'Annotation and Hand Sequence', 'Lanre Ibironke', 45, 10, '4.500', 'folaadeniyiscores', '12.5');
INSERT INTO `folaadeniyiscores` VALUES(12, '2016-04-24', 'Maximizing Your Most Valuable Asset', 'Home Work', 'Lanre Ibironke', 0, 10, '0.000', 'folaadeniyiscores', '12.5');
INSERT INTO `folaadeniyiscores` VALUES(13, '2016-05-01', 'Word Finder', 'Bible Word Guess', 'Lanre Ibironke', 17, 10, '1.7', 'folaadeniyiscores', '14.2');
INSERT INTO `folaadeniyiscores` VALUES(14, '2016-05-08', 'The Myth of Singleness', 'Questions', 'Dr Myles Munroe', 15, 10, '1.500', 'folaadeniyiscores', '15.7');
INSERT INTO `folaadeniyiscores` VALUES(15, '2016-05-15', 'Being Still (Psalms 46vs10)', 'Chicken on Egg Scenario', 'Lanre Ibironke', 3, 10, '0.300', 'folaadeniyiscores', '16');
INSERT INTO `folaadeniyiscores` VALUES(16, '2016-05-22', 'Selecting the Most Appropriate Word Replacement', 'Quiz', 'Lanre Ibironke', 40, 10, '4.000', 'folaadeniyiscores', '20');
INSERT INTO `folaadeniyiscores` VALUES(17, '2016-05-29', 'Personalizing Scripture', 'Theory Question', 'Lanre Ibironke', 47, 10, '4.7', 'folaadeniyiscores', '24.7');
INSERT INTO `folaadeniyiscores` VALUES(18, '2016-06-05', 'Inner Counsel', 'Annotation', 'Lanre Ibironke', 40, 10, '4', 'folaadeniyiscores', '28.7');
INSERT INTO `folaadeniyiscores` VALUES(19, '2016-06-12', 'Bible Questions', 'General Quiz', 'Lanre Ibironke', 42, 10, '4.2', 'folaadeniyiscores', '32.9');
INSERT INTO `folaadeniyiscores` VALUES(20, '2016-06-19', 'Marathon Question', 'General Quiz 2', 'Lanre Ibironke', 28, 10, '2.8', 'folaadeniyiscores', '35.7');
INSERT INTO `folaadeniyiscores` VALUES(21, '2016-06-26', 'Uzziah''s Story', 'Annotation', 'Lanre Ibironke', 14, 10, '1.4', 'folaadeniyiscores', '37.1');
INSERT INTO `folaadeniyiscores` VALUES(22, '2016-07-03', 'Multiple Choice', 'General Quiz 3', 'Lanre Ibironke', 43, 10, '4.3', 'folaadeniyiscores', '41.4');
INSERT INTO `folaadeniyiscores` VALUES(23, '2016-07-10', '4-Cards', 'Bible Game', 'Lanre Ibironke', 21, 10, '2.1', 'folaadeniyiscores', '43.5');
INSERT INTO `folaadeniyiscores` VALUES(24, '2016-07-24', 'Memory Test', 'Theory Questions', 'Lanre Ibironke', 0, 10, '0', 'folaadeniyiscores', '43.5');
INSERT INTO `folaadeniyiscores` VALUES(25, '2016-07-31', 'Scripture Expansion', 'Presentation', 'Lanre Ibironke', 24, 10, '2.4', 'folaadeniyiscores', '45.9');
INSERT INTO `folaadeniyiscores` VALUES(26, '2016-08-07', 'Multiple Choice', 'General Quiz 4', 'Lanre Ibironke', 41, 10, '4.1', 'folaadeniyiscores', '50');
INSERT INTO `folaadeniyiscores` VALUES(27, '2016-08-14', 'Tower of Hanoi & Marriage', 'Puzzle  & Annotation', 'Lanre Ibironke', 30, 10, '3', 'folaadeniyiscores', '53');
INSERT INTO `folaadeniyiscores` VALUES(28, '2016-08-21', 'The Innovative Demands of Leadership', 'Quiz 5', 'Myles Munroe', 0, 10, '0', 'folaadeniyiscores', '53');
INSERT INTO `folaadeniyiscores` VALUES(29, '2016-08-28', 'The Best Kept Secret', 'Quiz 6 & Annotation', 'Lanre Ibironke', 42, 10, '4.2', 'folaadeniyiscores', '57.2');
INSERT INTO `folaadeniyiscores` VALUES(30, '2016-09-04', 'Divine Secrets', 'Annotation', 'Lanre Ibironke', 0, 10, '0', 'folaadeniyiscores', '57.2');
INSERT INTO `folaadeniyiscores` VALUES(31, '2016-09-11', 'Repositioning for Exploits', 'Online Quiz', 'Bishop David Oyedepo', 321, 10, '32.1', 'folaadeniyiscores', '89.3');
INSERT INTO `folaadeniyiscores` VALUES(32, '2016-09-18', 'Kingdom Keys to Successful Relationships', 'Online Quiz', 'Myles Munroe', 300, 10, '30', 'folaadeniyiscores', '119.3');
INSERT INTO `folaadeniyiscores` VALUES(33, '2016-09-25', 'Heralding the Emergence of World Changers', 'Online Quiz', 'Bishop David Oyedepo', 500, 10, '50', 'folaadeniyiscores', '169.3');
INSERT INTO `folaadeniyiscores` VALUES(34, '2016-10-02', 'The Encounter', 'Online Quiz', 'Pure Flix Entertainment', 104, 10, '10.4', 'folaadeniyiscores', '179.7');
INSERT INTO `folaadeniyiscores` VALUES(35, '2016-10-09', 'The Ten Attitudes for Leadership Development', 'Online Quiz', 'Myles Munroe & David Oyedepo', 385, 10, '38.5', 'folaadeniyiscores', '218.2');
INSERT INTO `folaadeniyiscores` VALUES(36, '2016-10-16', 'What is Faith?', 'Online Quiz', 'David Oyedepo', 145, 10, '14.5', 'folaadeniyiscores', '232.7');
INSERT INTO `folaadeniyiscores` VALUES(37, '2016-11-13', 'Engaging Violent Faith for Supernatural Turnaround', 'Online Quiz', 'Bishop David Oyedepo', 384, 10, '38.4', 'folaadeniyiscores', '271.1');
INSERT INTO `folaadeniyiscores` VALUES(38, '2016-11-27', 'How to Excel In Your Field', 'Online Quiz', 'Bishop David Oyedepo', 301, 10, '30.1', 'folaadeniyiscores', '301.2');
INSERT INTO `folaadeniyiscores` VALUES(39, '2016-12-11', 'The Stronghold of Faith', 'Online Quiz', 'Bishop David Oyedepo', 600, 10, '60', 'folaadeniyiscores', '361.2');
INSERT INTO `folaadeniyiscores` VALUES(40, '2016-12-18', 'How to Deal With Grief 1', 'Online Quiz', 'Andrew Wommack', 332, 10, '33.2', 'folaadeniyiscores', '394.4');
INSERT INTO `folaadeniyiscores` VALUES(41, '2016-12-25', 'How to Deal with Grief 2/4', 'Online Quiz', 'Andrew Wommack', 394, 10, '39.4', 'folaadeniyiscores', '433.8');
INSERT INTO `folaadeniyiscores` VALUES(42, '2017-01-08', 'Christmas Jubilee and Direction', 'Online Quiz', 'Myles Munroe', 415, 10, '41.5', 'folaadeniyiscores', '475.3');
INSERT INTO `folaadeniyiscores` VALUES(43, '2017-01-22', 'Eternal Life', 'Online Quiz', 'Andrew Wommack', 359, 10, '35.9', 'folaadeniyiscores', '511.2');
INSERT INTO `folaadeniyiscores` VALUES(44, '2017-01-29', 'The Holy Spirit', 'Online Quiz', 'Pastor Adeboye & Andrew Wommack', 286, 10, '28.6', 'folaadeniyiscores', '539.8');
INSERT INTO `folaadeniyiscores` VALUES(45, '2017-02-12', '7 Mistakes to avoid before marriage & End of the Harvest', 'Online Quiz', 'Pastor E.A. Adeboye & Christiano Film Group', 289, 10, '28.9', 'folaadeniyiscores', '568.7');
INSERT INTO `folaadeniyiscores` VALUES(46, '2017-03-05', 'Spirituality the Master Key to a World of Exploits (Birthday Mar 7)', 'Online Quiz', 'Bishop David Oyedepo', 544, 11, '54.4', 'folaadeniyiscores', '623.1');
INSERT INTO `folaadeniyiscores` VALUES(48, '2017-03-12', 'The Kingdom Power of Self Government', 'Online Quiz', 'Myles Munroe', 612, 11, '55.692', 'folaadeniyiscores', '678.792');
INSERT INTO `folaadeniyiscores` VALUES(49, '2017-04-09', 'God\\''s Love (Love Series 3)', 'Online Quiz', 'Andrew Wommack', 798, 11, '72.618', 'folaadeniyiscores', '751.41');
INSERT INTO `folaadeniyiscores` VALUES(50, '2017-04-28', 'The Last Reformation(30:27-The End)', 'Online Quiz', 'Akatio Films', 1141, 11, '103.831', 'folaadeniyiscores', '855.241');

-- --------------------------------------------------------

--
-- Table structure for table `funtoadeniyiscores`
--

CREATE TABLE `funtoadeniyiscores` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `exercise` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `source` varchar(200) NOT NULL,
  `score` mediumint(9) NOT NULL,
  `currentage` mediumint(9) NOT NULL,
  `aggregate` varchar(200) NOT NULL,
  `tableName` varchar(50) NOT NULL DEFAULT 'funtoadeniyiscores',
  `currentTotalAggregate` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=54 ;

--
-- Dumping data for table `funtoadeniyiscores`
--

INSERT INTO `funtoadeniyiscores` VALUES(1, '2016-01-03', 'Eternal Life', 'Review', 'Andrew Wommack', 0, 12, '0.000', 'funtoadeniyiscores', '0');
INSERT INTO `funtoadeniyiscores` VALUES(2, '2016-01-10', 'Close Encounter of the God Kind', 'Review', 'Jesse Duplantis', 0, 12, '0.000', 'funtoadeniyiscores', '0');
INSERT INTO `funtoadeniyiscores` VALUES(3, '2016-01-31', 'Growing Up Spiritually', 'Review', 'Kenneth E Hagin', 2, 12, '0.167', 'funtoadeniyiscores', '0.167');
INSERT INTO `funtoadeniyiscores` VALUES(4, '2016-02-07', 'The Cost of a Crown', 'Quiz', 'Bishop David Oyedepo', 20, 12, '1.667', 'funtoadeniyiscores', '1.834');
INSERT INTO `funtoadeniyiscores` VALUES(5, '2016-02-14', 'The Love Walk', 'Review', 'Kenneth E Hagin', 7, 12, '0.583', 'funtoadeniyiscores', '2.417');
INSERT INTO `funtoadeniyiscores` VALUES(6, '2016-02-21', 'Opted for Group Discussion', 'Group Discussion', 'Youths', 0, 12, '0.000', 'funtoadeniyiscores', '2.417');
INSERT INTO `funtoadeniyiscores` VALUES(7, '2016-03-13', 'Repositioning for Exploits', 'Review', 'Bishop David Oyedepo', 0, 12, '0.000', 'funtoadeniyiscores', '2.417');
INSERT INTO `funtoadeniyiscores` VALUES(8, '2016-03-27', '1John 4:4', 'Synonyms', 'Lanre Ibironke', 25, 12, '2.083', 'funtoadeniyiscores', '4.5');
INSERT INTO `funtoadeniyiscores` VALUES(9, '2016-04-03', 'Hand Sequence', 'Focus Test', 'Lanre Ibironke', 48, 12, '4.000', 'funtoadeniyiscores', '8.5');
INSERT INTO `funtoadeniyiscores` VALUES(10, '2016-04-10', 'Yesterday, Today and Tomorrow', 'Annotation and Silence Half Hour', 'Lanre Ibironke', 0, 12, '0.000', 'funtoadeniyiscores', '8.5');
INSERT INTO `funtoadeniyiscores` VALUES(11, '2016-04-17', 'Your Abilities', 'Annotation and Hand Sequence', 'Lanre Ibironke', 17, 12, '1.417', 'funtoadeniyiscores', '9.917');
INSERT INTO `funtoadeniyiscores` VALUES(12, '2016-04-24', 'Maximizing Your Most Valuable Asset', 'Home Work', 'Lanre Ibironke', 0, 12, '0.000', 'funtoadeniyiscores', '9.917');
INSERT INTO `funtoadeniyiscores` VALUES(13, '2016-05-01', 'Character Custodian of Destiny', 'Quiz', 'Bishop David Oyedepo', 12, 12, '1.000', 'funtoadeniyiscores', '10.917');
INSERT INTO `funtoadeniyiscores` VALUES(14, '2016-05-08', 'The Myth of Singleness', 'Questions', 'Dr Myles Munroe', 12, 12, '1.000', 'funtoadeniyiscores', '11.917');
INSERT INTO `funtoadeniyiscores` VALUES(15, '2016-05-15', 'Being Still (Psalms 46vs10)', 'Chicken on Egg Scenario', 'Lanre Ibironke', 7, 13, '0.538', 'funtoadeniyiscores', '12.455');
INSERT INTO `funtoadeniyiscores` VALUES(16, '2016-05-22', 'Selecting the Most Appropriate Word Replacement', 'Quiz', 'Lanre Ibironke', 35, 13, '2.692', 'funtoadeniyiscores', '15.147');
INSERT INTO `funtoadeniyiscores` VALUES(17, '2016-05-29', 'Personalizing Scripture', 'Theory Question', 'Lanre Ibironke', 5, 13, '0.385', 'funtoadeniyiscores', '15.532');
INSERT INTO `funtoadeniyiscores` VALUES(18, '2016-06-05', 'Inner Counsel', 'Annotation', 'Lanre Ibironke', 20, 13, '1.538', 'funtoadeniyiscores', '17.07');
INSERT INTO `funtoadeniyiscores` VALUES(19, '2016-06-12', 'Bible Questions', 'General Quiz', 'Lanre Ibironke', 39, 13, '3', 'funtoadeniyiscores', '20.07');
INSERT INTO `funtoadeniyiscores` VALUES(20, '2016-06-19', 'Marathon Question', 'General Quiz 2', 'Lanre Ibironke', 42, 13, '3.231', 'funtoadeniyiscores', '23.301');
INSERT INTO `funtoadeniyiscores` VALUES(21, '2016-06-26', 'Uzziah''s Story', 'Annotation', 'Lanre Ibironke', 0, 13, '0', 'funtoadeniyiscores', '23.301');
INSERT INTO `funtoadeniyiscores` VALUES(22, '2016-07-03', 'Multiple Choice', 'General Quiz 3', 'Lanre Ibironke', 31, 13, '2.385', 'funtoadeniyiscores', '25.686');
INSERT INTO `funtoadeniyiscores` VALUES(23, '2016-07-10', '4-Cards', 'Bible Game', 'Lanre Ibironke', 23, 13, '1.769', 'funtoadeniyiscores', '27.455');
INSERT INTO `funtoadeniyiscores` VALUES(24, '2016-07-24', 'Memory Test', 'Theory Questions', 'Lanre Ibironke', 0, 13, '0', 'funtoadeniyiscores', '27.455');
INSERT INTO `funtoadeniyiscores` VALUES(25, '2016-07-31', 'Scripture Expansion', 'Presentation', 'Lanre Ibironke', 35, 13, '2.692', 'funtoadeniyiscores', '30.147');
INSERT INTO `funtoadeniyiscores` VALUES(26, '2016-08-07', 'Multiple Choice', 'General Quiz 4', 'Lanre Ibironke', 47, 13, '3.615', 'funtoadeniyiscores', '33.762');
INSERT INTO `funtoadeniyiscores` VALUES(27, '2016-08-14', 'Tower of Hanoi & Marriage', 'Puzzle  & Annotation', 'Lanre Ibironke', 34, 13, '2.615', 'funtoadeniyiscores', '36.377');
INSERT INTO `funtoadeniyiscores` VALUES(28, '2016-08-21', 'The Innovative Demands of Leadership', 'Quiz 5', 'Myles Munroe', 0, 13, '0', 'funtoadeniyiscores', '36.377');
INSERT INTO `funtoadeniyiscores` VALUES(29, '2016-08-28', 'The Best Kept Secret', 'Quiz 6 & Annotation', 'Lanre Ibironke', 47, 13, '3.615', 'funtoadeniyiscores', '39.992');
INSERT INTO `funtoadeniyiscores` VALUES(30, '2016-09-04', 'Divine Secrets', 'Annotation', 'Lanre Ibironke', 59, 13, '4.538', 'funtoadeniyiscores', '44.53');
INSERT INTO `funtoadeniyiscores` VALUES(31, '2016-09-11', 'Repositioning for Exploits', 'Online Quiz', 'Bishop David Oyedepo', 39, 13, '3.003', 'funtoadeniyiscores', '47.533');
INSERT INTO `funtoadeniyiscores` VALUES(32, '2016-09-18', 'Kingdom Keys to Successful Relationships', 'Online Quiz', 'Myles Munroe', 151, 13, '11.627', 'funtoadeniyiscores', '59.16');
INSERT INTO `funtoadeniyiscores` VALUES(33, '2016-09-25', 'Heralding the Emergence of World Changers', 'Online Quiz', 'Bishop David Oyedepo', 180, 13, '13.86', 'funtoadeniyiscores', '73.02');
INSERT INTO `funtoadeniyiscores` VALUES(34, '2016-10-02', 'The Encounter', 'Online Quiz', 'Pure Flix Movie', 211, 13, '16.247', 'funtoadeniyiscores', '89.267');
INSERT INTO `funtoadeniyiscores` VALUES(35, '2016-10-09', 'The Ten Attitudes for Leadership Development', 'Online Quiz', 'Myles Munroe & David Oyedepo', 409, 13, '31.493', 'funtoadeniyiscores', '120.76');
INSERT INTO `funtoadeniyiscores` VALUES(36, '2016-10-16', 'What is Faith?', 'Online Quiz', 'David Oyedepo', 153, 13, '11.781', 'funtoadeniyiscores', '132.541');
INSERT INTO `funtoadeniyiscores` VALUES(37, '2016-11-13', 'Engaging Violent Faith for Supernatural Turnaround', 'Online Quiz', 'Bishop David Oyedepo', 368, 13, '28.336', 'funtoadeniyiscores', '160.877');
INSERT INTO `funtoadeniyiscores` VALUES(38, '2016-11-20', 'The Source of the Leadership Spirit', 'Online Quiz', 'Myles Munroe', 341, 13, '26.257', 'funtoadeniyiscores', '187.134');
INSERT INTO `funtoadeniyiscores` VALUES(39, '2016-12-11', 'The Stronghold of Faith', 'Online Quiz', 'Bishop David Oyedepo', 208, 13, '16.016', 'funtoadeniyiscores', '203.15');
INSERT INTO `funtoadeniyiscores` VALUES(40, '2016-12-18', 'How to Deal With Grief 1', 'Online Quiz', 'Andrew Wommack', 340, 13, '26.18', 'funtoadeniyiscores', '229.33');
INSERT INTO `funtoadeniyiscores` VALUES(41, '2016-12-25', 'How to Deal with Grief 2/4', 'Online Quiz', 'Andrew Wommack', 298, 13, '22.946', 'funtoadeniyiscores', '252.276');
INSERT INTO `funtoadeniyiscores` VALUES(42, '2017-01-08', 'Christmas Jubilee and Direction', 'Online Quiz', 'Myles Munroe', 395, 13, '30.415', 'funtoadeniyiscores', '282.691');
INSERT INTO `funtoadeniyiscores` VALUES(43, '2017-01-15', 'Life', 'Online Quiz', 'David Oyedepo', 660, 13, '50.82', 'funtoadeniyiscores', '333.511');
INSERT INTO `funtoadeniyiscores` VALUES(44, '2017-01-22', 'Eternal Life', 'Online Quiz', 'Andrew Wommack', 347, 13, '26.719', 'funtoadeniyiscores', '360.23');
INSERT INTO `funtoadeniyiscores` VALUES(45, '2017-01-29', 'The Holy Spirit', 'Online Quiz', 'Pastor Adeboye & Andrew Wommack', 118, 13, '9.086', 'funtoadeniyiscores', '369.316');
INSERT INTO `funtoadeniyiscores` VALUES(46, '2017-02-12', '7 Mistakes to avoid before marriage & End of the Harvest', 'Online Quiz', 'Pastor E.A. Adeboye & Christiano Film Group', 253, 13, '19.481', 'funtoadeniyiscores', '388.797');
INSERT INTO `funtoadeniyiscores` VALUES(47, '2017-02-19', 'Deepening your Relationship with God & 3 Types of Friends', 'Online Quiz', 'TD Jakes', 282, 13, '21.714', 'funtoadeniyiscores', '410.511');
INSERT INTO `funtoadeniyiscores` VALUES(48, '2017-03-05', 'Spirituality the Master Key to a World of Exploits', 'Online Quiz', 'Bishop David Oyedepo', 496, 13, '38.192', 'funtoadeniyiscores', '448.703');
INSERT INTO `funtoadeniyiscores` VALUES(49, '2017-03-19', 'Life 2', 'Online Quiz', 'Bishop David Oyedepo', 59, 13, '4.543', 'funtoadeniyiscores', '453.246');
INSERT INTO `funtoadeniyiscores` VALUES(50, '2017-04-09', 'God\\''s Love (Love Series 3)', 'Online Quiz', 'Andrew Wommack', 40, 13, '3.08', 'funtoadeniyiscores', '456.326');
INSERT INTO `funtoadeniyiscores` VALUES(51, '2017-04-23', 'The Power of Spiritual Depth', 'Online Quiz', 'Bishop David Oyedepo', 39, 13, '3.003', 'funtoadeniyiscores', '459.329');
INSERT INTO `funtoadeniyiscores` VALUES(52, '2017-04-28', 'The Last Reformation(30:27-The End){Birthday May 14}', 'Online Quiz', 'Akatio Films', 260, 14, '20.02', 'funtoadeniyiscores', '479.349');
INSERT INTO `funtoadeniyiscores` VALUES(53, '2017-05-12', 'Drive Through History Holy Land 1', 'Online Quiz', 'Myles Munroe', 77, 14, '5.495', 'funtoadeniyiscores', '484.844');

-- --------------------------------------------------------

--
-- Table structure for table `hannahojoscores`
--

CREATE TABLE `hannahojoscores` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `exercise` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `source` varchar(200) NOT NULL,
  `score` mediumint(9) NOT NULL,
  `currentage` mediumint(9) NOT NULL,
  `aggregate` varchar(200) NOT NULL,
  `tableName` varchar(50) NOT NULL DEFAULT 'hannahojoscores',
  `currentTotalAggregate` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=34 ;

--
-- Dumping data for table `hannahojoscores`
--

INSERT INTO `hannahojoscores` VALUES(1, '2016-10-16', 'Joined', 'Online Quiz', 'David Oyedepo', 211, 18, '11.722', 'hannahojoscores', '11.722');
INSERT INTO `hannahojoscores` VALUES(2, '2016-10-23', 'What is Faith?', 'Online Quiz', 'David Oyedepo', 561, 18, '31.2', 'hannahojoscores', '42.922');
INSERT INTO `hannahojoscores` VALUES(3, '2016-10-30', 'Engaging the Armour of Light for Total Deliverance', 'Online Quiz', 'David Oyedepo', 555, 18, '30.864', 'hannahojoscores', '73.786');
INSERT INTO `hannahojoscores` VALUES(4, '2016-11-06', 'Vital Keys to Achieving Your Vision', 'Online Quiz', 'Myles Munroe', 890, 18, '49.488', 'hannahojoscores', '123.274');
INSERT INTO `hannahojoscores` VALUES(5, '2016-11-13', 'Engaging Violent Faith for Supernatural Turnaround', 'Online Quiz', 'Bishop David Oyedepo', 534, 18, '29.698', 'hannahojoscores', '152.972');
INSERT INTO `hannahojoscores` VALUES(6, '2016-11-20', 'The Source of the Leadership Spirit', 'Online Quiz', 'Myles Munroe', 617, 18, '34.31', 'hannahojoscores', '187.282');
INSERT INTO `hannahojoscores` VALUES(7, '2016-11-27', 'How to Excel in Your Field', 'Online Quiz', 'Bishop David Oyedepo', 485, 18, '26.968', 'hannahojoscores', '214.25');
INSERT INTO `hannahojoscores` VALUES(8, '2016-12-18', 'How to Deal With Grief 1', 'Online Quiz', 'Andrew Wommack', 416, 18, '23.136', 'hannahojoscores', '237.386');
INSERT INTO `hannahojoscores` VALUES(9, '2016-12-25', 'How to Deal with Grief 2/4', 'Online Quiz', 'Andrew Wommack', 558, 18, '31.028', 'hannahojoscores', '268.414');
INSERT INTO `hannahojoscores` VALUES(10, '2017-01-15', 'Life', 'Online Quiz', 'David Oyedepo', 202, 18, '11.244', 'hannahojoscores', '279.658');
INSERT INTO `hannahojoscores` VALUES(11, '2017-01-22', 'Eternal Life', 'Online Quiz', 'Andrew Wommack', 511, 18, '28.414', 'hannahojoscores', '308.072');
INSERT INTO `hannahojoscores` VALUES(12, '2017-01-29', 'The Holy Spirit', 'Online Quiz', 'Pastor Adeboye & Andrew Wommack', 454, 18, '25.246', 'hannahojoscores', '333.318');
INSERT INTO `hannahojoscores` VALUES(13, '2017-02-05', 'God''s Kind of Love to You', 'Online Quiz', 'Andrew Wommack', 529, 18, '29.426', 'hannahojoscores', '362.744');
INSERT INTO `hannahojoscores` VALUES(14, '2017-02-19', 'Deepening your Relationship with God & 3 Types of Friends', 'Online Quiz', 'TD Jakes', 486, 18, '27.024', 'hannahojoscores', '389.768');
INSERT INTO `hannahojoscores` VALUES(15, '2017-02-26', 'Ultimate Myles Munroe 2016 Collection', 'Online Quiz', 'Myles Munroe', 1165, 18, '64.776', 'hannahojoscores', '454.544');
INSERT INTO `hannahojoscores` VALUES(16, '2017-03-05', 'Spirituality the Master Key to a World of Exploits', 'Online Quiz', 'Bishop David Oyedepo', 736, 18, '40.936', 'hannahojoscores', '495.48');
INSERT INTO `hannahojoscores` VALUES(17, '2017-03-12', 'The Kingdom Power of Self Government', 'Online Quiz', 'Myles Munroe', 771, 18, '42.87', 'hannahojoscores', '538.35');
INSERT INTO `hannahojoscores` VALUES(18, '2017-03-19', 'The Kingdom Power of Self Government', 'Online Quiz', 'Myles Munroe', 678, 18, '37.704', 'hannahojoscores', '576.054');
INSERT INTO `hannahojoscores` VALUES(19, '2017-03-26', 'Marriage Prep 101', 'Online Quiz', 'Myles Munroe', 1122, 18, '62.386', 'hannahojoscores', '638.44');
INSERT INTO `hannahojoscores` VALUES(20, '2017-04-02', 'Salvation Testimony', 'Online Quiz', 'Kenneth Erwin Hagin', 758, 18, '42.152', 'hannahojoscores', '680.592');
INSERT INTO `hannahojoscores` VALUES(21, '2017-04-09', 'God\\''s Love (Love Series 3)', 'Online Quiz', 'Andrew Wommack', 1048, 18, '58.278', 'hannahojoscores', '738.87');
INSERT INTO `hannahojoscores` VALUES(32, '2017-05-12', 'Drive Through History Holy Land 1', 'Online Quiz', 'Myles Munroe', 1616, 19, '85.016', 'hannahojoscores', '1119.815');
INSERT INTO `hannahojoscores` VALUES(23, '2017-04-15', 'The Last Reformation(0:00-30:27)', 'Online Quiz', 'Akatio Films', 982, 18, '54.604', 'hannahojoscores', '793.474');
INSERT INTO `hannahojoscores` VALUES(30, '2017-04-28', 'The Last Reformation(30:27-The End)', 'Online Quiz', 'Akatio Films', 1599, 19, '84.117', 'hannahojoscores', '986.079');
INSERT INTO `hannahojoscores` VALUES(25, '2017-04-22', 'The Power of Spiritual Depth (Birthday Apr 24)', 'Online Quiz', 'Bishop David Oyedepo', 1951, 19, '108.488', 'hannahojoscores', '901.962');
INSERT INTO `hannahojoscores` VALUES(31, '2017-05-05', 'The Principles of Creation', 'Online Quiz', 'Myles Munroe', 926, 19, '48.72', 'hannahojoscores', '1034.799');
INSERT INTO `hannahojoscores` VALUES(33, '2017-05-19', 'How to Walk in Confidence', 'Online Quiz', 'Myles Munroe', 1581, 19, '83.197', 'hannahojoscores', '1203.012');

-- --------------------------------------------------------

--
-- Table structure for table `messagematerials`
--

CREATE TABLE `messagematerials` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `type` varchar(50) NOT NULL,
  `author` varchar(50) NOT NULL,
  `link` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `messagematerials`
--

INSERT INTO `messagematerials` VALUES(1, 'The Best Kept Secret', 'Camp Meeting', 'Myles Munroe', 'YouTube');

-- --------------------------------------------------------

--
-- Table structure for table `messagequestions`
--

CREATE TABLE `messagequestions` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `question` varchar(3000) NOT NULL,
  `type` varchar(50) NOT NULL,
  `options` varchar(300) NOT NULL,
  `answers` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5376 ;

--
-- Dumping data for table `messagequestions`
--

INSERT INTO `messagequestions` VALUES(5189, 'The most important thing in life on earth is to make ______', 'Single Answer', 'money,it to our future,people', 'it to our future');
INSERT INTO `messagequestions` VALUES(5190, 'The race to our future is a ______ not a _______', 'Single Answer', 'sprint-marathon,marathon-sprint,marathon-dash', 'marathon-sprint');
INSERT INTO `messagequestions` VALUES(5191, 'God designed our lives to be lived quickly. True or False?', 'Single Answer', 'True,False', 'False');
INSERT INTO `messagequestions` VALUES(5192, '... we go through different _____ in a marathon', 'Single Answer', 'changes,stages', 'changes');
INSERT INTO `messagequestions` VALUES(5193, 'we start out feeling very good, _______', 'Single Answer', 'adrenalined,excited,elated', 'excited');
INSERT INTO `messagequestions` VALUES(5194, 'we feel strong and there''s a time in the marathon when our body begins to tell us ______', 'Single Answer', 'quit this,forget this', 'forget this');
INSERT INTO `messagequestions` VALUES(5195, 'and then if we fight the forget this phase, then our body kicks in some ______', 'Single Answer', 'impulse,juice,adrenaline', 'adrenaline');
INSERT INTO `messagequestions` VALUES(5196, 'and our body starts saying, don''t ______...', 'Single Answer', 'stop now,you stop now', 'you stop now');
INSERT INTO `messagequestions` VALUES(5197, 'and our body picks up this ______ that we don''t know where it comes from...', 'Single Answer', 'strength,energy', 'energy');
INSERT INTO `messagequestions` VALUES(5198, 'and it begins to ____ again.', 'Single Answer', 'move,run', 'run');
INSERT INTO `messagequestions` VALUES(5199, 'and we feel good... then we get to a point where our muscles begin to feel like they''re going to ____ out of our body', 'Single Answer', 'burn,come', 'burn');
INSERT INTO `messagequestions` VALUES(5200, 'and our body begins to tell us, if we don''t stop, it''s going to ________', 'Single Answer', 'disintegrate,fall apart', 'fall apart');
INSERT INTO `messagequestions` VALUES(5201, '...after we break that fall apart _____, we kick in to another ______ where our body actually begins to take us now rather than we take it', 'Single Answer', 'phase,stage', 'phase');
INSERT INTO `messagequestions` VALUES(5202, 'and we run without ______, without pain', 'Single Answer', 'effort,stress', 'stress');
INSERT INTO `messagequestions` VALUES(5203, 'in other words there''s a period in our life where we ______, where our body takes us and we find it very easy to run forever', 'Single Answer', 'enter,kick in', 'kick in');
INSERT INTO `messagequestions` VALUES(5204, 'I did that a few times in my life. I ran over _____ miles in one single run', 'Single Answer', '20,28,25', '28');
INSERT INTO `messagequestions` VALUES(5205, 'and I remember as a young man, when that thing kicked in, I felt ______ when I stopped running', 'Single Answer', 'bad,tired,discouraged', 'bad');
INSERT INTO `messagequestions` VALUES(5206, '...and that''s what God wants us to do. He wants us to live long enough, and live in ______ long enough...', 'Single Answer', 'our vision,His purpose,His will', 'our vision');
INSERT INTO `messagequestions` VALUES(5207, '... and go through the changes long enough, until we get to a point where there''s no _______ back now.', 'Single Answer', 'going,turning', 'turning');
INSERT INTO `messagequestions` VALUES(5208, '<strong>I have seen something else under the sun: The race is not to the swift or the battle to the strong.</strong> What bible verse is this?', 'Single Answer', 'Ecclesiastes 7:11,Ecclesiastis 9:11,Ecclesiastes 9:11', 'Ecclesiastes 9:11');
INSERT INTO `messagequestions` VALUES(5209, 'The race of life is to _____', 'Single Answer', 'the strong,the swift,the steady,he who endures to the end', 'he who endures to the end');
INSERT INTO `messagequestions` VALUES(5210, 'Life is not about beginning things, life is about finishing things. True or False?', 'Single Answer', 'True,False', 'True');
INSERT INTO `messagequestions` VALUES(5211, 'I''ve been doing what I''m doing for about ____ years', 'Single Answer', '30,39,40', '39');
INSERT INTO `messagequestions` VALUES(5212, 'God is going to measure our faithfulness by ______', 'Single Answer', 'starting,finishing,enduring', 'finishing');
INSERT INTO `messagequestions` VALUES(5213, 'A lot of people can do a ______', 'Single Answer', 'sprint,mad dash,dash', 'mad dash');
INSERT INTO `messagequestions` VALUES(5214, 'Excitement is adrenaline. How true that is. Applying it to a relationship. A man sees a young woman, he gets excited about her and thinks she must be his God ordained spouse. If he evaluates his motives properly, he probably got excited about her because of her physical beauty and that''s selfish. A woman is supposed to connect with the man spiritually first before physical attraction. The spiritual connector of a man and woman is God''s purpose for the man''s life. What bible verse says this?', 'Single Answer', 'Genesis 2:17,Genesis 2:18,Genesis 2:19', 'Genesis 2:18');
INSERT INTO `messagequestions` VALUES(5215, 'Genesis 2:18 And the LORD God said, It is not good that the man should be alone; I will make him an <strong>help meet</strong> for him. Help meet to help the man do what God told him to do. True or False?', 'Single Answer', 'True,False', 'True');
INSERT INTO `messagequestions` VALUES(5216, 'The key to life is being committed for life. True or False?', 'Single Answer', 'True,False', 'True');
INSERT INTO `messagequestions` VALUES(5217, 'God cannot _______ a person who He cannot find.', 'Single Answer', 'depend on,trust,rely on', 'trust');
INSERT INTO `messagequestions` VALUES(5218, 'Life is about what ______ said to me years ago', 'Single Answer', 'Paula White,Corrie ten Boom,Hilary Clinton', 'Corrie ten Boom');
INSERT INTO `messagequestions` VALUES(5219, 'the great woman who wrote that book _______', 'Single Answer', 'God''s Tramp,God''s Hiding Place', 'God''s Tramp');
INSERT INTO `messagequestions` VALUES(5220, 'she said to me, son _____ where you are planted.', 'Single Answer', 'grow,develop,stay', 'grow');
INSERT INTO `messagequestions` VALUES(5221, 'We never can grow fruit if you keep uprooting the plant. True or False?', 'Single Answer', 'True,False', 'True');
INSERT INTO `messagequestions` VALUES(5222, 'We''ve got to stay one place long enough for God to give us some good ______...', 'Single Answer', 'nourishment,growth,fertilizer', 'fertilizer');
INSERT INTO `messagequestions` VALUES(5223, 'To make it into our future we''ve got to lock in for ______.', 'Single Answer', 'life,good', 'life');
INSERT INTO `messagequestions` VALUES(5224, 'God will trust a man who He can _______', 'Single Answer', 'find,depend on,rely on', 'depend on');
INSERT INTO `messagequestions` VALUES(5225, 'A lot of folks are dreaming big, but they aren''t working ______', 'Single Answer', 'hard,smart,long', 'long');
INSERT INTO `messagequestions` VALUES(5226, 'they allow their ______ to outpace their ______ in God', 'Single Answer', 'passion-faith,passion-pace,passion-patience', 'passion-patience');
INSERT INTO `messagequestions` VALUES(5227, 'I''m not looking for anything in life except to serve God and obey Him ______', 'Single Answer', 'always,everyday', 'everyday');
INSERT INTO `messagequestions` VALUES(5228, '<strong>When we are faithful over little things, God will make us ruler over big things.</strong> Where in the bible can this be found?', 'Single Answer', 'Matthew 25:21,Matthew 25:23,Luke 19:17,all of the above', 'all of the above');
INSERT INTO `messagequestions` VALUES(5229, 'Our success determines God''s success. True or False?', 'Single Answer', 'True,False', 'True');
INSERT INTO `messagequestions` VALUES(5230, 'God has to make sure we succeed, because His reputation is on the line. True or False?', 'Single Answer', 'True,False', 'True');
INSERT INTO `messagequestions` VALUES(5231, 'God created us just like a ______ makes a product', 'Single Answer', 'producer,manufacturer', 'manufacturer');
INSERT INTO `messagequestions` VALUES(5232, 'and God made us for a ______ a ______', 'Single Answer', 'purpose-reason,reason-purpose', 'reason-purpose');
INSERT INTO `messagequestions` VALUES(5233, 'the manufacturer places in the product box a ______', 'Single Answer', 'todo list,manual', 'manual');
INSERT INTO `messagequestions` VALUES(5234, 'the manual has in it how to operate the product. The manual for the Good news of salvation (God''s product) is the bible. True or False?', 'Single Answer', 'True,False', 'True');
INSERT INTO `messagequestions` VALUES(5235, 'The manual also has in it, two things we forget about sometimes. One, it has a ______ and then it has a _______', 'Single Answer', 'guarantee-warranty,warranty-guarantee', 'warranty-guarantee');
INSERT INTO `messagequestions` VALUES(5236, 'The warranty of the bible corresponds to our connection to God, that''s the _______ experience', 'Single Answer', 'salvation,born-again,all of the above', 'all of the above');
INSERT INTO `messagequestions` VALUES(5237, 'The guarantee of the bible corresponds to God''s _______', 'Single Answer', 'promises,covenant,all of the above', 'all of the above');
INSERT INTO `messagequestions` VALUES(5238, '<strong>I will bless you for my name sake.</strong> Where in the bible can this be found?', 'Single Answer', 'Ezekiel 36:22,Ezekiel 36:16,Ezekiel 36:13', 'Ezekiel 36:22');
INSERT INTO `messagequestions` VALUES(5239, '<strong>Name sake</strong> is a Hebrew term which means ______', 'Single Answer', 'glory,splendor,reputation', 'reputation');
INSERT INTO `messagequestions` VALUES(5240, 'God already told _____ who we are.', 'Single Answer', 'satan,the devil', 'the devil');
INSERT INTO `messagequestions` VALUES(5241, '<strong>We were in God before the world began.</strong> What bible verse is this?', 'Single Answer', 'Ephesians 1:4,1Peter 1:20,all of the above', 'all of the above');
INSERT INTO `messagequestions` VALUES(5242, 'The devil knows what God says we''re supposed to become. True or False?', 'Single Answer', 'True,False', 'True');
INSERT INTO `messagequestions` VALUES(5243, 'Whatever we go through, God has to make sure we ______ through', 'Single Answer', 'pass,come', 'come');
INSERT INTO `messagequestions` VALUES(5244, 'Does it happen automatically?', 'Single Answer', 'Yes,No', 'No');
INSERT INTO `messagequestions` VALUES(5245, 'It doesn''t happen automatically because we have to ______ this for it to happen', 'Single Answer', 'know,believe', 'believe');
INSERT INTO `messagequestions` VALUES(5246, 'because we might be in a situation where nothing seems to be working. God is saying, that''s okay. Once we know that we cannot die in this situation, then we''ll have the right _______', 'Single Answer', 'mindset,perspective,attitude', 'attitude');
INSERT INTO `messagequestions` VALUES(5247, 'Whatever we are in, we have to ________ for His Name sake.', 'Single Answer', 'pass through,come out', 'come out');
INSERT INTO `messagequestions` VALUES(5248, 'Putting the man together, putting the _____ together', 'Single Answer', 'family,nation,world', 'world');
INSERT INTO `messagequestions` VALUES(5249, 'The boy put the torn map of the world together by _______', 'Single Answer', 'arranging it carefully,putting the man together', 'putting the man together');
INSERT INTO `messagequestions` VALUES(5250, 'the boy said to his father, I just put the man together. And when I put the man together the world _______', 'Single Answer', 'arranged itself,came together', 'came together');
INSERT INTO `messagequestions` VALUES(5251, 'Is God trying to put the world together?', 'Single Answer', 'Yes,No', 'No');
INSERT INTO `messagequestions` VALUES(5252, 'God isn''t trying to put the world together. He wants to get us together, if He can get us together, then the world will be okay. True or False?', 'Single Answer', 'True,False', 'True');
INSERT INTO `messagequestions` VALUES(5253, 'Which of the following is more important: a job, a work, a reason for waking up', 'Single Answer', 'a job,a work,a purpose', 'a purpose');
INSERT INTO `messagequestions` VALUES(5254, '<strong> In Him we were also chosen, having been predestined according to the plan of Him who works out everything in conformity with the purpose of His will.</strong> What bible verse is this', 'Single Answer', 'Ephesians 1:11-12,Ephesians 1:11', 'Ephesians 1:11');
INSERT INTO `messagequestions` VALUES(5255, 'Even when we mess up and make a mistake, God will turn our mistake into a _______', 'Single Answer', 'blessing,miracle,testimony', 'miracle');
INSERT INTO `messagequestions` VALUES(5256, 'The natural reaction of a believer that goes into sin is to stay away from church. True or False?', 'Single Answer', 'True,False', 'True');
INSERT INTO `messagequestions` VALUES(5257, 'In spite the natural reaction, if we ever make a mistake, we should keep coming to church. True or False?', 'Single Answer', 'True,False', 'True');
INSERT INTO `messagequestions` VALUES(5258, 'Some of the greatest people in the history of life have a bad ______', 'Single Answer', 'history,past,story', 'history');
INSERT INTO `messagequestions` VALUES(5259, 'the first 5 books of the bible was written by _____', 'Single Answer', 'an adulterer,a murderer,a liar', 'a murderer');
INSERT INTO `messagequestions` VALUES(5260, 'the first 5 books of the bible was written by murderer. This is because <strong>God has chosen the foolish things of the world to confound the wise</strong>. What bible verse is this?', 'Single Answer', 'Romans 8:1,John 3:16,1Corinthians 1:27', '1Corinthians 1:27');
INSERT INTO `messagequestions` VALUES(5261, 'Our failure doesn''t cancel our assignment because of ______', 'Single Answer', 'Romans 8:2,Proverbs 20:27,Romans 11:29', 'Romans 11:29');
INSERT INTO `messagequestions` VALUES(5262, '<strong>For the gifts and calling of God are without repentance</strong>. It means God doesn''t change His mind. True or False?', 'Single Answer', 'True,False', 'True');
INSERT INTO `messagequestions` VALUES(5263, 'What we are born to do is more powerful than what we have done because what we are born to do is what keeps us alive. If what we''ve done is more powerful that what we are yet to do, there won''t be need for us in the earth. True or False?', 'Single Answer', 'True,False', 'True');
INSERT INTO `messagequestions` VALUES(5264, 'God is an expert in failure. He knows what to do with it. He turns it into a ______', 'Single Answer', 'miracle,testimony,blessing', 'testimony');
INSERT INTO `messagequestions` VALUES(5265, '_______ whom you see on television was a rape baby.', 'Single Answer', 'James Robinson,Benny Hinn,James Robison', 'James Robison');
INSERT INTO `messagequestions` VALUES(5266, 'Don''t you ever allow your _______ to rob you of your ______', 'Single Answer', 'shame-uplift,mess-fame,shame-fame', 'shame-fame');
INSERT INTO `messagequestions` VALUES(5267, 'the key to the whole thing is for us to _______', 'Single Answer', 'return to God,come back to God', 'come back to God');
INSERT INTO `messagequestions` VALUES(5268, '<strong>And we know that all things work together for good to them that love God, to them who are the called according to his purpose.</strong> What bible verse is this?', 'Single Answer', 'Romans 8:28-29,Romans 8:28,Romans 8:29', 'Romans 8:28');
INSERT INTO `messagequestions` VALUES(5269, '<strong>For whom he did foreknow, he also did predestinate to be conformed to the image of his Son, that he might be the firstborn among many brethren.</strong> What bible verse is this?', 'Single Answer', 'Romans 8:28,Romans 8:29,Romans 8:28-29', 'Romans 8:28');
INSERT INTO `messagequestions` VALUES(5270, 'the implication is, we are family not ______', 'Single Answer', 'slaves,servants,messengers', 'slaves');
INSERT INTO `messagequestions` VALUES(5271, 'We were created to live and be just like God. True or False?', 'Single Answer', 'True,False', 'True');
INSERT INTO `messagequestions` VALUES(5272, '<strong>I am a sinner saved by grace.</strong> Is this a true statement?', 'Single Answer', 'Yes,No', 'No');
INSERT INTO `messagequestions` VALUES(5273, 'We aren''t a sinner anymore. We used to be sinners, but when we received Christ at salvation, God made us <strong>righteous and truly holy.</strong> What bible verse proves this?', 'Single Answer', 'Ephesians 1:2,Ephesians 2:2,Ephesians 4:24', 'Ephesians 4:24');
INSERT INTO `messagequestions` VALUES(5274, 'We may still sin because our mind must be renewed to what God has done in our spirit. When that happens we''ll live holy automatically because our body follows the direction of our mind. True or False?', 'Single Answer', 'True,False', 'True');
INSERT INTO `messagequestions` VALUES(5275, 'Living holy is not a matter of not doing this, not doing that. Living holy is a matter of is that ______', 'Single Answer', 'appropriate,worthy of me doing,reflective of royalty', 'worthy of me doing');
INSERT INTO `messagequestions` VALUES(5276, 'Kingdom living is there are certain things _____ don''t do', 'Single Answer', 'royalty,queens,kings,all of the above', 'all of the above');
INSERT INTO `messagequestions` VALUES(5277, 'our _____ is to be just like God.', 'Single Answer', 'goal,destination,destiny', 'destination');
INSERT INTO `messagequestions` VALUES(5278, 'How do we walk into this confidence? #1 is we have to ________', 'Single Answer', 'have a goal,have a job,have knowledge of our purpose', 'have knowledge of our purpose');
INSERT INTO `messagequestions` VALUES(5279, 'Does our training automatically correspond to our passion?', 'Single Answer', 'Yes,No', 'No');
INSERT INTO `messagequestions` VALUES(5280, 'How do we walk into this confidence? #2 is we have to know our _______', 'Single Answer', 'ability,capacity,potential', 'potential');
INSERT INTO `messagequestions` VALUES(5281, 'Our capability = our __________', 'Single Answer', 'responsibility,assignment', 'assignment');
INSERT INTO `messagequestions` VALUES(5282, 'Do birds attend flight school?', 'Single Answer', 'Yes,No', 'No');
INSERT INTO `messagequestions` VALUES(5283, 'once you''ve discovered your ______, you''ve also discovered your ability.', 'Single Answer', 'gift,assignment,gift & assignment', 'gift & assignment');
INSERT INTO `messagequestions` VALUES(5284, 'How do we walk into this confidence? #3 is we have to know our _______', 'Single Answer', 'purpose,calling,resources', 'resources');
INSERT INTO `messagequestions` VALUES(5285, 'first, our resources include a lot of things like ______', 'Single Answer', 'money,family,our brain', 'our brain');
INSERT INTO `messagequestions` VALUES(5286, 'the Word of God _______ forever', 'Single Answer', 'remains,lasts,endures,all of the above', 'all of the above');
INSERT INTO `messagequestions` VALUES(5287, 'How do we walk into this confidence? #4 is we have to know our _______', 'Single Answer', 'source,resource,family', 'source');
INSERT INTO `messagequestions` VALUES(5288, 'Do we need people to get ahead?', 'Single Answer', 'Yes,No', 'No');
INSERT INTO `messagequestions` VALUES(5289, 'We don''t need people, we need God because He is our source. True or False?', 'Single Answer', 'True,False', 'True');
INSERT INTO `messagequestions` VALUES(5290, '<strong>Promotion doesn''t come from the east, nor from the west, nor from the south. But God is the judge: he puts down one, and sets up another.</strong> What part of the bible says this?', 'Single Answer', 'Psalms 75:6,Psalms 75:7,Psalms 75:6-7', 'Psalms 75:6-7');
INSERT INTO `messagequestions` VALUES(5291, '<strong>God knows where the secret riches of darkness lie.</strong> What bible verse is this?', 'Single Answer', 'Isaiah 45:1,Jeremiah 28:1,Isaiah 45:3', 'Isaiah 45:3');
INSERT INTO `messagequestions` VALUES(5292, 'How do we walk into this confidence? #5 is we have to know our _______', 'Single Answer', 'source,value,worth', 'value');
INSERT INTO `messagequestions` VALUES(5293, 'Attitude comes from ________', 'Single Answer', 'insight,revelation,personal revelation', 'personal revelation');
INSERT INTO `messagequestions` VALUES(5294, 'Does where we are change who we are?', 'Single Answer', 'Yes,No', 'No');
INSERT INTO `messagequestions` VALUES(5295, 'Do you need to be approved by other people to be important?', 'Single Answer', 'Yes,No', 'No');
INSERT INTO `messagequestions` VALUES(5296, 'We are important because God made us important. True or False?', 'Single Answer', 'True,False', 'True');
INSERT INTO `messagequestions` VALUES(5297, 'How do we walk into this confidence? #6 is we have to know our _______', 'Single Answer', 'responsibility,ability,resource', 'ability');
INSERT INTO `messagequestions` VALUES(5298, 'We must know we are our own _______', 'Single Answer', 'resource,raw material', 'raw material');
INSERT INTO `messagequestions` VALUES(5299, 'We came to earth _______', 'Single Answer', 'equipped,packaged,complete', 'packaged');
INSERT INTO `messagequestions` VALUES(5300, 'We came to earth with everything we need for the rest our lives. Therefore there''s no need running around. If we''ll be still, we''ll <strong>realize amazing things God has put inside us. Once we realize it, it''ll be easy to live it</strong>. What bible verse proves this?', 'Single Answer', 'Jude 1:4,Philemon 1:6,Philemon 1:9', 'Philemon 1:6');
INSERT INTO `messagequestions` VALUES(5301, 'How do we walk into this confidence? #7 is we have to know our _______', 'Single Answer', 'value,wholeness,uniqueness', 'uniqueness');
INSERT INTO `messagequestions` VALUES(5302, 'Knowledge of our uniqueness separates us from everyone else. True or False?', 'Single Answer', 'True,False', 'True');
INSERT INTO `messagequestions` VALUES(5303, 'Is imitating people good?', 'Single Answer', 'Yes,No', 'No');
INSERT INTO `messagequestions` VALUES(5304, 'When we have discovered ourselves, everybody tries to imitate us, because we only imitate ________', 'Single Answer', 'something unique,an original', 'an original');
INSERT INTO `messagequestions` VALUES(5305, 'confidence is uniqueness. The most important word on this list is _______', 'Single Answer', 'insight,knowledge,revelation', 'knowledge');
INSERT INTO `messagequestions` VALUES(5306, 'We have to know it, otherwise we become victims of other people''s opinions. True or False?', 'Single Answer', 'True,False', 'True');
INSERT INTO `messagequestions` VALUES(5307, 'How do we walk into this confidence? #8 is we have to know our _______', 'Single Answer', 'destiny,destination,predestination', 'predestination');
INSERT INTO `messagequestions` VALUES(5308, 'our future is God''s _______', 'Single Answer', 'future,past', 'past');
INSERT INTO `messagequestions` VALUES(5309, '<strong>This command have I received from My Father, that if I lay my life down I will pick it up again.</strong> What bible verse is this?', 'Single Answer', 'John 10:13,John 10:15,John 10:18', 'John 10:18');
INSERT INTO `messagequestions` VALUES(5310, 'Getting the result before the process is called _______', 'Single Answer', 'destination,predestination,foreordain,last two options,all of the above', 'last two options');
INSERT INTO `messagequestions` VALUES(5311, 'We can be quiet when we are confident, because <strong>in quietness and confidence shall be our strength.</strong> What bible verse is this?', 'Single Answer', 'Isaiah 30,Isaiah 30:1,Isaiah 30:15', 'Isaiah 30:15');
INSERT INTO `messagequestions` VALUES(5312, 'Do predictions affect the saints?', 'Single Answer', 'Yes,No', 'No');
INSERT INTO `messagequestions` VALUES(5313, 'If the saints are plugged in to the <strong>news, sitcoms and soap operas</strong> and have all their attention on them will their predictions affect them?', 'Single Answer', 'Yes,No', 'Yes');
INSERT INTO `messagequestions` VALUES(5314, 'Yes they will because <strong>perfect peace only comes when our minds or attention are focused and stayed on God and kept away from the news, sitcoms and soap operas.</strong> What bible verse confirms this?', 'Single Answer', 'Isaiah 26:4,Isaiah 26:5,Isaiah 26:3', 'Isaiah 26:3');
INSERT INTO `messagequestions` VALUES(5315, '<strong>No good thing will I withhold from my folks who walk uprightly.</strong> What bible verse is this?', 'Single Answer', 'Psalms 84:7,Psalms 84:9,Psalms 84:11', 'Psalms 84:11');
INSERT INTO `messagequestions` VALUES(5316, 'How do we walk into this confidence? #9 is we have to know our _______', 'Single Answer', 'provision,security,protection,last two options', 'last two options');
INSERT INTO `messagequestions` VALUES(5317, '<strong>The LORD will perfect that which concerns me:</strong> The word <strong>perfect</strong> means ______', 'Single Answer', 'keep,complete', 'keep');
INSERT INTO `messagequestions` VALUES(5318, 'As members of the kingdom of God, do we have a normal business?', 'Single Answer', 'Yes,No', 'No');
INSERT INTO `messagequestions` VALUES(5319, 'God will protect us right in the middle of chaos. True or False?', 'Single Answer', 'True,False', 'True');
INSERT INTO `messagequestions` VALUES(5320, 'The Lord says, no matter how difficult it seems right now to what we''ve been going through for the last couple of years and even now, that cannot last because that is not His ______ word to us.', 'Single Answer', 'final,last', 'last');
INSERT INTO `messagequestions` VALUES(5321, 'The reason it is taking long is not because He is holding it back from us but because He is preparing us for it. True or False?', 'Single Answer', 'True,False', 'True');
INSERT INTO `messagequestions` VALUES(5322, 'How do we walk into this confidence? #10 is we have to know our _______', 'Single Answer', 'company,Creator,Source', 'Creator');
INSERT INTO `messagequestions` VALUES(5323, 'What measures our value and quality is _______', 'Single Answer', 'how we look,where we came from', 'where we came from');
INSERT INTO `messagequestions` VALUES(5324, 'We are a product of ________ international', 'Single Answer', 'Adonai,Yahweh,Elohim', 'Elohim');
INSERT INTO `messagequestions` VALUES(5325, '<strong>For you have been my hope, O Sovereign LORD, my confidence since my youth</strong> What bible verse is this?', 'Single Answer', 'Psalms 71:5,Psalms 71:6,Psalms 71:5-6', 'Psalms 71:5');
INSERT INTO `messagequestions` VALUES(5326, '<strong>The fruit of righteousness will be peace; the effect of righteousness will be quietness and confidence forever.</strong> What bible verse is this?', 'Single Answer', 'Isaiah 32:16,Isaiah 32:17,Isaiah 32:18', 'Isaiah 32:17');
INSERT INTO `messagequestions` VALUES(5327, 'When we are lined up correctly with God, we have _______', 'Single Answer', 'confidence,quietness,quiet confidence', 'quiet confidence');
INSERT INTO `messagequestions` VALUES(5328, 'Can anyone stop our future?', 'Single Answer', 'Yes,No', 'No');
INSERT INTO `messagequestions` VALUES(5329, '<strong>So do not throw away your confidence;\n it will be richly rewarded.</strong> What bible verse is this?', 'Single Answer', 'Hebrews 10:15,Hebrews 10:35,Hebrews 10:36', 'Hebrews 10:35');
INSERT INTO `messagequestions` VALUES(5330, '<strong>We need to persevere so that when we have done the will of God, we will receive what He has promised.</strong> The word persevere means ________', 'Single Answer', 'endure,believe,all of the above', 'endure');
INSERT INTO `messagequestions` VALUES(5331, 'Can anyone stop what God has finished?', 'Single Answer', 'Yes,No', 'No');
INSERT INTO `messagequestions` VALUES(5332, 'When ever insecurity meets confidence, it calls it _______', 'Single Answer', 'pride,arrogance', 'arrogance');
INSERT INTO `messagequestions` VALUES(5333, '<strong>Beelzebub</strong>, another name for the devil means lord of ______', 'Single Answer', 'goats,pigs,flies', 'flies');
INSERT INTO `messagequestions` VALUES(5334, 'Beelzebub, another name for the devil means <strong>lord</strong> of flies. <strong>lord</strong> in the previous sentence means ______', 'Single Answer', 'captain,ruler,leader', 'ruler');
INSERT INTO `messagequestions` VALUES(5335, 'Beelzebub, another name for the devil means lord of <strong>flies.</strong> <strong>flies</strong> in the previous sentence means ______', 'Single Answer', 'demons,satan himself', 'demons');
INSERT INTO `messagequestions` VALUES(5336, '________ is a sign of confidence.', 'Single Answer', 'endurance,courage,quietness', 'quietness');
INSERT INTO `messagequestions` VALUES(5337, 'The _______ has established our future', 'Single Answer', 'government,school,Kingdom', 'Kingdom');
INSERT INTO `messagequestions` VALUES(5338, 'The Kingdom is __________ our future', 'Single Answer', 'responsible for,committed to', 'committed to');
INSERT INTO `messagequestions` VALUES(5339, 'The Kingdom ______ for our future', 'Single Answer', 'supplies,provides', 'provides');
INSERT INTO `messagequestions` VALUES(5340, 'The Kingdom ______ our future', 'Single Answer', 'secures,protects', 'protects');
INSERT INTO `messagequestions` VALUES(5341, 'The Kingdom ______ for our future', 'Single Answer', 'goes,works,moves', 'works');
INSERT INTO `messagequestions` VALUES(5342, 'The Kingdom ______ for our future', 'Single Answer', 'strategizes,plans', 'plans');
INSERT INTO `messagequestions` VALUES(5343, 'That''s what we do with _______. We take care of their whole future', 'Single Answer', 'representatives,ambassadors,all of the above', 'all of the above');
INSERT INTO `messagequestions` VALUES(5344, 'This year shall be the death of the _____ in our lives', 'Single Answer', 'anxiety,worry,all of the above', 'all of the above');
INSERT INTO `messagequestions` VALUES(5345, '<strong>Your beginnings will seem humble,\n so prosperous will your future be.</strong> What bible verse is this?', 'Single Answer', 'Job 8:7-8,Job 8:7,Job 8:8', 'Job 8:7');
INSERT INTO `messagequestions` VALUES(5346, '<strong>Consider the blameless, observe the upright; there is a future for the man of peace.</strong> What bible verse is this?', 'Single Answer', 'Psalms 37:37,Psalms 37:39,Psalms 37:37-39', 'Psalms 37:37');
INSERT INTO `messagequestions` VALUES(5347, '<strong>But all sinners will be destroyed;\n the future of the wicked will be cut off.</strong> What bible verse is this?', 'Single Answer', 'Psalms 37:37,Psalms 37:37-39,Psalms 37:38', 'Psalms 37:38');
INSERT INTO `messagequestions` VALUES(5348, 'We protect our future by living righteously. True or False?', 'Single Answer', 'True,False', 'True');
INSERT INTO `messagequestions` VALUES(5349, '_______ is resistance to fear', 'Single Answer', 'boldness,courage', 'courage');
INSERT INTO `messagequestions` VALUES(5350, 'Is courage the absence of fear?', 'Single Answer', 'Yes,No', 'No');
INSERT INTO `messagequestions` VALUES(5351, 'Courage is resistance to fear, mastery of fear-not the absence of fear. Who made this statement?', 'Single Answer', 'Corrie ten Boom,Mark Twain,Zig Ziglar', 'Mark Twain');
INSERT INTO `messagequestions` VALUES(5352, 'Can courage exist without fear?', 'Single Answer', 'Yes,No', 'No');
INSERT INTO `messagequestions` VALUES(5353, 'Courage is the product of fear. When you are afraid, it gives birth to courage. True or False?', 'Single Answer', 'True,False', 'True');
INSERT INTO `messagequestions` VALUES(5354, 'He who fears he will suffer, already suffers because of fear. Who made this statement', 'Single Answer', 'Mark Twain,Michel de Montaigne,Corrie ten Boom', 'Michel de Montaigne');
INSERT INTO `messagequestions` VALUES(5355, 'He who fears he will suffer, already suffers because of fear for <strong>fear has torment.</strong> What bible verse is this?', 'Single Answer', 'John 4:18,1John 4:18,2John 4:18,3John 4:18', '1John 4:18');
INSERT INTO `messagequestions` VALUES(5356, 'Whenever we are going to obey God, we should expect to be afraid, as His assignment always frightens us. True or False?', 'Single Answer', 'True,False', 'True');
INSERT INTO `messagequestions` VALUES(5357, 'Anything we can do on our own without God cannot be God ordained. True or False?', 'Single Answer', 'True,False', 'True');
INSERT INTO `messagequestions` VALUES(5358, 'God''s assignment always frightens us to bring courage to our lives. True or False?', 'Single Answer', 'True,False', 'True');
INSERT INTO `messagequestions` VALUES(5359, 'We should trust our ______ not our fears.', 'Single Answer', 'faith,ability,hope', 'hope');
INSERT INTO `messagequestions` VALUES(5360, 'We should ______ what God told us, not what we see with our eyes.', 'Single Answer', 'rely on,trust,believe', 'believe');
INSERT INTO `messagequestions` VALUES(5361, '________ will protect us from our fears.', 'Single Answer', 'our faith,our hope,our love', 'our hope');
INSERT INTO `messagequestions` VALUES(5362, '________ casts out fear.', 'Single Answer', 'hope,perfect love,faith', 'perfect love');
INSERT INTO `messagequestions` VALUES(5363, '<strong>perfect love casts out fear</strong>. What bible verse is this?', 'Single Answer', 'John 4:18,1John 4:18,2John 4:18,3John 4:18', '1John 4:18');
INSERT INTO `messagequestions` VALUES(5364, '<strong>What, then, shall we say in response to this? If God is for us; who can be against us?</strong> What bible verse is this?', 'Single Answer', 'Romans 8:30,Romans 8:31,Romans 8:31-32', 'Romans 8:31');
INSERT INTO `messagequestions` VALUES(5365, '<strong>He who did not spare His own Son,\n but gave Him up for us all-how will He not also,\n along with Him, graciously give us all things?</strong> What bible verse is this?', 'Single Answer', 'Romans 8:33,Romans 8:32,Romans 8:31-33', 'Romans 8:32');
INSERT INTO `messagequestions` VALUES(5366, '<strong>Who shall separate us from the love of Christ? Shall trouble or hardship or persecution or famine or nakedness or danger or sword?</strong> What bible verse is this?', 'Single Answer', 'Romans 8:33,Romans 8:34,Romans 8:35', 'Romans 8:35');
INSERT INTO `messagequestions` VALUES(5367, '<strong>No, in all these things we are more than conquerors through Him who loved us.</strong> What bible verse is this?', 'Single Answer', 'Romans 8:36,Romans 8:37,Romans 8:38', 'Romans 8:37');
INSERT INTO `messagequestions` VALUES(5368, '<strong>...commit to the LORD whatever you do, and your plans will succeed.</strong> What bible verse is this?', 'Single Answer', 'Proverbs 16:3-4,Proverbs 16:3,Proverbs 16:4', 'Proverbs 16:3');
INSERT INTO `messagequestions` VALUES(5369, '<strong>in his heart a man plans his course,\n but the LORD determines his steps.</strong> What bible verse is this?', 'Single Answer', 'Proverbs 16:8-9,Proverbs 16:9-10,Proverbs 16:9', 'Proverbs 16:9');
INSERT INTO `messagequestions` VALUES(5370, '<strong>May He give you the desire of your heart and make all your plans succeed.</strong> What bible verse is this?', 'Single Answer', 'Psalms 20:4-5,Psalms 20:3,Psalms 20:4,Psalms 20:5', 'Psalms 20:4');
INSERT INTO `messagequestions` VALUES(5371, '<strong>Delight yourself in the LORD and He will give you the desires of your heart.</strong> What bible verse is this?', 'Single Answer', 'Psalms 37:4-5,Psalms 37:4,Psalms 37:5', 'Psalms 37:4');
INSERT INTO `messagequestions` VALUES(5372, 'only those who dare to ______ greatly, can ever achieve greatly', 'Single Answer', 'accomplish,fail', 'fail');
INSERT INTO `messagequestions` VALUES(5373, 'Don''t _______, organize!', 'Single Answer', 'worry,be anxious,agonize', 'agonize');
INSERT INTO `messagequestions` VALUES(5374, 'Fear is as powerful as we fear it because when we  fear, we put our faith in the devil''s ability to destroy and so we empower him. True or False?', 'Single Answer', 'True,False', 'True');
INSERT INTO `messagequestions` VALUES(5375, 'Have faith in the God of your ______', 'Single Answer', 'tomorrow,future', 'future');

-- --------------------------------------------------------

--
-- Table structure for table `michaelalofescores`
--

CREATE TABLE `michaelalofescores` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `exercise` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `source` varchar(200) NOT NULL,
  `score` mediumint(9) NOT NULL,
  `currentage` mediumint(9) NOT NULL,
  `aggregate` varchar(200) NOT NULL,
  `tableName` varchar(50) NOT NULL DEFAULT 'michaelalofescores',
  `currentTotalAggregate` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=65 ;

--
-- Dumping data for table `michaelalofescores`
--

INSERT INTO `michaelalofescores` VALUES(1, '2016-01-03', 'Eternal Life', 'Review', 'Andrew Wommack', 0, 17, '0.000', 'michaelalofescores', '0');
INSERT INTO `michaelalofescores` VALUES(2, '2016-01-10', 'Close Encounter of the God Kind', 'Review', 'Jesse Duplantis', 3, 17, '0.176', 'michaelalofescores', '0.176');
INSERT INTO `michaelalofescores` VALUES(3, '2016-01-31', 'Growing Up Spiritually', 'Review', 'Kenneth E Hagin', 0, 17, '0.000', 'michaelalofescores', '0.176');
INSERT INTO `michaelalofescores` VALUES(4, '2016-02-07', 'The Cost of a Crown', 'Quiz', 'Bishop David Oyedepo', 27, 17, '1.588', 'michaelalofescores', '1.764');
INSERT INTO `michaelalofescores` VALUES(5, '2016-02-14', 'The Love Walk', 'Review', 'Kenneth E Hagin', 0, 17, '0.000', 'michaelalofescores', '1.764');
INSERT INTO `michaelalofescores` VALUES(6, '2016-02-21', 'Opted for Group Discussion', 'Group Discussion', 'Youths', 0, 17, '0.000', 'michaelalofescores', '1.764');
INSERT INTO `michaelalofescores` VALUES(7, '2016-03-13', 'Repositioning for Exploits', 'Review', 'Bishop David Oyedepo', 0, 17, '0.000', 'michaelalofescores', '1.764');
INSERT INTO `michaelalofescores` VALUES(8, '2016-03-27', '1John 4:4', 'Synonyms', 'Lanre Ibironke', 30, 17, '1.765', 'michaelalofescores', '3.529');
INSERT INTO `michaelalofescores` VALUES(9, '2016-04-03', 'Hand Sequence', 'Focus Test', 'Lanre Ibironke', 43, 17, '2.529', 'michaelalofescores', '6.058');
INSERT INTO `michaelalofescores` VALUES(10, '2016-04-10', 'Yesterday, Today and Tomorrow', 'Annotation and Silence Half Hour', 'Lanre Ibironke', 43, 17, '2.529', 'michaelalofescores', '8.587');
INSERT INTO `michaelalofescores` VALUES(11, '2016-04-17', 'Your Abilities', 'Annotation and Hand Sequence', 'Lanre Ibironke', 50, 17, '2.941', 'michaelalofescores', '11.528');
INSERT INTO `michaelalofescores` VALUES(12, '2016-04-24', 'Maximizing Your Most Valuable Asset', 'Home Work', 'Lanre Ibironke', 0, 17, '0.000', 'michaelalofescores', '11.528');
INSERT INTO `michaelalofescores` VALUES(13, '2016-05-01', 'Character Custodian of Destiny', 'Quiz', 'Bishop David Oyedepo', 0, 17, '0.000', 'michaelalofescores', '11.528');
INSERT INTO `michaelalofescores` VALUES(14, '2016-05-08', 'The Myth of Singleness', 'Questions', 'Dr Myles Munroe', 0, 17, '0.000', 'michaelalofescores', '11.528');
INSERT INTO `michaelalofescores` VALUES(15, '2016-05-15', 'Being Still (Psalms 46vs10)', 'Chicken on Egg Scenario', 'Lanre Ibironke', 0, 17, '0.000', 'michaelalofescores', '11.528');
INSERT INTO `michaelalofescores` VALUES(16, '2016-05-22', 'Selecting the Most Appropriate Word Replacement', 'Quiz', 'Lanre Ibironke', 50, 17, '2.941', 'michaelalofescores', '14.469');
INSERT INTO `michaelalofescores` VALUES(17, '2016-05-29', 'Personalizing Scripture', 'Theory Question', 'Lanre Ibironke', 71, 17, '4.176', 'michaelalofescores', '18.645');
INSERT INTO `michaelalofescores` VALUES(18, '2016-06-05', 'Inner Counsel', 'Annotation', 'Lanre Ibironke', 45, 17, '2.647', 'michaelalofescores', '21.292');
INSERT INTO `michaelalofescores` VALUES(19, '2016-06-12', 'Bible Questions', 'General Quiz', 'Lanre Ibironke', 45, 17, '2.647', 'michaelalofescores', '23.939');
INSERT INTO `michaelalofescores` VALUES(20, '2016-06-19', 'Marathon Question', 'General Quiz 2', 'Lanre Ibironke', 36, 17, '2.118', 'michaelalofescores', '26.057');
INSERT INTO `michaelalofescores` VALUES(21, '2016-06-26', 'Uzziah''s Story', 'Annotation', 'Lanre Ibironke', 26, 17, '1.529', 'michaelalofescores', '27.586');
INSERT INTO `michaelalofescores` VALUES(22, '2016-07-03', 'Multiple Choice', 'General Quiz 3', 'Lanre Ibironke', 60, 17, '3.529', 'michaelalofescores', '31.115');
INSERT INTO `michaelalofescores` VALUES(23, '2016-07-10', '4-Cards', 'Bible Game', 'Lanre Ibironke', 67, 17, '3.941', 'michaelalofescores', '35.056');
INSERT INTO `michaelalofescores` VALUES(24, '2016-07-24', 'Memory Test', 'Theory Questions', 'Lanre Ibironke', 65, 17, '3.824', 'michaelalofescores', '38.88');
INSERT INTO `michaelalofescores` VALUES(25, '2016-07-31', 'Scripture Expansion', 'Presentation', 'Lanre Ibironke', 35, 17, '2.059', 'michaelalofescores', '40.939');
INSERT INTO `michaelalofescores` VALUES(26, '2016-08-07', 'Multiple Choice', 'General Quiz 4', 'Lanre Ibironke', 66, 17, '3.882', 'michaelalofescores', '44.821');
INSERT INTO `michaelalofescores` VALUES(27, '2016-08-14', 'Tower of Hanoi & Marriage', 'Puzzle  & Annotation', 'Lanre Ibironke', 0, 17, '0', 'michaelalofescores', '44.821');
INSERT INTO `michaelalofescores` VALUES(28, '2016-08-21', 'The Innovative Demands of Leadership', 'Quiz 5', 'Myles Munroe', 52, 17, '3.059', 'michaelalofescores', '47.88');
INSERT INTO `michaelalofescores` VALUES(29, '2016-08-28', 'The Best Kept Secret', 'Quiz 6 & Annotation', 'Lanre Ibironke', 24, 17, '1.412', 'michaelalofescores', '49.292');
INSERT INTO `michaelalofescores` VALUES(30, '2016-09-04', 'Divine Secrets', 'Annotation', 'Lanre Ibironke', 55, 17, '3.235', 'michaelalofescores', '52.527');
INSERT INTO `michaelalofescores` VALUES(31, '2016-09-11', 'Repositioning for Exploits', 'Online Quiz', 'Bishop David Oyedepo', 386, 17, '22.698', 'michaelalofescores', '75.225');
INSERT INTO `michaelalofescores` VALUES(34, '2016-09-18', 'Kingdom Keys to Successful Relationships', 'Online Quiz', 'Myles Munroe', 474, 17, '27.876', 'michaelalofescores', '103.101');
INSERT INTO `michaelalofescores` VALUES(35, '2016-09-25', 'Heralding the Emergence of World Changers', 'Online Quiz', 'Bishop David Oyedepo', 940, 17, '55.282', 'michaelalofescores', '158.383');
INSERT INTO `michaelalofescores` VALUES(36, '2016-10-02', 'The Encounter', 'Online Quiz', 'Pure Flix Entertainment', 327, 18, '18.167', 'michaelalofescores', '176.55');
INSERT INTO `michaelalofescores` VALUES(37, '2016-10-09', 'The Ten Attitudes for Leadership Development', 'Online Quiz', 'Myles Munroe & David Oyedepo', 340, 18, '18.889', 'michaelalofescores', '195.439');
INSERT INTO `michaelalofescores` VALUES(38, '2016-10-16', 'What is Faith?', 'Online Quiz', 'David Oyedepo', 325, 18, '18.056', 'michaelalofescores', '213.495');
INSERT INTO `michaelalofescores` VALUES(39, '2016-10-23', 'The Media Mandate of the Kingdom', 'Online Quiz', 'Myles Munroe', 613, 18, '34.086', 'michaelalofescores', '247.581');
INSERT INTO `michaelalofescores` VALUES(40, '2016-10-30', 'Engaging the Armour of Light for Total Deliverance', 'Online Quiz', 'David Oyedepo', 575, 18, '31.974', 'michaelalofescores', '279.555');
INSERT INTO `michaelalofescores` VALUES(41, '2016-11-06', 'Vital Keys to Achieving Your Vision', 'Online Quiz', 'Myles Munroe', 926, 18, '51.486', 'michaelalofescores', '331.041');
INSERT INTO `michaelalofescores` VALUES(42, '2016-11-13', 'Engaging Violent Faith for Supernatural Turnaround', 'Online Quiz', 'Bishop David Oyedepo', 732, 18, '40.702', 'michaelalofescores', '371.743');
INSERT INTO `michaelalofescores` VALUES(43, '2016-11-20', 'The Source of the Leadership Spirit', 'Online Quiz', 'Myles Munroe', 661, 18, '36.752', 'michaelalofescores', '408.495');
INSERT INTO `michaelalofescores` VALUES(44, '2016-11-27', 'How to Excel in Your Field', 'Online Quiz', 'Bishop David Oyedepo', 505, 18, '28.078', 'michaelalofescores', '436.573');
INSERT INTO `michaelalofescores` VALUES(45, '2016-12-25', 'How to Deal with Grief 2/4', 'Online Quiz', 'Andrew Wommack', 97, 18, '5.394', 'michaelalofescores', '441.967');
INSERT INTO `michaelalofescores` VALUES(46, '2017-01-08', 'Christmas Jubilee and Direction', 'Online Quiz', 'Myles Munroe', 541, 18, '30.082', 'michaelalofescores', '472.049');
INSERT INTO `michaelalofescores` VALUES(48, '2017-01-15', 'Life', 'Online Quiz', 'David Oyedepo', 376, 18, '20.906', 'michaelalofescores', '492.955');
INSERT INTO `michaelalofescores` VALUES(49, '2017-01-22', 'Eternal Life', 'Online Quiz', 'Andrew Wommack', 311, 18, '17.314', 'michaelalofescores', '510.269');
INSERT INTO `michaelalofescores` VALUES(50, '2017-01-29', 'The Holy Spirit', 'Online Quiz', 'Pastor E.A. Adeboye', 75, 18, '4.17', 'michaelalofescores', '514.439');
INSERT INTO `michaelalofescores` VALUES(51, '2017-02-05', 'God''s Kind of Love To You', 'Online Quiz', 'Andrew Wommack', 10, 18, '0.556', 'michaelalofescores', '514.995');
INSERT INTO `michaelalofescores` VALUES(52, '2017-02-12', '7 Mistakes to avoid before marriage & End of the Harvest', 'Online Quiz', 'Pastor E.A. Adeboye & Christiano Film Group', 226, 18, '12.566', 'michaelalofescores', '527.561');
INSERT INTO `michaelalofescores` VALUES(53, '2017-02-19', 'Deepening your Relationship with God & 3 Types of Friends', 'Online Quiz', 'Pastor E.A. Adeboye & Christiano Film Group', 510, 18, '28.356', 'michaelalofescores', '555.917');
INSERT INTO `michaelalofescores` VALUES(54, '2017-02-26', 'Ultimate Myles Munroe 2016 Collection', 'Online Quiz', 'Myles Munroe', 1177, 18, '65.442', 'michaelalofescores', '621.359');
INSERT INTO `michaelalofescores` VALUES(55, '2017-03-05', 'Spirituality the Master Key to a World of Exploits', 'Online Quiz', 'Bishop David Oyedepo', 361, 18, '20.072', 'michaelalofescores', '641.431');
INSERT INTO `michaelalofescores` VALUES(56, '2017-03-12', 'The Kingdom Power of Self Government', 'Online Quiz', 'Myles Munroe', 598, 18, '33.25', 'michaelalofescores', '674.681');
INSERT INTO `michaelalofescores` VALUES(57, '2017-03-26', 'Marriage Prep 101', 'Online Quiz', 'Myles Munroe', 1146, 18, '63.718', 'michaelalofescores', '738.399');
INSERT INTO `michaelalofescores` VALUES(58, '2017-04-09', 'God\\''s Love (Love Series 3)', 'Online Quiz', 'Andrew Wommack', 411, 18, '22.852', 'michaelalofescores', '761.251');
INSERT INTO `michaelalofescores` VALUES(59, '2017-04-16', 'The Last Reformation 1(0:00-30:27)', 'Online Quiz', 'Akatio Films', 981, 18, '54.544', 'michaelalofescores', '815.795');
INSERT INTO `michaelalofescores` VALUES(60, '2017-04-23', 'The Power of Spiritual Depth', 'Online Quiz', 'Bishop David Oyedepo', 190, 18, '10.564', 'michaelalofescores', '826.359');
INSERT INTO `michaelalofescores` VALUES(61, '2017-04-28', 'The Last Reformation(30:27-The End)', 'Online Quiz', 'Akatio Films', 1313, 18, '73.004', 'michaelalofescores', '899.363');
INSERT INTO `michaelalofescores` VALUES(62, '2017-05-05', 'The Principles of Creation', 'Online Quiz', 'Myles Munroe', 1059, 18, '58.886', 'michaelalofescores', '958.249');
INSERT INTO `michaelalofescores` VALUES(63, '2017-05-12', 'Drive Through History Holy Land 1', 'Online Quiz', 'Myles Munroe', 1267, 18, '70.446', 'michaelalofescores', '1028.695');
INSERT INTO `michaelalofescores` VALUES(64, '2017-05-19', 'How to Walk in Confidence', 'Online Quiz', 'Myles Munroe', 125, 18, '6.95', 'michaelalofescores', '1035.645');

-- --------------------------------------------------------

--
-- Table structure for table `oluwanifemifawalescores`
--

CREATE TABLE `oluwanifemifawalescores` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `exercise` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `source` varchar(200) NOT NULL,
  `score` mediumint(9) NOT NULL,
  `currentage` mediumint(9) NOT NULL,
  `aggregate` varchar(200) NOT NULL,
  `tableName` varchar(50) NOT NULL,
  `currentTotalAggregate` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `oluwanifemifawalescores`
--

INSERT INTO `oluwanifemifawalescores` VALUES(1, '2017-04-16', 'Joined (DOB Mar 31 2006)', 'Joined', 'Youth Instructor', 319, 11, '29', 'oluwanifemifawalescores', '29');
INSERT INTO `oluwanifemifawalescores` VALUES(2, '2017-04-23', 'The Power of Spiritual Depth', 'Online Quiz', 'Bishop David Oyedepo', 546, 11, '49.686', 'oluwanifemifawalescores', '78.686');
INSERT INTO `oluwanifemifawalescores` VALUES(3, '2017-05-05', 'The Principles of Creation', 'Online Quiz', 'Myles Munroe', 218, 11, '19.838', 'oluwanifemifawalescores', '98.524');
INSERT INTO `oluwanifemifawalescores` VALUES(4, '2017-05-12', 'Drive Through History Holy Land 1', 'Online Quiz', 'Myles Munroe', 536, 11, '48.776', 'oluwanifemifawalescores', '147.3');

-- --------------------------------------------------------

--
-- Table structure for table `oluwaseyialofescores`
--

CREATE TABLE `oluwaseyialofescores` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `exercise` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `source` varchar(200) NOT NULL,
  `score` mediumint(9) NOT NULL,
  `currentage` mediumint(9) NOT NULL,
  `aggregate` varchar(200) NOT NULL,
  `tableName` varchar(50) NOT NULL,
  `currentTotalAggregate` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `oluwaseyialofescores`
--

INSERT INTO `oluwaseyialofescores` VALUES(1, '2017-05-14', 'Joined (DOB May 10)', 'Joined', 'Lanre Ibironke', 290, 10, '29.02', 'oluwaseyialofescores', '29.02');
INSERT INTO `oluwaseyialofescores` VALUES(3, '2017-05-19', 'The Principles of Creation', 'Online Quiz', 'Myles Munroe', 116, 10, '11.6', 'oluwaseyialofescores', '40.62');

-- --------------------------------------------------------

--
-- Table structure for table `oyinalofescores`
--

CREATE TABLE `oyinalofescores` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `exercise` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `source` varchar(200) NOT NULL,
  `score` mediumint(9) NOT NULL,
  `currentage` mediumint(9) NOT NULL,
  `aggregate` varchar(200) NOT NULL,
  `tableName` varchar(50) NOT NULL DEFAULT 'oyinalofescores',
  `currentTotalAggregate` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=64 ;

--
-- Dumping data for table `oyinalofescores`
--

INSERT INTO `oyinalofescores` VALUES(1, '2016-01-03', 'Eternal Life', 'Review', 'Andrew Wommack', 0, 10, '0.000', 'oyinalofescores', '0');
INSERT INTO `oyinalofescores` VALUES(2, '2016-01-10', 'Close Encounter of the God Kind', 'Review', 'Jesse Duplantis', 0, 10, '0.000', 'oyinalofescores', '0');
INSERT INTO `oyinalofescores` VALUES(3, '2016-01-31', 'Growing Up Spiritually', 'Review', 'Kenneth E Hagin', 0, 11, '0.000', 'oyinalofescores', '0');
INSERT INTO `oyinalofescores` VALUES(4, '2016-02-07', 'The Cost of a Crown', 'Quiz', 'Bishop David Oyedepo', 0, 11, '0.000', 'oyinalofescores', '0');
INSERT INTO `oyinalofescores` VALUES(5, '2016-02-14', 'The Love Walk', 'Review', 'Kenneth E Hagin', 0, 11, '0.000', 'oyinalofescores', '0');
INSERT INTO `oyinalofescores` VALUES(6, '2016-02-21', 'Opted for Group Discussion', 'Group Discussion', 'Youth', 0, 11, '0.000', 'oyinalofescores', '0');
INSERT INTO `oyinalofescores` VALUES(7, '2016-03-13', 'Repositioning for Exploits', 'Review', 'Bishop David Oyedepo', 0, 11, '0.000', 'oyinalofescores', '0');
INSERT INTO `oyinalofescores` VALUES(8, '2016-03-27', '1John 4:4', 'Synonyms', 'Lanre Ibironke', 0, 11, '0.000', 'oyinalofescores', '0');
INSERT INTO `oyinalofescores` VALUES(9, '2016-04-03', 'Hand Sequence', 'Focus Test', 'Lanre Ibironke', 18, 11, '1.636', 'oyinalofescores', '1.636');
INSERT INTO `oyinalofescores` VALUES(10, '2016-04-10', 'Yesterday, Today and Tomorrow', 'Annotation and Silence Half Hour', 'Lanre Ibironke', 32, 11, '2.909', 'oyinalofescores', '4.545');
INSERT INTO `oyinalofescores` VALUES(11, '2016-04-17', 'Your Abilities', 'Annotation and Hand Sequence', 'Lanre Ibironke', 2, 11, '0.182', 'oyinalofescores', '4.727');
INSERT INTO `oyinalofescores` VALUES(12, '2016-04-24', 'Maximizing Your Most Valuable Asset', 'Home Work', 'Lanre Ibironke', 0, 11, '0.000', 'oyinalofescores', '4.727');
INSERT INTO `oyinalofescores` VALUES(13, '2016-05-01', 'Character Custodian of Destiny', 'Quiz', 'Bishop David Oyedepo', 0, 11, '0.000', 'oyinalofescores', '4.727');
INSERT INTO `oyinalofescores` VALUES(15, '2016-05-08', 'The Myth of Singleness', 'Questions', 'Dr Myles Munroe', 0, 11, '0.000', 'oyinalofescores', '4.727');
INSERT INTO `oyinalofescores` VALUES(16, '2016-05-15', 'Being Still (Psalms 46vs10)', 'Chicken on Egg Scenario', 'Lanre Ibironke', 0, 11, '0.000', 'oyinalofescores', '4.727');
INSERT INTO `oyinalofescores` VALUES(17, '2016-05-22', 'Selecting the Most Appropriate Word Replacement', 'Quiz', 'Lanre Ibironke', 30, 11, '2.727', 'oyinalofescores', '7.454');
INSERT INTO `oyinalofescores` VALUES(18, '2016-05-29', 'Personalizing Scripture', 'Theory Question', 'Lanre Ibironke', 41, 11, '3.727', 'oyinalofescores', '11.181');
INSERT INTO `oyinalofescores` VALUES(19, '2016-06-05', 'Inner Counsel', 'Annotation', 'Lanre Ibironke', 30, 11, '2.727', 'oyinalofescores', '13.908');
INSERT INTO `oyinalofescores` VALUES(20, '2016-06-12', 'Bible Questions', 'General Quiz', 'Lanre Ibironke', 33, 11, '3', 'oyinalofescores', '16.908');
INSERT INTO `oyinalofescores` VALUES(21, '2016-06-19', 'Marathon Question', 'General Quiz 2', 'Lanre Ibironke', 42, 11, '3.818', 'oyinalofescores', '20.726');
INSERT INTO `oyinalofescores` VALUES(22, '2016-06-26', 'Uzziah''s Story', 'Annotation', 'Lanre Ibironke', 33, 11, '3', 'oyinalofescores', '23.726');
INSERT INTO `oyinalofescores` VALUES(23, '2016-07-03', 'Multiple Choice', 'General Quiz 3', 'Lanre Ibironke', 0, 11, '0', 'oyinalofescores', '23.726');
INSERT INTO `oyinalofescores` VALUES(24, '2016-07-10', '4-Cards', 'Bible Game', 'Lanre Ibironke', 0, 11, '0', 'oyinalofescores', '23.726');
INSERT INTO `oyinalofescores` VALUES(25, '2016-07-24', 'Memory Test', 'Theory Questions', 'Lanre Ibironke', 27, 11, '2.455', 'oyinalofescores', '26.181');
INSERT INTO `oyinalofescores` VALUES(26, '2016-07-31', 'Scripture Expansion', 'Presentation', 'Lanre Ibironke', 17, 11, '1.545', 'oyinalofescores', '27.726');
INSERT INTO `oyinalofescores` VALUES(27, '2016-08-07', 'Multiple Choice', 'General Quiz 4', 'Lanre Ibironke', 57, 11, '5.182', 'oyinalofescores', '32.908');
INSERT INTO `oyinalofescores` VALUES(28, '2016-08-14', 'Tower of Hanoi & Marriage', 'Puzzle  & Annotation', 'Lanre Ibironke', 0, 11, '0', 'oyinalofescores', '32.908');
INSERT INTO `oyinalofescores` VALUES(29, '2016-08-21', 'The Innovative Demands of Leadership', 'Quiz 5', 'Myles Munroe', 40, 11, '3.636', 'oyinalofescores', '36.544');
INSERT INTO `oyinalofescores` VALUES(30, '2016-08-28', 'The Best Kept Secret', 'Quiz 6 & Annotation', 'Lanre Ibironke', 40, 11, '3.636', 'oyinalofescores', '40.18');
INSERT INTO `oyinalofescores` VALUES(31, '2016-09-04', 'Divine Secrets', 'Annotation', 'Lanre Ibironke', 75, 11, '6.818', 'oyinalofescores', '46.998');
INSERT INTO `oyinalofescores` VALUES(32, '2016-09-11', 'Repositioning for Exploits', 'Online Quiz', 'Bishop David Oyedepo', 122, 11, '11.102', 'oyinalofescores', '58.1');
INSERT INTO `oyinalofescores` VALUES(33, '2016-09-18', 'Kingdom Keys to Successful Relationships', 'Online Quiz', 'Myles Munroe', 339, 11, '30.849', 'oyinalofescores', '88.949');
INSERT INTO `oyinalofescores` VALUES(34, '2016-09-25', 'Heralding the Emergence of World Changers', 'Online Quiz', 'Bishop David Oyedepo', 532, 11, '48.412', 'oyinalofescores', '137.361');
INSERT INTO `oyinalofescores` VALUES(35, '2016-10-02', 'The Encounter', 'Online Quiz', 'Pure Flix Entertainment', 319, 11, '29.029', 'oyinalofescores', '166.39');
INSERT INTO `oyinalofescores` VALUES(36, '2016-10-09', 'The Ten Attitudes for Leadership Development', 'Online Quiz', 'Myles Munroe', 465, 11, '42.315', 'oyinalofescores', '208.705');
INSERT INTO `oyinalofescores` VALUES(37, '2016-10-16', 'What is Faith?', 'Online Quiz', 'David Oyedepo', 145, 11, '13.195', 'oyinalofescores', '221.9');
INSERT INTO `oyinalofescores` VALUES(38, '2016-10-23', 'The Media Mandate of the Kingdom', 'Online Quiz', 'Myles Munroe', 281, 11, '25.571', 'oyinalofescores', '247.471');
INSERT INTO `oyinalofescores` VALUES(39, '2016-10-30', 'Engaging the Armour of Light for Total Deliverance', 'Online Quiz', 'Bishop David Oyedepo', 355, 11, '32.305', 'oyinalofescores', '279.776');
INSERT INTO `oyinalofescores` VALUES(40, '2016-11-06', 'Vital Keys to Achieving Your Vision', 'Online Quiz', 'Myles Munroe', 494, 11, '44.954', 'oyinalofescores', '324.73');
INSERT INTO `oyinalofescores` VALUES(41, '2016-11-13', 'Engaging Violent Faith for Supernatural Turnaround', 'Online Quiz', 'Bishop David Oyedepo', 380, 11, '34.58', 'oyinalofescores', '359.31');
INSERT INTO `oyinalofescores` VALUES(42, '2016-11-20', 'The Source of the Leadership Spirit', 'Online Quiz', 'Myles Munroe', 377, 11, '34.307', 'oyinalofescores', '393.617');
INSERT INTO `oyinalofescores` VALUES(43, '2016-12-25', 'How to Deal with Grief 2/4', 'Online Quiz', 'Andrew Wommack', 297, 11, '27.027', 'oyinalofescores', '420.644');
INSERT INTO `oyinalofescores` VALUES(44, '2017-01-01', 'The Life and Power of Words', 'Online Quiz', 'Charles Capps', 303, 11, '27.573', 'oyinalofescores', '448.217');
INSERT INTO `oyinalofescores` VALUES(45, '2017-01-08', 'Christmas Jubilee and Direction', 'Online Quiz', 'Myles Munroe', 431, 11, '39.221', 'oyinalofescores', '487.438');
INSERT INTO `oyinalofescores` VALUES(46, '2017-01-15', 'Life', 'Online Quiz', 'David Oyedepo', 421, 11, '38.311', 'oyinalofescores', '525.749');
INSERT INTO `oyinalofescores` VALUES(47, '2017-01-22', 'Eternal Life', 'Online Quiz', 'Andrew Wommack', 59, 11, '5.369', 'oyinalofescores', '531.118');
INSERT INTO `oyinalofescores` VALUES(48, '2017-01-29', 'The Holy Spirit', 'Online Quiz', 'Pastor E.A. Adeboye & Andrew Wommack', 270, 12, '22.496', 'oyinalofescores', '553.614');
INSERT INTO `oyinalofescores` VALUES(49, '2017-02-05', 'God''s Kind of Love To You', 'Online Quiz', 'Andrew Wommack', 389, 12, '32.415', 'oyinalofescores', '586.029');
INSERT INTO `oyinalofescores` VALUES(50, '2017-02-12', '7 Mistakes to avoid before marriage & End of the Harvest', 'Online Quiz', 'Pastor E.A. Adeboye & Christiano Film Group', 265, 12, '22.097', 'oyinalofescores', '608.126');
INSERT INTO `oyinalofescores` VALUES(51, '2017-02-19', 'Deepening your Relationship with God & 3 Types of Friends', 'Online Quiz', 'TD Jakes', 454, 12, '37.858', 'oyinalofescores', '645.984');
INSERT INTO `oyinalofescores` VALUES(52, '2017-03-05', 'Spirituality the Master Key to a World of Exploits', 'Online Quiz', 'Bishop David Oyedepo', 516, 12, '42.998', 'oyinalofescores', '688.982');
INSERT INTO `oyinalofescores` VALUES(53, '2017-03-12', 'The Kingdom Power of Self Government', 'Online Quiz', 'Myles Munroe', 37, 12, '3.083', 'oyinalofescores', '692.065');
INSERT INTO `oyinalofescores` VALUES(54, '2017-03-19', 'Life 2', 'Online Quiz', 'Bishop David Oyedepo', 662, 12, '55.202', 'oyinalofescores', '747.267');
INSERT INTO `oyinalofescores` VALUES(55, '2017-03-26', 'Marriage Prep 101', 'Online Quiz', 'Myles Munroe', 1062, 12, '88.562', 'oyinalofescores', '835.829');
INSERT INTO `oyinalofescores` VALUES(56, '2017-04-02', 'Salvation Testimony', 'Online Quiz', 'Kenneth Erwin Hagin', 794, 12, '66.216', 'oyinalofescores', '902.045');
INSERT INTO `oyinalofescores` VALUES(57, '2017-04-09', 'God\\''s Love (Love Series 3)', 'Online Quiz', 'Andrew Wommack', 513, 12, '42.667', 'oyinalofescores', '944.712');
INSERT INTO `oyinalofescores` VALUES(58, '2017-04-16', 'God\\''s Love (Love Series 3)', 'Online Quiz', 'Andrew Wommack', 578, 12, '48.2', 'oyinalofescores', '992.912');
INSERT INTO `oyinalofescores` VALUES(59, '2017-04-23', 'The Power of Spiritual Depth', 'Online Quiz', 'Bishop David Oyedepo', 297, 12, '24.767', 'oyinalofescores', '1017.679');
INSERT INTO `oyinalofescores` VALUES(60, '2017-04-28', 'The Last Reformation(30:27-The End)', 'Online Quiz', 'Akatio Films', 976, 12, '81.394', 'oyinalofescores', '1099.073');
INSERT INTO `oyinalofescores` VALUES(61, '2017-05-05', 'The Principles of Creation', 'Online Quiz', 'Myles Munroe', 400, 12, '33.354', 'oyinalofescores', '1132.427');
INSERT INTO `oyinalofescores` VALUES(62, '2017-05-12', 'Drive Through History Holy Land 1', 'Online Quiz', 'Myles Munroe', 168, 12, '14.008', 'oyinalofescores', '1146.435');
INSERT INTO `oyinalofescores` VALUES(63, '2017-05-19', 'The Principles of Creation', 'Online Quiz', 'Myles Munroe', 225, 12, '18.761', 'oyinalofescores', '1165.196');

-- --------------------------------------------------------

--
-- Table structure for table `praiseshondescores`
--

CREATE TABLE `praiseshondescores` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `exercise` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `source` varchar(200) NOT NULL,
  `score` mediumint(9) NOT NULL,
  `currentage` mediumint(9) NOT NULL,
  `aggregate` varchar(200) NOT NULL,
  `tableName` varchar(50) NOT NULL DEFAULT 'praiseshondescores',
  `currentTotalAggregate` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=67 ;

--
-- Dumping data for table `praiseshondescores`
--

INSERT INTO `praiseshondescores` VALUES(10, '2016-01-03', 'Eternal Life', 'Review', 'Andrew Wommack', 0, 10, '0', 'praiseshondescores', '0');
INSERT INTO `praiseshondescores` VALUES(11, '2016-01-10', 'Close Encounter of the God Kind', 'Review', 'Jesse Duplantis', 0, 10, '0', 'praiseshondescores', '0');
INSERT INTO `praiseshondescores` VALUES(12, '2016-01-31', 'Growing Up Sppiritually', 'Review', 'Kenneth E Hagin', 0, 10, '0', 'praiseshondescores', '0');
INSERT INTO `praiseshondescores` VALUES(13, '2016-02-07', 'The Cost of a Crown', 'Quiz', 'Bishop David Oyedepo', 0, 10, '0', 'praiseshondescores', '0');
INSERT INTO `praiseshondescores` VALUES(14, '2016-02-14', 'The Love Walk', 'Review', 'Kenneth E Hagin', 0, 10, '0', 'praiseshondescores', '0');
INSERT INTO `praiseshondescores` VALUES(15, '2016-02-21', 'Opted for Group Discussion', 'Group Discussion', 'Youths', 0, 10, '0', 'praiseshondescores', '0');
INSERT INTO `praiseshondescores` VALUES(16, '2016-03-13', 'Repositioning for Exploits', 'Review', 'Bishop David Oyedepo', 0, 10, '0', 'praiseshondescores', '0');
INSERT INTO `praiseshondescores` VALUES(17, '2016-03-27', '1John 4:4', 'Synonyms', 'Lanre Ibironke', 0, 10, '0', 'praiseshondescores', '0');
INSERT INTO `praiseshondescores` VALUES(18, '2016-04-03', 'Hand Sequence', 'Focus Test ', 'Lanre Ibironke', 0, 10, '0', 'praiseshondescores', '0');
INSERT INTO `praiseshondescores` VALUES(19, '2016-04-10', 'Yesterday, Today and Tomorrow', 'Annotation and Silence Half Hour', 'Lanre Ibironke', 0, 10, '0', 'praiseshondescores', '0');
INSERT INTO `praiseshondescores` VALUES(20, '2016-04-17', 'Your Abilities', 'Annotation and Hand Sequence', 'Lanre Ibironke', 0, 10, '0', 'praiseshondescores', '0');
INSERT INTO `praiseshondescores` VALUES(21, '2016-04-24', 'Maximizing Your Most Valuable Asset', 'Home Work', 'Lanre Ibironke', 0, 10, '0', 'praiseshondescores', '0');
INSERT INTO `praiseshondescores` VALUES(22, '2016-05-01', 'Character Custodian of Destiny', 'Quiz', 'Bishop David Oyedepo', 0, 10, '0', 'praiseshondescores', '0');
INSERT INTO `praiseshondescores` VALUES(23, '2016-05-08', 'The Myth of Singleness', 'Questions', 'Dr Myles Munroe', 0, 10, '0', 'praiseshondescores', '0');
INSERT INTO `praiseshondescores` VALUES(24, '2016-05-15', 'Being Still (Psalms 46vs10)', 'Chicken on Egg Scenario', 'Lanre Ibironke', 0, 10, '0', 'praiseshondescores', '0');
INSERT INTO `praiseshondescores` VALUES(25, '2016-05-22', 'Selecting the Most Appropriate Word Replacement', 'Quiz', 'Lanre Ibironke', 0, 10, '0', 'praiseshondescores', '0');
INSERT INTO `praiseshondescores` VALUES(26, '2016-05-29', 'Personalizing Scripture', 'Theory Question', 'Lanre Ibironke', 0, 10, '0', 'praiseshondescores', '0');
INSERT INTO `praiseshondescores` VALUES(27, '2016-06-05', 'Inner Counsel', 'Annotation', 'Lanre Ibironke', 0, 10, '0', 'praiseshondescores', '0');
INSERT INTO `praiseshondescores` VALUES(28, '2016-06-12', 'Bible Questions', 'General Quiz', 'Lanre Ibironke', 0, 10, '0', 'praiseshondescores', '0');
INSERT INTO `praiseshondescores` VALUES(29, '2016-06-19', 'Marathon Question', 'General Quiz 2', 'Lanre Ibironke', 0, 10, '0', 'praiseshondescores', '0');
INSERT INTO `praiseshondescores` VALUES(33, '2016-06-26', 'Uzziah''s Story', 'Annotation', 'Lanre Ibironke', 70, 10, '7', 'praiseshondescores', '7');
INSERT INTO `praiseshondescores` VALUES(34, '2016-07-03', 'Multiple Choice', 'General Quiz 3', 'Lanre Ibironke', 0, 10, '0', 'praiseshondescores', '7');
INSERT INTO `praiseshondescores` VALUES(35, '2016-07-10', '4-Cards', 'Bible Game', 'Lanre Ibironke', 14, 10, '1.4', 'praiseshondescores', '8.4');
INSERT INTO `praiseshondescores` VALUES(46, '2016-07-24', 'Memory Test', 'Theory Questions', 'Lanre Ibironke', 0, 10, '0', 'praiseshondescores', '8.4');
INSERT INTO `praiseshondescores` VALUES(47, '2016-07-31', 'Scripture Expansion', 'Presentation', 'Lanre Ibironke', 24, 10, '2.4', 'praiseshondescores', '10.8');
INSERT INTO `praiseshondescores` VALUES(48, '2016-08-07', 'Multiple Choice', 'General Quiz 4', 'Lanre Ibironke', 48, 10, '4.8', 'praiseshondescores', '15.6');
INSERT INTO `praiseshondescores` VALUES(49, '2016-08-14', 'Tower of Hanoi & Marriage', 'Puzzle & Annotation', 'Lanre Ibironke', 0, 10, '0', 'praiseshondescores', '15.6');
INSERT INTO `praiseshondescores` VALUES(50, '2016-08-21', 'The Innovative Demands of Leadership', 'Quiz 5', 'Myles Munroe', 17, 10, '1.7', 'praiseshondescores', '17.3');
INSERT INTO `praiseshondescores` VALUES(51, '2016-08-28', 'The Best Kept Secret', 'Quiz 6 & Annotation', 'Lanre Ibironke', 12, 10, '1.2', 'praiseshondescores', '18.5');
INSERT INTO `praiseshondescores` VALUES(52, '2016-09-04', 'Divine Secrets', 'Annotation', 'Lanre Ibironke', 40, 10, '4', 'praiseshondescores', '22.5');
INSERT INTO `praiseshondescores` VALUES(53, '2016-09-11', 'Repositioning for Exploits', 'Online Quiz', 'Bishop David Oyedepo', 116, 10, '11.6', 'praiseshondescores', '34.1');
INSERT INTO `praiseshondescores` VALUES(54, '2016-09-18', 'Kingdom Keys to Successful Relationships', 'Online Quiz', 'Myles Munroe', 303, 10, '30.3', 'praiseshondescores', '64.4');
INSERT INTO `praiseshondescores` VALUES(55, '2016-09-25', 'Heralding the Emergence of World Changers', 'Online Quiz', 'Bishop David Oyedepo', 460, 10, '46', 'praiseshondescores', '110.4');
INSERT INTO `praiseshondescores` VALUES(56, '2016-10-16', 'What is Faith?', 'Online Quiz', 'David Oyedepo', 17, 10, '1.7', 'praiseshondescores', '112.1');
INSERT INTO `praiseshondescores` VALUES(57, '2016-10-30', 'Engaging the Armour of Light for Total Deliverance', 'Online Quiz', 'Bishop David Oyedepo', 145, 10, '14.5', 'praiseshondescores', '126.6');
INSERT INTO `praiseshondescores` VALUES(58, '2016-12-11', 'The Stronghold of Faith', 'Online Quiz', 'Bishop David Oyedepo', 291, 10, '29.1', 'praiseshondescores', '155.7');
INSERT INTO `praiseshondescores` VALUES(59, '2017-01-15', 'Life', 'Online Quiz', 'David Oyedepo', 27, 10, '2.7', 'praiseshondescores', '158.4');
INSERT INTO `praiseshondescores` VALUES(60, '2017-01-22', 'Eternal Life', 'Online Quiz', 'Andrew Wommack', 96, 10, '9.6', 'praiseshondescores', '168');
INSERT INTO `praiseshondescores` VALUES(61, '2017-01-29', 'The Holy Spirit', 'Online Quiz', 'Pastor E.A. Adeboye & Andrew Wommack', 259, 10, '25.9', 'praiseshondescores', '193.9');
INSERT INTO `praiseshondescores` VALUES(62, '2017-02-05', 'God''s Kind of Love To You', 'Online Quiz', 'Andrew Wommack', 357, 10, '35.7', 'praiseshondescores', '229.6');
INSERT INTO `praiseshondescores` VALUES(63, '2017-02-12', '7 Mistakes to avoid before marriage & End of the Harvest', 'Online Quiz', 'Pastor E.A. Adeboye & Christiano Film Group', 201, 10, '20.1', 'praiseshondescores', '249.7');
INSERT INTO `praiseshondescores` VALUES(64, '2017-04-16', 'The Last Reformation 1(0:00-30:27)', 'Online Quiz', 'Akatio Films', 775, 10, '77.5', 'praiseshondescores', '327.2');
INSERT INTO `praiseshondescores` VALUES(65, '2017-04-23', 'The Power of Spiritual Depth', 'Online Quiz', 'Bishop David Oyedepo', 1292, 10, '129.2', 'praiseshondescores', '456.4');
INSERT INTO `praiseshondescores` VALUES(66, '2017-04-28', 'The Last Reformation(30:27-The End) (Birthday May 7)', 'Online Quiz', 'Akatio Films', 258, 11, '25.8', 'praiseshondescores', '482.2');

-- --------------------------------------------------------

--
-- Table structure for table `preciousfalodunscores`
--

CREATE TABLE `preciousfalodunscores` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `exercise` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `source` varchar(200) NOT NULL,
  `score` mediumint(9) NOT NULL,
  `currentage` mediumint(9) NOT NULL,
  `aggregate` varchar(200) NOT NULL,
  `tableName` varchar(50) NOT NULL DEFAULT 'preciousfalodunscores',
  `currentTotalAggregate` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=39 ;

--
-- Dumping data for table `preciousfalodunscores`
--

INSERT INTO `preciousfalodunscores` VALUES(32, '2017-03-25', 'Joined', 'Online Quiz', 'Lanre Ibironke', 181, 14, '12.943', 'preciousfalodunscores', '12.943');
INSERT INTO `preciousfalodunscores` VALUES(33, '2017-03-26', 'Marriage Prep 101', 'Online Quiz', 'Myles Munroe', 1118, 14, '79.857', 'preciousfalodunscores', '92.8');
INSERT INTO `preciousfalodunscores` VALUES(34, '2017-04-16', 'The Last Reformation 1(0:00-30:27)', 'Online Quiz', 'Akatio Films', 989, 14, '70.613', 'preciousfalodunscores', '163.413');
INSERT INTO `preciousfalodunscores` VALUES(35, '2017-04-30', 'The Power of Spiritual Depth', 'Online Quiz', 'Bishop David Oyedepo', 817, 14, '58.331', 'preciousfalodunscores', '221.744');
INSERT INTO `preciousfalodunscores` VALUES(36, '2017-05-05', 'The Principles of Creation', 'Online Quiz', 'Myles Munroe', 880, 14, '62.828', 'preciousfalodunscores', '284.572');
INSERT INTO `preciousfalodunscores` VALUES(37, '2017-05-12', 'Drive Through History Holy Land 1', 'Online Quiz', 'Myles Munroe', 47, 14, '3.355', 'preciousfalodunscores', '287.927');
INSERT INTO `preciousfalodunscores` VALUES(38, '2017-05-19', 'How to Walk in Confidence', 'Online Quiz', 'Myles Munroe', 435, 14, '31.057', 'preciousfalodunscores', '318.984');

-- --------------------------------------------------------

--
-- Table structure for table `prizes`
--

CREATE TABLE `prizes` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `donor` varchar(50) NOT NULL,
  `amount` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `prizes`
--

INSERT INTO `prizes` VALUES(1, 'Lanre Ibironke', '300');

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--

CREATE TABLE `profiles` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `first` varchar(200) NOT NULL,
  `last` varchar(200) NOT NULL,
  `age` varchar(100) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL,
  `totalAggregate` varchar(200) NOT NULL,
  `position` varchar(200) NOT NULL,
  `prize` varchar(100) NOT NULL,
  `color` varchar(10) NOT NULL,
  `initials` varchar(2) NOT NULL,
  `codename` varchar(50) NOT NULL,
  `scorestablename` varchar(50) NOT NULL,
  `scores` text NOT NULL,
  `quizStatus` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `profiles`
--

INSERT INTO `profiles` VALUES(1, 'Timilehin', 'Adeosun', '14', 'fijitimi9900@gmail.com', 'cf6ad41c68eff82a4b248859f66af75cfabfc1ca', '973.211', '6th', '34', '690056', 'TA', 'Chocolate87', 'timilehinadeosunscores', '[{"id":"1","date":"2016-01-03","exercise":"Eternal Life","type":"Review","source":"Andrew Wommack","score":"24","currentage":"13","aggregate":"1.846","tableName":"timilehinadeosunscores","currentTotalAggregate":"1.846"},{"id":"2","date":"2016-01-10","exercise":"Close Encounter of the God Kind","type":"Review","source":"Jesse Duplantis","score":"14","currentage":"13","aggregate":"1.077","tableName":"timilehinadeosunscores","currentTotalAggregate":"2.923"},{"id":"3","date":"2016-01-31","exercise":"Growing Up Spiritually","type":"Review","source":"Kenneth E Hagin","score":"11","currentage":"13","aggregate":"0.846","tableName":"timilehinadeosunscores","currentTotalAggregate":"3.769"},{"id":"4","date":"2016-02-07","exercise":"The Cost of a Crown","type":"Quiz","source":"Bishop David Oyedepo","score":"43","currentage":"13","aggregate":"3.308","tableName":"timilehinadeosunscores","currentTotalAggregate":"7.077"},{"id":"5","date":"2016-02-14","exercise":"The Love Walk","type":"Review","source":"Kenneth E Hagin","score":"34","currentage":"13","aggregate":"2.615","tableName":"timilehinadeosunscores","currentTotalAggregate":"9.692"},{"id":"6","date":"2016-02-21","exercise":"Opted for Group Discussion","type":"Group Discussion","source":"Youths","score":"0","currentage":"13","aggregate":"0.000","tableName":"timilehinadeosunscores","currentTotalAggregate":"9.692"},{"id":"7","date":"2016-03-13","exercise":"Repositioning for Exploits","type":"Review ","source":"Bishop David Oyedepo","score":"0","currentage":"13","aggregate":"0.000","tableName":"timilehinadeosunscores","currentTotalAggregate":"9.692"},{"id":"8","date":"2016-03-27","exercise":"1John 4:4","type":"Synonyms","source":"Lanre Ibironke","score":"47","currentage":"13","aggregate":"3.615","tableName":"timilehinadeosunscores","currentTotalAggregate":"13.307"},{"id":"9","date":"2016-04-03","exercise":"Hand Sequence","type":"Focus Test","source":"Lanre Ibironke","score":"30","currentage":"13","aggregate":"2.308","tableName":"timilehinadeosunscores","currentTotalAggregate":"15.615"},{"id":"10","date":"2016-04-10","exercise":"Yesterday, Today and Tomorrow","type":"Annotation and Silence Half Hour","source":"Lanre Ibironke","score":"64","currentage":"13","aggregate":"4.923","tableName":"timilehinadeosunscores","currentTotalAggregate":"20.538"},{"id":"11","date":"2016-04-17","exercise":"Your Abilities","type":"Annotation and Hand Sequence","source":"Lanre Ibironke","score":"54","currentage":"13","aggregate":"4.154","tableName":"timilehinadeosunscores","currentTotalAggregate":"24.692"},{"id":"12","date":"2016-04-24","exercise":"Maximizing Your Most Valuable Asset","type":"Home Work","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0.000","tableName":"timilehinadeosunscores","currentTotalAggregate":"24.692"},{"id":"13","date":"2016-05-01","exercise":"Character Custodian of Destiny","type":"Quiz","source":"Bishop David Oyedepo","score":"49","currentage":"13","aggregate":"3.769","tableName":"timilehinadeosunscores","currentTotalAggregate":"28.461"},{"id":"14","date":"2016-05-08","exercise":"The Myth of Singleness","type":"Questions","source":"Dr Myles Munroe","score":"16","currentage":"13","aggregate":"1.230","tableName":"timilehinadeosunscores","currentTotalAggregate":"29.691"},{"id":"15","date":"2016-05-15","exercise":"Being Still (Psalms 46v10)","type":"Chicken on Egg Scenario","source":"Lanre Ibironke","score":"1","currentage":"13","aggregate":"0.077","tableName":"timilehinadeosunscores","currentTotalAggregate":"29.768"},{"id":"16","date":"2016-05-22","exercise":"Selecting the Most Appropriate Word Replacement","type":"Quiz","source":"Lanre Ibironke","score":"45","currentage":"13","aggregate":"3.462","tableName":"timilehinadeosunscores","currentTotalAggregate":"33.23"},{"id":"21","date":"2016-05-29","exercise":"Personalizing Scripture","type":"Theory Question","source":"Lanre Ibironke","score":"14","currentage":"13","aggregate":"1.077","tableName":"timilehinadeosunscores","currentTotalAggregate":"34.307"},{"id":"22","date":"2016-06-05","exercise":"Inner Counsel","type":"Annotation","source":"Lanre Ibironke","score":"55","currentage":"13","aggregate":"4.231","tableName":"timilehinadeosunscores","currentTotalAggregate":"38.538"},{"id":"23","date":"2016-06-12","exercise":"Bible Questions","type":"General Quiz","source":"Lanre Ibironke","score":"33","currentage":"13","aggregate":"2.538","tableName":"timilehinadeosunscores","currentTotalAggregate":"41.076"},{"id":"24","date":"2016-06-19","exercise":"Marathon Question","type":"General Quiz 2","source":"Lanre Ibironke","score":"64","currentage":"13","aggregate":"4.923","tableName":"timilehinadeosunscores","currentTotalAggregate":"45.999"},{"id":"37","date":"2016-06-26","exercise":"Uzziah''s Story","type":"Annotation","source":"Lanre Ibironke","score":"44","currentage":"13","aggregate":"3.385","tableName":"timilehinadeosunscores","currentTotalAggregate":"46.384"},{"id":"38","date":"2016-07-03","exercise":"Multiple Choice","type":"General Quiz 3","source":"Lanre Ibironke","score":"48","currentage":"13","aggregate":"3.692","tableName":"timilehinadeosunscores","currentTotalAggregate":"53.076"},{"id":"39","date":"2016-07-10","exercise":"4-Cards","type":"Bible Game","source":"Lanre Ibironke","score":"42","currentage":"13","aggregate":"3.231","tableName":"timilehinadeosunscores","currentTotalAggregate":"56.307"},{"id":"40","date":"2016-07-24","exercise":"Memory Test","type":"Theory Questions","source":"Lanre Ibironke","score":"69","currentage":"13","aggregate":"5.308","tableName":"timilehinadeosunscores","currentTotalAggregate":"61.615"},{"id":"41","date":"2016-07-31","exercise":"Scripture Expansion","type":"Presentation","source":"Lanre Ibironke","score":"40","currentage":"14","aggregate":"2.857","tableName":"timilehinadeosunscores","currentTotalAggregate":"64.472"},{"id":"42","date":"2016-08-07","exercise":"Multiple Choice","type":"General Quiz 4","source":"Lanre Ibironke","score":"0","currentage":"14","aggregate":"0","tableName":"timilehinadeosunscores","currentTotalAggregate":"64.472"},{"id":"43","date":"2016-08-14","exercise":"Tower of Hanoi & Marriage","type":"Puzzle & Annotation","source":"Lanre Ibironke","score":"98","currentage":"14","aggregate":"7","tableName":"timilehinadeosunscores","currentTotalAggregate":"71.472"},{"id":"47","date":"2016-08-21","exercise":"The Innovative Demands of Leadership","type":"Quiz 5","source":"Myles Munroe","score":"26","currentage":"14","aggregate":"1.857","tableName":"timilehinadeosunscores","currentTotalAggregate":"73.329"},{"id":"48","date":"2016-08-28","exercise":"The Best Kept Secret","type":"Quiz 6 & Annotation","source":"Lanre Ibironke","score":"41","currentage":"14","aggregate":"2.929","tableName":"timilehinadeosunscores","currentTotalAggregate":"76.258"},{"id":"49","date":"2016-09-04","exercise":"Divine Secrets","type":"Annotation","source":"Lanre Ibironke","score":"73","currentage":"14","aggregate":"5.214","tableName":"timilehinadeosunscores","currentTotalAggregate":"81.472"},{"id":"50","date":"2016-09-11","exercise":"Repositioning for Exploits","type":"Online Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"14","aggregate":"0","tableName":"timilehinadeosunscores","currentTotalAggregate":"81.472"}]', '{"cTab":"Scripture","wQAnswered":"15","wQGotten":"15","wQMissed":"0","mQAnswered":"187","mQGotten":"119","mQMissed":"68","sTyped":"60","sWordsTyped":"Hhshj","sGotten":"0","sMissed":"60","tPoints":"798","eAForToday":"56.926","totalAggregate":"973.211","email":"fijitimi9900@gmail.com","age":"14"}');
INSERT INTO `profiles` VALUES(2, 'Eniola', 'Adewunmi', '17', 'iamboothang@gmail.com', 'cfefb695b6c30eb74335258988904b48eb8160d7', '283.042', '18th', '0', '1F54BF', 'EA', 'candygirl', 'eniolaadewunmiscores', '[{"id":"1","date":"2016-01-03","exercise":"Eternal Life","type":"Review","source":"Andrew Wommack","score":"15","currentage":"15","aggregate":"1.000","tableName":"eniolaadewunmiscores","currentTotalAggregate":"1"},{"id":"2","date":"2016-01-10","exercise":"Close Encounter of the God Kind","type":"Review","source":"Jesse Duplantis","score":"0","currentage":"15","aggregate":"0.000","tableName":"eniolaadewunmiscores","currentTotalAggregate":"1"},{"id":"3","date":"2016-01-31","exercise":"Growing Up Spiritually","type":"Review","source":"Kenneth E Hagin","score":"6","currentage":"15","aggregate":"0.400","tableName":"eniolaadewunmiscores","currentTotalAggregate":"1.4"},{"id":"4","date":"2016-02-07","exercise":"The Cost of a Crown","type":"Quiz","source":"Bishop David Oyedepo","score":"51","currentage":"15","aggregate":"3.400","tableName":"eniolaadewunmiscores","currentTotalAggregate":"4.8"},{"id":"5","date":"2016-02-14","exercise":"The Love Walk","type":"Review","source":"Kenneth E Hagin","score":"23","currentage":"15","aggregate":"1.533","tableName":"eniolaadewunmiscores","currentTotalAggregate":"6.333"},{"id":"6","date":"2016-02-21","exercise":"Opted for Group Discussion","type":"Group Discussion","source":"Youths","score":"0","currentage":"15","aggregate":"0.000","tableName":"eniolaadewunmiscores","currentTotalAggregate":"6.333"},{"id":"7","date":"2016-03-13","exercise":"Repositioning for Exploits","type":"Review","source":"Bishop David Oyedepo","score":"0","currentage":"15","aggregate":"0.000","tableName":"eniolaadewunmiscores","currentTotalAggregate":"6.333"},{"id":"8","date":"2016-03-27","exercise":"1John 4:4","type":"Synonyms","source":"Lanre Ibironke","score":"36","currentage":"16","aggregate":"2.250","tableName":"eniolaadewunmiscores","currentTotalAggregate":"8.583"},{"id":"9","date":"2016-04-03","exercise":"Hand Sequence","type":"Focus Test","source":"Lanre Ibironke","score":"41","currentage":"16","aggregate":"2.563","tableName":"eniolaadewunmiscores","currentTotalAggregate":"11.146"},{"id":"10","date":"2016-04-10","exercise":"Yesterday, Today and Tomorrow","type":"Annotation and Silence Half Hour","source":"Lanre Ibironke","score":"60","currentage":"16","aggregate":"3.750","tableName":"eniolaadewunmiscores","currentTotalAggregate":"14.896"},{"id":"11","date":"2016-04-17","exercise":"Your Abilities","type":"Annotation and Hand Sequence","source":"Lanre Ibironke","score":"28","currentage":"16","aggregate":"1.750","tableName":"eniolaadewunmiscores","currentTotalAggregate":"16.646"},{"id":"12","date":"2016-04-24","exercise":"Maximizing Your Most Valuable Asset","type":"Home Work","source":"Lanre Ibironke","score":"0","currentage":"16","aggregate":"0.000","tableName":"eniolaadewunmiscores","currentTotalAggregate":"16.646"},{"id":"13","date":"2016-05-01","exercise":"Character Custodian of Destiny","type":"Quiz","source":"Bishop David Oyedepo","score":"47","currentage":"16","aggregate":"2.938","tableName":"eniolaadewunmiscores","currentTotalAggregate":"19.584"},{"id":"14","date":"2016-05-08","exercise":"The Myth of Singleness","type":"Questions","source":"Dr Myles Munroe","score":"0","currentage":"16","aggregate":"0.000","tableName":"eniolaadewunmiscores","currentTotalAggregate":"19.584"},{"id":"15","date":"2016-05-15","exercise":"Being Still (Psalms 46v10)","type":"Chicken on Egg Scenario","source":"Lanre Ibironke","score":"2","currentage":"16","aggregate":"0.125","tableName":"eniolaadewunmiscores","currentTotalAggregate":"19.709"},{"id":"16","date":"2016-05-22","exercise":"Selecting the Most Appropriate Word Replacement","type":"Quiz","source":"Lanre Ibironke","score":"40","currentage":"16","aggregate":"2.500","tableName":"eniolaadewunmiscores","currentTotalAggregate":"22.209"},{"id":"17","date":"2016-05-29","exercise":"Personalizing Scripture","type":"Theory Question","source":"Lanre Ibironke","score":"0","currentage":"16","aggregate":"0","tableName":"eniolaadewunmiscores","currentTotalAggregate":"22.209"},{"id":"18","date":"2016-06-05","exercise":"Inner Counsel","type":"Annotation","source":"Lanre Ibironke","score":"65","currentage":"16","aggregate":"4.063","tableName":"eniolaadewunmiscores","currentTotalAggregate":"26.272"},{"id":"19","date":"2016-06-12","exercise":"Bible Questions","type":"General Quiz","source":"Lanre Ibironke","score":"45","currentage":"16","aggregate":"2.813","tableName":"eniolaadewunmiscores","currentTotalAggregate":"29.085"},{"id":"20","date":"2016-06-19","exercise":"Marathon Question","type":"General Quiz 2","source":"Lanre Ibironke","score":"120","currentage":"16","aggregate":"7.5","tableName":"eniolaadewunmiscores","currentTotalAggregate":"36.585"},{"id":"21","date":"2016-06-26","exercise":"Uzziah''s Story","type":"Annotation","source":"Lanre Ibironke","score":"40","currentage":"16","aggregate":"2.5","tableName":"eniolaadewunmiscores","currentTotalAggregate":"39.085"},{"id":"22","date":"2016-07-03","exercise":"Multiple Choice","type":"General Quiz 3","source":"Lanre Ibironke","score":"60","currentage":"16","aggregate":"3.75","tableName":"eniolaadewunmiscores","currentTotalAggregate":"42.835"},{"id":"23","date":"2016-07-10","exercise":"4-Cards","type":"Bible Game","source":"Lanre Ibironke","score":"45","currentage":"16","aggregate":"2.813","tableName":"eniolaadewunmiscores","currentTotalAggregate":"45.648"},{"id":"24","date":"2016-07-24","exercise":"Memory Test","type":"Theory Questions","source":"Lanre Ibironke","score":"78","currentage":"16","aggregate":"4.875","tableName":"eniolaadewunmiscores","currentTotalAggregate":"50.523"},{"id":"25","date":"2016-07-31","exercise":"Scripture Expansion","type":"Presentation","source":"Lanre Ibironke","score":"75","currentage":"16","aggregate":"4.688","tableName":"eniolaadewunmiscores","currentTotalAggregate":"55.211"},{"id":"26","date":"2016-08-07","exercise":"Multiple Choice","type":"General Quiz 4","source":"Lanre Ibironke","score":"0","currentage":"16","aggregate":"0","tableName":"eniolaadewunmiscores","currentTotalAggregate":"55.211"},{"id":"27","date":"2016-08-14","exercise":"Tower of Hanoi & Marriage","type":"Puzzle  & Annotation","source":"Lanre Ibironke","score":"49","currentage":"16","aggregate":"3.063","tableName":"eniolaadewunmiscores","currentTotalAggregate":"58.274"},{"id":"28","date":"2016-08-21","exercise":"The Innovative Demands of Leadership","type":"Quiz 5","source":"Myles Munroe","score":"50","currentage":"16","aggregate":"3.125","tableName":"eniolaadewunmiscores","currentTotalAggregate":"61.399"},{"id":"29","date":"2016-08-28","exercise":"The Best Kept Secret","type":"Quiz 6 & Annotation","source":"Lanre Ibironke","score":"45","currentage":"16","aggregate":"2.813","tableName":"eniolaadewunmiscores","currentTotalAggregate":"64.212"},{"id":"30","date":"2016-09-04","exercise":"Divine Secrets","type":"Annotation","source":"Lanre Ibironke","score":"110","currentage":"16","aggregate":"6.875","tableName":"eniolaadewunmiscores","currentTotalAggregate":"71.087"},{"id":"31","date":"2016-09-11","exercise":"Repositioning for Exploits","type":"Online Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"16","aggregate":"0","tableName":"eniolaadewunmiscores","currentTotalAggregate":"71.087"}]', '');
INSERT INTO `profiles` VALUES(3, 'Desola', 'Oladipupo', '17', 'desolaoladipupo@gmail.com', '93d2917689be25151a03d6cf20e337c39ba9d448', '1457.595', '1st', '59', '722386', 'DO', 'Dide4life', 'desolaoladipuposcores', '[{"id":"1","date":"2016-01-03","exercise":"Eternal Life","type":"Review","source":"Andrew Wommack","score":"0","currentage":"16","aggregate":"0.000","tableName":"desolaoladipuposcores","currentTotalAggregate":"0"},{"id":"2","date":"2016-01-10","exercise":"Close Encounter of the God Kind","type":"Review","source":"Jesse Duplantis","score":"9","currentage":"16","aggregate":"0.563","tableName":"desolaoladipuposcores","currentTotalAggregate":"0.563"},{"id":"3","date":"2016-01-31","exercise":"Growing Up Spiritually","type":"Review","source":"Kenneth E Hagin","score":"0","currentage":"16","aggregate":"0.000","tableName":"desolaoladipuposcores","currentTotalAggregate":"0.563"},{"id":"4","date":"2016-02-07","exercise":"The Cost of a Crown","type":"Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"16","aggregate":"0.000","tableName":"desolaoladipuposcores","currentTotalAggregate":"0.563"},{"id":"5","date":"2016-02-14","exercise":"The Love Walk","type":"Review","source":"Kenneth E Hagin","score":"0","currentage":"16","aggregate":"0.000","tableName":"desolaoladipuposcores","currentTotalAggregate":"0.563"},{"id":"6","date":"2016-02-21","exercise":"Opted for Group Discussion","type":"Group Discussion","source":"Youths","score":"0","currentage":"16","aggregate":"0.000","tableName":"desolaoladipuposcores","currentTotalAggregate":"0.563"},{"id":"7","date":"2016-03-13","exercise":"Repositioning for Exploits","type":"Review","source":"Bishop David Oyedepo","score":"21","currentage":"16","aggregate":"1.313","tableName":"desolaoladipuposcores","currentTotalAggregate":"1.876"},{"id":"8","date":"2016-03-27","exercise":"1John 4:4","type":"Synonyms","source":"Lanre Ibironke","score":"0","currentage":"16","aggregate":"0.000","tableName":"desolaoladipuposcores","currentTotalAggregate":"1.876"},{"id":"9","date":"2016-04-03","exercise":"Hand Sequence","type":"Focus Test","source":"Lanre Ibironke","score":"0","currentage":"16","aggregate":"0.000","tableName":"desolaoladipuposcores","currentTotalAggregate":"1.876"},{"id":"10","date":"2016-04-10","exercise":"Yesterday, Today and Tomorrow","type":"Annotation and Silence Half Hour","source":"Lanre Ibironke","score":"90","currentage":"16","aggregate":"5.625","tableName":"desolaoladipuposcores","currentTotalAggregate":"7.501"},{"id":"11","date":"2016-04-17","exercise":"Your Abilities","type":"Annotation & Hand Sequence","source":"Lanre Ibironke","score":"107","currentage":"16","aggregate":"6.688","tableName":"desolaoladipuposcores","currentTotalAggregate":"14.189"},{"id":"12","date":"2016-04-24","exercise":"Maximizing Your Most Valuable Asset","type":"Home Work","source":"Lanre Ibironke","score":"31","currentage":"16","aggregate":"1.938","tableName":"desolaoladipuposcores","currentTotalAggregate":"16.127"},{"id":"13","date":"2016-05-01","exercise":"Character Custodian of Destiny","type":"Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"16","aggregate":"0.000","tableName":"desolaoladipuposcores","currentTotalAggregate":"16.127"},{"id":"14","date":"2016-05-08","exercise":"The Myth of Singleness","type":"Question","source":"Dr Myles Munroe","score":"0","currentage":"16","aggregate":"0.000","tableName":"desolaoladipuposcores","currentTotalAggregate":"16.127"},{"id":"15","date":"2016-05-15","exercise":"Being Still (Psalms 46vs10)","type":"Chicken on Egg Scenario","source":"Lanre Ibironke","score":"0","currentage":"16","aggregate":"0.000","tableName":"desolaoladipuposcores","currentTotalAggregate":"16.127"},{"id":"16","date":"2016-05-22","exercise":"Selecting the Most Appropriate Word Replacement","type":"Quiz","source":"Lanre Ibironke","score":"0","currentage":"16","aggregate":"0.000","tableName":"desolaoladipuposcores","currentTotalAggregate":"16.127"},{"id":"17","date":"2016-05-29","exercise":"Personalizing Scripture","type":"Theory Question","source":"Lanre Ibironke","score":"0","currentage":"16","aggregate":"0","tableName":"desolaoladipuposcores","currentTotalAggregate":"16.127"},{"id":"18","date":"2016-06-05","exercise":"Inner Counsel","type":"Annotation","source":"Lanre Ibironke","score":"55","currentage":"16","aggregate":"3.438","tableName":"desolaoladipuposcores","currentTotalAggregate":"19.565"},{"id":"19","date":"2016-06-12","exercise":"Bible Questions","type":"General Quiz","source":"Lanre Ibironke","score":"39","currentage":"16","aggregate":"2.438","tableName":"desolaoladipuposcores","currentTotalAggregate":"22.003"},{"id":"20","date":"2016-06-19","exercise":"Marathon Question","type":"General Quiz 2","source":"Lanre Ibironke","score":"156","currentage":"16","aggregate":"9.75","tableName":"desolaoladipuposcores","currentTotalAggregate":"31.753"},{"id":"21","date":"2016-06-26","exercise":"Uzziah''s Story","type":"Annotation","source":"Lanre Ibironke","score":"34","currentage":"16","aggregate":"2.125","tableName":"desolaoladipuposcores","currentTotalAggregate":"33.878"},{"id":"22","date":"2016-07-03","exercise":"Multiple Choice","type":"General Quiz 3","source":"Lanre Ibironke","score":"0","currentage":"16","aggregate":"0","tableName":"desolaoladipuposcores","currentTotalAggregate":"33.878"},{"id":"23","date":"2016-07-10","exercise":"4-Cards","type":"Bible Game","source":"Lanre Ibironke","score":"0","currentage":"16","aggregate":"0","tableName":"desolaoladipuposcores","currentTotalAggregate":"33.878"},{"id":"24","date":"2016-07-24","exercise":"Memory Test","type":"Theory Questions","source":"Lanre Ibironke","score":"0","currentage":"16","aggregate":"0","tableName":"desolaoladipuposcores","currentTotalAggregate":"33.878"},{"id":"25","date":"2016-07-31","exercise":"Scripture Expansion","type":"Presentation","source":"Lanre Ibironke","score":"0","currentage":"16","aggregate":"0","tableName":"desolaoladipuposcores","currentTotalAggregate":"33.878"},{"id":"26","date":"2016-08-07","exercise":"Multiple Choice","type":"General Quiz 4","source":"Lanre Ibironke","score":"0","currentage":"16","aggregate":"0","tableName":"desolaoladipuposcores","currentTotalAggregate":"33.878"},{"id":"27","date":"2016-08-14","exercise":"Tower of Hanoi & Marriage","type":"Puzzle  & Annotation","source":"Lanre Ibironke","score":"59","currentage":"16","aggregate":"3.688","tableName":"desolaoladipuposcores","currentTotalAggregate":"37.566"},{"id":"28","date":"2016-08-21","exercise":"The Innovative Demands of Leadership","type":"Quiz 5","source":"Myles Munroe","score":"77","currentage":"16","aggregate":"4.813","tableName":"desolaoladipuposcores","currentTotalAggregate":"42.379"},{"id":"29","date":"2016-08-28","exercise":"The Best Kept Secret","type":"Quiz 6 & Annotation","source":"Lanre Ibironke","score":"115","currentage":"17","aggregate":"6.765","tableName":"desolaoladipuposcores","currentTotalAggregate":"49.144"},{"id":"30","date":"2016-09-04","exercise":"Divine Secrets","type":"Annotation","source":"Lanre Ibironke","score":"65","currentage":"17","aggregate":"3.824","tableName":"desolaoladipuposcores","currentTotalAggregate":"52.967999999999996"},{"id":"33","date":"2016-09-11","exercise":"Repositioning for Exploits","type":"Online Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"17","aggregate":"0","tableName":"desolaoladipuposcores","currentTotalAggregate":"52.968"}]', '{"cTab":"Scripture","wQAnswered":"15","wQGotten":"15","wQMissed":"0","mQAnswered":"187","mQGotten":"155","mQMissed":"32","sTyped":"13","sWordsTyped":"Proverbs 7:13-So she caught him and kissed him and with impudent face she said to him,","sGotten":"9","sMissed":"4","tPoints":"931","eAForToday":"54.75","totalAggregate":"1457.595","email":"desolaoladipupo@gmail.com","age":"17"}');
INSERT INTO `profiles` VALUES(4, 'Wadud', 'Adamu', '14', 'swagpancakeyt@gmail.com', '55d483cea004e568cfdec7db383fceff2e745e86', '306.708', '17th', '0', '212334', 'WA', 'SwagPancakeXL', 'wadudadamuscores', '[{"id":"1","date":"2016-01-03","exercise":"Eternal Life","type":"Review","source":"Andrew Wommack","score":"10","currentage":"13","aggregate":"0.769","tableName":"wadudadamuscores","currentTotalAggregate":"0.769"},{"id":"2","date":"2016-01-10","exercise":"Close Encounter of the God Kind","type":"Review","source":"Jesse Duplantis","score":"3","currentage":"13","aggregate":"0.231","tableName":"wadudadamuscores","currentTotalAggregate":"1"},{"id":"3","date":"2016-01-31","exercise":"Growing Up Spiritually","type":"Review","source":"Kenneth E Hagin","score":"0","currentage":"13","aggregate":"0.000","tableName":"wadudadamuscores","currentTotalAggregate":"1"},{"id":"4","date":"2016-02-07","exercise":"The Cost of a Crown","type":"Quiz","source":"Bishop David Oyedepo","score":"43","currentage":"13","aggregate":"3.308","tableName":"wadudadamuscores","currentTotalAggregate":"4.308"},{"id":"5","date":"2016-02-14","exercise":"The Love Walk","type":"Review","source":"Kenneth E Hagin","score":"18","currentage":"13","aggregate":"1.385","tableName":"wadudadamuscores","currentTotalAggregate":"5.693"},{"id":"6","date":"2016-02-21","exercise":"Opted for Group Discussion","type":"Group Discussion","source":"Youths","score":"0","currentage":"13","aggregate":"0.000","tableName":"wadudadamuscores","currentTotalAggregate":"5.693"},{"id":"7","date":"2016-03-13","exercise":"Repositioning for Exploits","type":"Review","source":"Bishop David Oyedepo","score":"6","currentage":"13","aggregate":"0.461","tableName":"wadudadamuscores","currentTotalAggregate":"6.154"},{"id":"8","date":"2016-03-27","exercise":"1John 4:4","type":"Synonyms","source":"Lanre Ibironke","score":"8","currentage":"13","aggregate":"0.615","tableName":"wadudadamuscores","currentTotalAggregate":"6.769"},{"id":"9","date":"2016-04-03","exercise":"Hand Sequence","type":"Focus Test","source":"Lanre Ibironke","score":"28","currentage":"13","aggregate":"2.154","tableName":"wadudadamuscores","currentTotalAggregate":"8.923"},{"id":"10","date":"2016-04-10","exercise":"Yesterday, Today and Tomorrow","type":"Annotation and Silence Half Hour","source":"Lanre Ibironke","score":"54","currentage":"13","aggregate":"4.154","tableName":"wadudadamuscores","currentTotalAggregate":"13.077"},{"id":"11","date":"2016-04-17","exercise":"Your Abilities","type":"Annotation and Hand Sequence","source":"Lanre Ibironke","score":"18","currentage":"13","aggregate":"1.385","tableName":"wadudadamuscores","currentTotalAggregate":"14.462"},{"id":"12","date":"2016-04-24","exercise":"Maximizing Your Most Valuable Asset","type":"Home Work","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0.000","tableName":"wadudadamuscores","currentTotalAggregate":"14.462"},{"id":"13","date":"2016-05-01","exercise":"Character Custodian of Destiny","type":"Quiz","source":"Bishop David Oyedepo","score":"53","currentage":"13","aggregate":"4.077","tableName":"wadudadamuscores","currentTotalAggregate":"18.539"},{"id":"14","date":"2016-05-08","exercise":"The Myth of Singleness","type":"Questions","source":"Dr Myles Munroe","score":"0","currentage":"13","aggregate":"0.000","tableName":"wadudadamuscores","currentTotalAggregate":"18.539"},{"id":"15","date":"2016-05-15","exercise":"Being Still (Psalms 46vs10)","type":"Chicken on Egg Scenario","source":"Lanre Ibironke","score":"3","currentage":"13","aggregate":"0.231","tableName":"wadudadamuscores","currentTotalAggregate":"18.77"},{"id":"16","date":"2016-05-22","exercise":"Selecting the Most Appropriate Word Replacement","type":"Quiz","source":"Lanre Ibironke","score":"45","currentage":"13","aggregate":"3.462","tableName":"wadudadamuscores","currentTotalAggregate":"22.232"},{"id":"17","date":"2016-05-29","exercise":"Personalizing Scripture","type":"Theory Question","source":"Lanre Ibironke","score":"15","currentage":"13","aggregate":"1.154","tableName":"wadudadamuscores","currentTotalAggregate":"23.386"},{"id":"18","date":"2016-06-05","exercise":"Inner Counsel","type":"Annotation","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0","tableName":"wadudadamuscores","currentTotalAggregate":"23.386"},{"id":"19","date":"2016-06-12","exercise":"Bible Questions","type":"General Quiz","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0","tableName":"wadudadamuscores","currentTotalAggregate":"23.386"},{"id":"20","date":"2016-06-19","exercise":"Marathon Question","type":"General Quiz 2","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0","tableName":"wadudadamuscores","currentTotalAggregate":"23.386"},{"id":"21","date":"2016-06-26","exercise":"Uzziah''s Story","type":"Annotation","source":"Lanre Ibironke","score":"14","currentage":"13","aggregate":"1.077","tableName":"wadudadamuscores","currentTotalAggregate":"24.463"},{"id":"22","date":"2016-07-03","exercise":"Multiple Choice","type":"General Quiz 3","source":"Lanre Ibironke","score":"51","currentage":"13","aggregate":"3.923","tableName":"wadudadamuscores","currentTotalAggregate":"28.386"},{"id":"23","date":"2016-07-10","exercise":"4-Cards","type":"Bible Game","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0","tableName":"wadudadamuscores","currentTotalAggregate":"28.386"},{"id":"24","date":"2016-07-24","exercise":"Memory Test","type":"Theory Questions","source":"Lanre Ibironke","score":"81","currentage":"13","aggregate":"6.231","tableName":"wadudadamuscores","currentTotalAggregate":"34.617"},{"id":"25","date":"2016-07-31","exercise":"Scripture Expansion","type":"Presentation","source":"Lanre Ibironke","score":"29","currentage":"14","aggregate":"2.071","tableName":"wadudadamuscores","currentTotalAggregate":"36.688"},{"id":"26","date":"2016-08-07","exercise":"Multiple Choice","type":"General Quiz 4","source":"Lanre Ibironke","score":"0","currentage":"14","aggregate":"0","tableName":"wadudadamuscores","currentTotalAggregate":"36.688"},{"id":"27","date":"2016-08-14","exercise":"Tower of Hanoi & Marriage","type":"Puzzle  & Annotation","source":"Lanre Ibironke","score":"0","currentage":"14","aggregate":"0","tableName":"wadudadamuscores","currentTotalAggregate":"36.688"},{"id":"28","date":"2016-08-21","exercise":"The Innovative Demands of Leadership","type":"Quiz 5","source":"Myles Munroe","score":"47","currentage":"14","aggregate":"3.357","tableName":"wadudadamuscores","currentTotalAggregate":"40.045"},{"id":"29","date":"2016-08-28","exercise":"The Best Kept Secret","type":"Quiz 6 & Annotation","source":"Lanre Ibironke","score":"26","currentage":"14","aggregate":"1.857","tableName":"wadudadamuscores","currentTotalAggregate":"41.902"},{"id":"30","date":"2016-09-04","exercise":"Divine Secrets","type":"Annotation","source":"Lanre Ibironke","score":"0","currentage":"14","aggregate":"0","tableName":"wadudadamuscores","currentTotalAggregate":"41.902"},{"id":"31","date":"2016-09-11","exercise":"Repositioning for Exploits","type":"Online Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"14","aggregate":"0","tableName":"wadudadamuscores","currentTotalAggregate":"41.902"}]', '');
INSERT INTO `profiles` VALUES(5, 'Sefunmi', 'Adewunmi', '12', 'sefunmiadewumi8@gmail.com', '500c61e8fc1874799016e9f31acc6783f4697318', '712.028', '8th', '0', '730202', 'SA', 'Shepherd', 'sefunmiadewunmiscores', '[{"id":"1","date":"2016-01-03","exercise":"Eternal Life","type":"Review","source":"Andrew Wommack","score":"0","currentage":"10","aggregate":"0.000","tableName":"sefunmiadewunmiscores","currentTotalAggregate":"0"},{"id":"2","date":"2016-01-10","exercise":"Close Encounter of the God Kind","type":"Review","source":"Jesse Duplantis","score":"3","currentage":"10","aggregate":"0.300","tableName":"sefunmiadewunmiscores","currentTotalAggregate":"0.3"},{"id":"3","date":"2016-01-31","exercise":"Growing Up Spiritually","type":"Review","source":"Kenneth E Hagin","score":"4","currentage":"10","aggregate":"0.400","tableName":"sefunmiadewunmiscores","currentTotalAggregate":"0.7"},{"id":"4","date":"2016-02-07","exercise":"The Cost of a Crown","type":"Quiz","source":"Bishop David Oyedepo","score":"13","currentage":"10","aggregate":"1.300","tableName":"sefunmiadewunmiscores","currentTotalAggregate":"2"},{"id":"5","date":"2016-02-14","exercise":"The Love Walk","type":"Review","source":"Kenneth E Hagin","score":"11","currentage":"10","aggregate":"1.100","tableName":"sefunmiadewunmiscores","currentTotalAggregate":"3.1"},{"id":"6","date":"2016-02-21","exercise":"Opted for Group Discussion","type":"Group Discussion","source":"Youths","score":"0","currentage":"10","aggregate":"0.000","tableName":"sefunmiadewunmiscores","currentTotalAggregate":"3.1"},{"id":"7","date":"2016-03-13","exercise":"Repositioning for Exploits","type":"Review","source":"Bishop David Oyedepo","score":"2","currentage":"10","aggregate":"0.200","tableName":"sefunmiadewunmiscores","currentTotalAggregate":"3.3"},{"id":"8","date":"2016-03-27","exercise":"1John 4:4","type":"Synonyms","source":"Lanre Ibironke","score":"11","currentage":"10","aggregate":"1.100","tableName":"sefunmiadewunmiscores","currentTotalAggregate":"4.4"},{"id":"9","date":"2016-04-03","exercise":"Hand Sequence","type":"Focus Test","source":"Lanre Ibironke","score":"44","currentage":"11","aggregate":"4.000","tableName":"sefunmiadewunmiscores","currentTotalAggregate":"8.4"},{"id":"10","date":"2016-04-10","exercise":"Yesterday, Today and Tomorrow","type":"Annotation and Silence Half Hour","source":"Lanre Ibironke","score":"44","currentage":"11","aggregate":"4.000","tableName":"sefunmiadewunmiscores","currentTotalAggregate":"12.4"},{"id":"11","date":"2016-04-17","exercise":"Your Abilities","type":"Annotation and Hand Sequence","source":"Lanre Ibironke","score":"8","currentage":"11","aggregate":"0.727","tableName":"sefunmiadewunmiscores","currentTotalAggregate":"13.127"},{"id":"12","date":"2016-04-24","exercise":"Maximizing Your Most Valuable Asset","type":"Home Work","source":"Lanre Ibironke","score":"0","currentage":"11","aggregate":"0.000","tableName":"sefunmiadewunmiscores","currentTotalAggregate":"13.127"},{"id":"13","date":"2016-05-01","exercise":"Character Custodian of Destiny","type":"Quiz","source":"Bishop David Oyedepo","score":"27","currentage":"11","aggregate":"2.455","tableName":"sefunmiadewunmiscores","currentTotalAggregate":"15.582"},{"id":"14","date":"2016-05-08","exercise":"The Myth of Singleness","type":"Questions","source":"Dr Myles Munroe","score":"18","currentage":"11","aggregate":"1.636","tableName":"sefunmiadewunmiscores","currentTotalAggregate":"17.218"},{"id":"15","date":"2016-05-15","exercise":"Being Still (Psalms 46v10)","type":"Chicken on Egg Scenario","source":"Lanre Ibironke","score":"2","currentage":"11","aggregate":"0.182","tableName":"sefunmiadewunmiscores","currentTotalAggregate":"17.4"},{"id":"16","date":"2016-05-22","exercise":"Selecting the Most Appropriate Word Replacement","type":"Quiz","source":"Lanre Ibironke","score":"45","currentage":"11","aggregate":"4.091","tableName":"sefunmiadewunmiscores","currentTotalAggregate":"21.491"},{"id":"20","date":"2016-05-29","exercise":"Personalizing Scripture","type":"Theory Question","source":"Lanre Ibironke","score":"31","currentage":"11","aggregate":"2.818","tableName":"sefunmiadewunmiscores","currentTotalAggregate":"24.309"},{"id":"21","date":"2016-06-05","exercise":"Inner Counsel","type":"Annotation","source":"Lanre Ibironke","score":"65","currentage":"11","aggregate":"5.909","tableName":"sefunmiadewunmiscores","currentTotalAggregate":"30.218"},{"id":"22","date":"2016-06-12","exercise":"Bible Questions","type":"General Quiz","source":"Lanre Ibironke","score":"48","currentage":"11","aggregate":"4.364","tableName":"sefunmiadewunmiscores","currentTotalAggregate":"34.582"},{"id":"23","date":"2016-06-19","exercise":"Marathon Question","type":"General Quiz 2","source":"Lanre Ibironke","score":"137","currentage":"11","aggregate":"12.455","tableName":"sefunmiadewunmiscores","currentTotalAggregate":"47.037"},{"id":"24","date":"2016-06-26","exercise":"Uzziah''s Story","type":"Annotation","source":"Lanre Ibironke","score":"21","currentage":"11","aggregate":"1.909","tableName":"sefunmiadewunmiscores","currentTotalAggregate":"48.946"},{"id":"25","date":"2016-07-03","exercise":"Multiple Choice","type":"General Quiz 3","source":"Lanre Ibironke","score":"48","currentage":"11","aggregate":"4.364","tableName":"sefunmiadewunmiscores","currentTotalAggregate":"53.31"},{"id":"26","date":"2016-07-10","exercise":"4-Cards","type":"Bible Game","source":"Lanre Ibironke","score":"39","currentage":"11","aggregate":"3.545","tableName":"sefunmiadewunmiscores","currentTotalAggregate":"56.855"},{"id":"27","date":"2016-07-24","exercise":"Memory Test","type":"Theory Questions","source":"Lanre Ibironke","score":"56","currentage":"11","aggregate":"5.091","tableName":"sefunmiadewunmiscores","currentTotalAggregate":"61.946"},{"id":"28","date":"2016-07-31","exercise":"Scripture Expansion","type":"Presentation","source":"Lanre Ibironke","score":"18","currentage":"11","aggregate":"1.636","tableName":"sefunmiadewunmiscores","currentTotalAggregate":"63.582"},{"id":"29","date":"2016-08-07","exercise":"Multiple Choice","type":"General Quiz 4","source":"Lanre Ibironke","score":"0","currentage":"11","aggregate":"0","tableName":"sefunmiadewunmiscores","currentTotalAggregate":"63.582"},{"id":"30","date":"2016-08-14","exercise":"Tower of Hanoi & Marriage","type":"Puzzle  & Annotation","source":"Lanre Ibironke","score":"0","currentage":"11","aggregate":"0","tableName":"sefunmiadewunmiscores","currentTotalAggregate":"63.582"},{"id":"31","date":"2016-08-21","exercise":"The Innovative Demands of Leadership","type":"Quiz 5","source":"Myles Munroe","score":"39","currentage":"11","aggregate":"3.545","tableName":"sefunmiadewunmiscores","currentTotalAggregate":"67.127"},{"id":"32","date":"2016-08-28","exercise":"The Best Kept Secret","type":"Quiz 6 & Annotation","source":"Lanre Ibironke","score":"14","currentage":"11","aggregate":"1.273","tableName":"sefunmiadewunmiscores","currentTotalAggregate":"68.4"},{"id":"33","date":"2016-09-04","exercise":"Divine Secrets","type":"Annotation","source":"Lanre Ibironke","score":"40","currentage":"11","aggregate":"3.636","tableName":"sefunmiadewunmiscores","currentTotalAggregate":"72.036"},{"id":"34","date":"2016-09-11","exercise":"Repositioning for Exploits","type":"Online Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"11","aggregate":"0","tableName":"sefunmiadewunmiscores","currentTotalAggregate":"72.036"}]', '{"cTab":"Message","wQAnswered":"15","wQGotten":"15","wQMissed":"0","mQAnswered":"84","mQGotten":"68","mQMissed":"16","sTyped":"0","sWordsTyped":"","sGotten":"0","sMissed":"0","tPoints":"431","eAForToday":"35.939","totalAggregate":"712.028","email":"sefunmiadewumi8@gmail.com","age":"12"}');
INSERT INTO `profiles` VALUES(6, 'Fola', 'Adeniyi', '11', 'folaadeniyi@gmail.com', '42b2edd950b35110362d8fcd8af278fc7f484603', '855.241', '7th', '30', '584C40', 'FA', 'fo', 'folaadeniyiscores', '[{"id":"1","date":"2016-01-03","exercise":"Eternal Life","type":"Review","source":"Andrew Wommack","score":"0","currentage":"9","aggregate":"0.000","tableName":"folaadeniyiscores","currentTotalAggregate":"0"},{"id":"2","date":"2016-01-10","exercise":"Close Encounter of the God Kind","type":"Review","source":"Jesse Duplantis","score":"0","currentage":"9","aggregate":"0.000","tableName":"folaadeniyiscores","currentTotalAggregate":"0"},{"id":"3","date":"2016-01-31","exercise":"Growing Up Spiritually","type":"Review","source":"Kenneth E Hagin","score":"0","currentage":"9","aggregate":"0.000","tableName":"folaadeniyiscores","currentTotalAggregate":"0"},{"id":"4","date":"2016-02-07","exercise":"The Cost of a Crown","type":"Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"9","aggregate":"0.000","tableName":"folaadeniyiscores","currentTotalAggregate":"0"},{"id":"5","date":"2016-02-14","exercise":"The Love Walk","type":"Review","source":"Kenneth E Hagin","score":"0","currentage":"9","aggregate":"0.000","tableName":"folaadeniyiscores","currentTotalAggregate":"0"},{"id":"6","date":"2016-02-21","exercise":"Opted for Group Discussion","type":"Group Discussion","source":"Youths","score":"0","currentage":"9","aggregate":"0.000","tableName":"folaadeniyiscores","currentTotalAggregate":"0"},{"id":"7","date":"2016-03-13","exercise":"Repositioning for Exploits","type":"Review","source":"Bishop David Oyedepo","score":"0","currentage":"9","aggregate":"0.000","tableName":"folaadeniyiscores","currentTotalAggregate":"0"},{"id":"8","date":"2016-03-27","exercise":"1John 4:4","type":"Synonyms","source":"Lanre Ibironke","score":"37","currentage":"10","aggregate":"3.700","tableName":"folaadeniyiscores","currentTotalAggregate":"3.7"},{"id":"9","date":"2016-04-03","exercise":"Hand Sequence ","type":"Focus Test","source":"Lanre Ibironke","score":"43","currentage":"10","aggregate":"4.300","tableName":"folaadeniyiscores","currentTotalAggregate":"8"},{"id":"10","date":"2016-04-10","exercise":"Yesterday, Today and Tomorrow","type":"Annotation and Silence Half Hour","source":"Lanre Ibironke","score":"0","currentage":"10","aggregate":"0.000","tableName":"folaadeniyiscores","currentTotalAggregate":"8"},{"id":"11","date":"2016-04-17","exercise":"Your Abilities","type":"Annotation and Hand Sequence","source":"Lanre Ibironke","score":"45","currentage":"10","aggregate":"4.500","tableName":"folaadeniyiscores","currentTotalAggregate":"12.5"},{"id":"12","date":"2016-04-24","exercise":"Maximizing Your Most Valuable Asset","type":"Home Work","source":"Lanre Ibironke","score":"0","currentage":"10","aggregate":"0.000","tableName":"folaadeniyiscores","currentTotalAggregate":"12.5"},{"id":"13","date":"2016-05-01","exercise":"Word Finder","type":"Bible Word Guess","source":"Lanre Ibironke","score":"17","currentage":"10","aggregate":"1.7","tableName":"folaadeniyiscores","currentTotalAggregate":"14.2"},{"id":"14","date":"2016-05-08","exercise":"The Myth of Singleness","type":"Questions","source":"Dr Myles Munroe","score":"15","currentage":"10","aggregate":"1.500","tableName":"folaadeniyiscores","currentTotalAggregate":"15.7"},{"id":"15","date":"2016-05-15","exercise":"Being Still (Psalms 46vs10)","type":"Chicken on Egg Scenario","source":"Lanre Ibironke","score":"3","currentage":"10","aggregate":"0.300","tableName":"folaadeniyiscores","currentTotalAggregate":"16"},{"id":"16","date":"2016-05-22","exercise":"Selecting the Most Appropriate Word Replacement","type":"Quiz","source":"Lanre Ibironke","score":"40","currentage":"10","aggregate":"4.000","tableName":"folaadeniyiscores","currentTotalAggregate":"20"},{"id":"17","date":"2016-05-29","exercise":"Personalizing Scripture","type":"Theory Question","source":"Lanre Ibironke","score":"47","currentage":"10","aggregate":"4.7","tableName":"folaadeniyiscores","currentTotalAggregate":"24.7"},{"id":"18","date":"2016-06-05","exercise":"Inner Counsel","type":"Annotation","source":"Lanre Ibironke","score":"40","currentage":"10","aggregate":"4","tableName":"folaadeniyiscores","currentTotalAggregate":"28.7"},{"id":"19","date":"2016-06-12","exercise":"Bible Questions","type":"General Quiz","source":"Lanre Ibironke","score":"42","currentage":"10","aggregate":"4.2","tableName":"folaadeniyiscores","currentTotalAggregate":"32.9"},{"id":"20","date":"2016-06-19","exercise":"Marathon Question","type":"General Quiz 2","source":"Lanre Ibironke","score":"28","currentage":"10","aggregate":"2.8","tableName":"folaadeniyiscores","currentTotalAggregate":"35.7"},{"id":"21","date":"2016-06-26","exercise":"Uzziah''s Story","type":"Annotation","source":"Lanre Ibironke","score":"14","currentage":"10","aggregate":"1.4","tableName":"folaadeniyiscores","currentTotalAggregate":"37.1"},{"id":"22","date":"2016-07-03","exercise":"Multiple Choice","type":"General Quiz 3","source":"Lanre Ibironke","score":"43","currentage":"10","aggregate":"4.3","tableName":"folaadeniyiscores","currentTotalAggregate":"41.4"},{"id":"23","date":"2016-07-10","exercise":"4-Cards","type":"Bible Game","source":"Lanre Ibironke","score":"21","currentage":"10","aggregate":"2.1","tableName":"folaadeniyiscores","currentTotalAggregate":"43.5"},{"id":"24","date":"2016-07-24","exercise":"Memory Test","type":"Theory Questions","source":"Lanre Ibironke","score":"0","currentage":"10","aggregate":"0","tableName":"folaadeniyiscores","currentTotalAggregate":"43.5"},{"id":"25","date":"2016-07-31","exercise":"Scripture Expansion","type":"Presentation","source":"Lanre Ibironke","score":"24","currentage":"10","aggregate":"2.4","tableName":"folaadeniyiscores","currentTotalAggregate":"45.9"},{"id":"26","date":"2016-08-07","exercise":"Multiple Choice","type":"General Quiz 4","source":"Lanre Ibironke","score":"41","currentage":"10","aggregate":"4.1","tableName":"folaadeniyiscores","currentTotalAggregate":"50"},{"id":"27","date":"2016-08-14","exercise":"Tower of Hanoi & Marriage","type":"Puzzle  & Annotation","source":"Lanre Ibironke","score":"30","currentage":"10","aggregate":"3","tableName":"folaadeniyiscores","currentTotalAggregate":"53"},{"id":"28","date":"2016-08-21","exercise":"The Innovative Demands of Leadership","type":"Quiz 5","source":"Myles Munroe","score":"0","currentage":"10","aggregate":"0","tableName":"folaadeniyiscores","currentTotalAggregate":"53"},{"id":"29","date":"2016-08-28","exercise":"The Best Kept Secret","type":"Quiz 6 & Annotation","source":"Lanre Ibironke","score":"42","currentage":"10","aggregate":"4.2","tableName":"folaadeniyiscores","currentTotalAggregate":"57.2"},{"id":"30","date":"2016-09-04","exercise":"Divine Secrets","type":"Annotation","source":"Lanre Ibironke","score":"0","currentage":"10","aggregate":"0","tableName":"folaadeniyiscores","currentTotalAggregate":"57.2"},{"id":"31","date":"2016-09-11","exercise":"Repositioning for Exploits","type":"Online Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"10","aggregate":"0","tableName":"folaadeniyiscores","currentTotalAggregate":"57.2"}]', '');
INSERT INTO `profiles` VALUES(7, 'Ayo', 'Adewusi', '14', 'roselene.johnson@gmail.com', 'ef9e7e0a0b43106d89fe400b0d0f5e3e772273f5', '61.701', '23rd', '0', '24870B', 'AA', 'My Little Pony', 'ayoadewusiscores', '[{"id":"1","date":"2016-01-03","exercise":"Eternal Life","type":"Review","source":"Andrew Wommack","score":"0","currentage":"13","aggregate":"0.000","tableName":"ayoadewusiscores","currentTotalAggregate":"0"},{"id":"2","date":"2016-01-10","exercise":"Close Encounter of the God Kind","type":"Review","source":"Jesse Duplantis","score":"6","currentage":"13","aggregate":"0.462","tableName":"ayoadewusiscores","currentTotalAggregate":"0.462"},{"id":"3","date":"2016-01-31","exercise":"Growing Up Spiritually","type":"Review","source":"Kenneth E Hagin","score":"0","currentage":"13","aggregate":"0.000","tableName":"ayoadewusiscores","currentTotalAggregate":"0.462"},{"id":"4","date":"2016-02-07","exercise":"The Cost of a Crown","type":"Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"13","aggregate":"0.000","tableName":"ayoadewusiscores","currentTotalAggregate":"0.462"},{"id":"5","date":"2016-02-14","exercise":"The Love Walk","type":"Review","source":"Kenneth E Hagin","score":"16","currentage":"13","aggregate":"1.231","tableName":"ayoadewusiscores","currentTotalAggregate":"1.693"},{"id":"6","date":"2016-02-21","exercise":"Opted for Group Discussion","type":"Group Discussion","source":"Youths","score":"0","currentage":"13","aggregate":"0.000","tableName":"ayoadewusiscores","currentTotalAggregate":"1.693"},{"id":"7","date":"2016-03-13","exercise":"Repositioning for Exploits","type":"Review","source":"Bishop David Oyedepo","score":"0","currentage":"13","aggregate":"0.000","tableName":"ayoadewusiscores","currentTotalAggregate":"1.693"},{"id":"8","date":"2016-03-27","exercise":"1John 4:4","type":"Synonyms","source":"Lanre Ibironke","score":"31","currentage":"13","aggregate":"2.385","tableName":"ayoadewusiscores","currentTotalAggregate":"4.078"},{"id":"9","date":"2016-04-03","exercise":"Hand Sequence","type":"Focus Test","source":"Lanre Ibironke","score":"41","currentage":"13","aggregate":"3.154","tableName":"ayoadewusiscores","currentTotalAggregate":"7.232"},{"id":"10","date":"2016-04-10","exercise":"Yesterday, Today and Tomorrow","type":"Annotation and Silence Half Hour","source":"Lanre Ibironke","score":"52","currentage":"13","aggregate":"4.000","tableName":"ayoadewusiscores","currentTotalAggregate":"11.232"},{"id":"11","date":"2016-04-17","exercise":"Your Abilities","type":"Annotation & Hand Sequence","source":"Lanre Ibironke","score":"4","currentage":"13","aggregate":"0.308","tableName":"ayoadewusiscores","currentTotalAggregate":"11.54"},{"id":"12","date":"2016-04-27","exercise":"Maximizing Your Most Valuable Asset","type":"Home Work","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0.000","tableName":"ayoadewusiscores","currentTotalAggregate":"11.54"},{"id":"13","date":"2016-05-01","exercise":"Character Custodian of Destiny","type":"Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"13","aggregate":"0.000","tableName":"ayoadewusiscores","currentTotalAggregate":"11.54"},{"id":"14","date":"2016-05-08","exercise":"The Myth of Singleness","type":"Questions","source":"Dr Myles Munroe","score":"0","currentage":"13","aggregate":"0.000","tableName":"ayoadewusiscores","currentTotalAggregate":"11.54"},{"id":"15","date":"2016-05-15","exercise":"Being Still (Psalms 46vs10)","type":"Chicken on Egg Scenario","source":"Lanre Ibironke","score":"3","currentage":"13","aggregate":"0.231","tableName":"ayoadewusiscores","currentTotalAggregate":"11.771"},{"id":"16","date":"2016-05-22","exercise":"Selecting the Most Appropriate Word Replacement","type":"Quiz","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0.000","tableName":"ayoadewusiscores","currentTotalAggregate":"11.771"},{"id":"17","date":"2016-05-29","exercise":"Personalizing Scripture","type":"Theory Question","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0","tableName":"ayoadewusiscores","currentTotalAggregate":"11.771"},{"id":"19","date":"2016-06-05","exercise":"Inner Counsel","type":"Annotation","source":"Lanre Ibironke","score":"35","currentage":"13","aggregate":"2.692","tableName":"ayoadewusiscores","currentTotalAggregate":"14.463"},{"id":"20","date":"2016-06-12","exercise":"Bible Questions","type":"General Quiz","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0","tableName":"ayoadewusiscores","currentTotalAggregate":"14.463"},{"id":"21","date":"2016-06-19","exercise":"Marathon Question","type":"General Quiz 2","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0","tableName":"ayoadewusiscores","currentTotalAggregate":"14.463"},{"id":"22","date":"2016-06-26","exercise":"Uzziah''s Story","type":"Annotation","source":"Lanre Ibironke","score":"8","currentage":"13","aggregate":"0.615","tableName":"ayoadewusiscores","currentTotalAggregate":"15.078"},{"id":"23","date":"2016-07-03","exercise":"Multiple Choice","type":"General Quiz 3","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0","tableName":"ayoadewusiscores","currentTotalAggregate":"15.078"},{"id":"24","date":"2016-07-10","exercise":"4-Cards","type":"Bible Game","source":"Lanre Ibironke","score":"45","currentage":"14","aggregate":"3.214","tableName":"ayoadewusiscores","currentTotalAggregate":"18.292"},{"id":"25","date":"2016-07-24","exercise":"Memory Test","type":"Theory Questions","source":"Lanre Ibironke","score":"35","currentage":"14","aggregate":"2.5","tableName":"ayoadewusiscores","currentTotalAggregate":"20.792"},{"id":"26","date":"2016-07-31","exercise":"Scripture Expansion","type":"Presentation","source":"Lanre Ibironke","score":"15","currentage":"14","aggregate":"1.071","tableName":"ayoadewusiscores","currentTotalAggregate":"21.863"},{"id":"27","date":"2016-08-07","exercise":"Multiple Choice","type":"General Quiz 4","source":"Lanre Ibironke","score":"31","currentage":"14","aggregate":"2.214","tableName":"ayoadewusiscores","currentTotalAggregate":"24.077"},{"id":"28","date":"2016-08-14","exercise":"Tower of Hanoi & Marriage","type":"Puzzle  & Annotation","source":"Lanre Ibironke","score":"0","currentage":"14","aggregate":"0","tableName":"ayoadewusiscores","currentTotalAggregate":"24.077"},{"id":"29","date":"2016-08-21","exercise":"The Innovative Demands of Leadership","type":"Quiz 5","source":"Myles Munroe","score":"14","currentage":"14","aggregate":"1","tableName":"ayoadewusiscores","currentTotalAggregate":"25.077"},{"id":"30","date":"2016-08-28","exercise":"The Best Kept Secret","type":"Quiz 6 & Annotation","source":"Lanre Ibironke","score":"39","currentage":"14","aggregate":"2.786","tableName":"ayoadewusiscores","currentTotalAggregate":"27.863"},{"id":"31","date":"2016-09-04","exercise":"Divine Secrets","type":"Annotation","source":"Lanre Ibironke","score":"0","currentage":"14","aggregate":"0","tableName":"ayoadewusiscores","currentTotalAggregate":"27.863"},{"id":"32","date":"2016-09-11","exercise":"Repositioning for Exploits","type":"Online Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"14","aggregate":"0","tableName":"ayoadewusiscores","currentTotalAggregate":"27.863"}]', '');
INSERT INTO `profiles` VALUES(8, 'Michael', 'Alofe', '18', 'alofealofe@gmail.com', 'c8c254100e613b98e60b5bfc29b8929d70d6d8c4', '1035.645', '5th', '36', '242424', 'MA', 'Dcyphr4u', 'michaelalofescores', '[{"id":"1","date":"2016-01-03","exercise":"Eternal Life","type":"Review","source":"Andrew Wommack","score":"0","currentage":"17","aggregate":"0.000","tableName":"michaelalofescores","currentTotalAggregate":"0"},{"id":"2","date":"2016-01-10","exercise":"Close Encounter of the God Kind","type":"Review","source":"Jesse Duplantis","score":"3","currentage":"17","aggregate":"0.176","tableName":"michaelalofescores","currentTotalAggregate":"0.176"},{"id":"3","date":"2016-01-31","exercise":"Growing Up Spiritually","type":"Review","source":"Kenneth E Hagin","score":"0","currentage":"17","aggregate":"0.000","tableName":"michaelalofescores","currentTotalAggregate":"0.176"},{"id":"4","date":"2016-02-07","exercise":"The Cost of a Crown","type":"Quiz","source":"Bishop David Oyedepo","score":"27","currentage":"17","aggregate":"1.588","tableName":"michaelalofescores","currentTotalAggregate":"1.764"},{"id":"5","date":"2016-02-14","exercise":"The Love Walk","type":"Review","source":"Kenneth E Hagin","score":"0","currentage":"17","aggregate":"0.000","tableName":"michaelalofescores","currentTotalAggregate":"1.764"},{"id":"6","date":"2016-02-21","exercise":"Opted for Group Discussion","type":"Group Discussion","source":"Youths","score":"0","currentage":"17","aggregate":"0.000","tableName":"michaelalofescores","currentTotalAggregate":"1.764"},{"id":"7","date":"2016-03-13","exercise":"Repositioning for Exploits","type":"Review","source":"Bishop David Oyedepo","score":"0","currentage":"17","aggregate":"0.000","tableName":"michaelalofescores","currentTotalAggregate":"1.764"},{"id":"8","date":"2016-03-27","exercise":"1John 4:4","type":"Synonyms","source":"Lanre Ibironke","score":"30","currentage":"17","aggregate":"1.765","tableName":"michaelalofescores","currentTotalAggregate":"3.529"},{"id":"9","date":"2016-04-03","exercise":"Hand Sequence","type":"Focus Test","source":"Lanre Ibironke","score":"43","currentage":"17","aggregate":"2.529","tableName":"michaelalofescores","currentTotalAggregate":"6.058"},{"id":"10","date":"2016-04-10","exercise":"Yesterday, Today and Tomorrow","type":"Annotation and Silence Half Hour","source":"Lanre Ibironke","score":"43","currentage":"17","aggregate":"2.529","tableName":"michaelalofescores","currentTotalAggregate":"8.587"},{"id":"11","date":"2016-04-17","exercise":"Your Abilities","type":"Annotation and Hand Sequence","source":"Lanre Ibironke","score":"50","currentage":"17","aggregate":"2.941","tableName":"michaelalofescores","currentTotalAggregate":"11.528"},{"id":"12","date":"2016-04-24","exercise":"Maximizing Your Most Valuable Asset","type":"Home Work","source":"Lanre Ibironke","score":"0","currentage":"17","aggregate":"0.000","tableName":"michaelalofescores","currentTotalAggregate":"11.528"},{"id":"13","date":"2016-05-01","exercise":"Character Custodian of Destiny","type":"Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"17","aggregate":"0.000","tableName":"michaelalofescores","currentTotalAggregate":"11.528"},{"id":"14","date":"2016-05-08","exercise":"The Myth of Singleness","type":"Questions","source":"Dr Myles Munroe","score":"0","currentage":"17","aggregate":"0.000","tableName":"michaelalofescores","currentTotalAggregate":"11.528"},{"id":"15","date":"2016-05-15","exercise":"Being Still (Psalms 46vs10)","type":"Chicken on Egg Scenario","source":"Lanre Ibironke","score":"0","currentage":"17","aggregate":"0.000","tableName":"michaelalofescores","currentTotalAggregate":"11.528"},{"id":"16","date":"2016-05-22","exercise":"Selecting the Most Appropriate Word Replacement","type":"Quiz","source":"Lanre Ibironke","score":"50","currentage":"17","aggregate":"2.941","tableName":"michaelalofescores","currentTotalAggregate":"14.469"},{"id":"17","date":"2016-05-29","exercise":"Personalizing Scripture","type":"Theory Question","source":"Lanre Ibironke","score":"71","currentage":"17","aggregate":"4.176","tableName":"michaelalofescores","currentTotalAggregate":"18.645"},{"id":"18","date":"2016-06-05","exercise":"Inner Counsel","type":"Annotation","source":"Lanre Ibironke","score":"45","currentage":"17","aggregate":"2.647","tableName":"michaelalofescores","currentTotalAggregate":"21.292"},{"id":"19","date":"2016-06-12","exercise":"Bible Questions","type":"General Quiz","source":"Lanre Ibironke","score":"45","currentage":"17","aggregate":"2.647","tableName":"michaelalofescores","currentTotalAggregate":"23.939"},{"id":"20","date":"2016-06-19","exercise":"Marathon Question","type":"General Quiz 2","source":"Lanre Ibironke","score":"36","currentage":"17","aggregate":"2.118","tableName":"michaelalofescores","currentTotalAggregate":"26.057"},{"id":"21","date":"2016-06-26","exercise":"Uzziah''s Story","type":"Annotation","source":"Lanre Ibironke","score":"26","currentage":"17","aggregate":"1.529","tableName":"michaelalofescores","currentTotalAggregate":"27.586"},{"id":"22","date":"2016-07-03","exercise":"Multiple Choice","type":"General Quiz 3","source":"Lanre Ibironke","score":"60","currentage":"17","aggregate":"3.529","tableName":"michaelalofescores","currentTotalAggregate":"31.115"},{"id":"23","date":"2016-07-10","exercise":"4-Cards","type":"Bible Game","source":"Lanre Ibironke","score":"67","currentage":"17","aggregate":"3.941","tableName":"michaelalofescores","currentTotalAggregate":"35.056"},{"id":"24","date":"2016-07-24","exercise":"Memory Test","type":"Theory Questions","source":"Lanre Ibironke","score":"65","currentage":"17","aggregate":"3.824","tableName":"michaelalofescores","currentTotalAggregate":"38.88"},{"id":"25","date":"2016-07-31","exercise":"Scripture Expansion","type":"Presentation","source":"Lanre Ibironke","score":"35","currentage":"17","aggregate":"2.059","tableName":"michaelalofescores","currentTotalAggregate":"40.939"},{"id":"26","date":"2016-08-07","exercise":"Multiple Choice","type":"General Quiz 4","source":"Lanre Ibironke","score":"66","currentage":"17","aggregate":"3.882","tableName":"michaelalofescores","currentTotalAggregate":"44.821"},{"id":"27","date":"2016-08-14","exercise":"Tower of Hanoi & Marriage","type":"Puzzle  & Annotation","source":"Lanre Ibironke","score":"0","currentage":"17","aggregate":"0","tableName":"michaelalofescores","currentTotalAggregate":"44.821"},{"id":"28","date":"2016-08-21","exercise":"The Innovative Demands of Leadership","type":"Quiz 5","source":"Myles Munroe","score":"52","currentage":"17","aggregate":"3.059","tableName":"michaelalofescores","currentTotalAggregate":"47.88"},{"id":"29","date":"2016-08-28","exercise":"The Best Kept Secret","type":"Quiz 6 & Annotation","source":"Lanre Ibironke","score":"24","currentage":"17","aggregate":"1.412","tableName":"michaelalofescores","currentTotalAggregate":"49.292"},{"id":"30","date":"2016-09-04","exercise":"Divine Secrets","type":"Annotation","source":"Lanre Ibironke","score":"55","currentage":"17","aggregate":"3.235","tableName":"michaelalofescores","currentTotalAggregate":"52.527"},{"id":"31","date":"2016-09-11","exercise":"Repositioning for Exploits","type":"Online Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"17","aggregate":"0","tableName":"michaelalofescores","currentTotalAggregate":"52.527"}]', '{"cTab":"Message","wQAnswered":"0","wQGotten":"0","wQMissed":"0","mQAnswered":"25","mQGotten":"25","mQMissed":"0","sTyped":"0","sWordsTyped":"","sGotten":"0","sMissed":"0","tPoints":"125","eAForToday":"6.95","totalAggregate":"1035.645","email":"alofealofe@gmail.com","age":"18"}');
INSERT INTO `profiles` VALUES(9, 'Demilade', 'Oladipupo', '15', 'demmy.oladipupo01@gmail.com', '6419b672975226a3017fa423d9f14df000da159b', '632.097', '9th', '0', '010125', 'DO', 'R3436', 'demiladeoladipuposcores', '[{"id":"1","date":"2016-01-03","exercise":"Eternal Life","type":"Review","source":"Andrew Wommack","score":"0","currentage":"14","aggregate":"0.000","tableName":"demiladeoladipuposcores","currentTotalAggregate":"0"},{"id":"2","date":"2016-01-10","exercise":"Close Encounter of the God Kind","type":"Review","source":"Jesse Duplantis","score":"10","currentage":"14","aggregate":"0.714","tableName":"demiladeoladipuposcores","currentTotalAggregate":"0.714"},{"id":"3","date":"2016-01-31","exercise":"Growing Up Spiritually","type":"Review","source":"Kenneth E Hagin","score":"0","currentage":"14","aggregate":"0.000","tableName":"demiladeoladipuposcores","currentTotalAggregate":"0.714"},{"id":"4","date":"2016-02-07","exercise":"The Cost of a Crown","type":"Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"14","aggregate":"0.000","tableName":"demiladeoladipuposcores","currentTotalAggregate":"0.714"},{"id":"5","date":"2016-02-14","exercise":"The Love Walk","type":"Review","source":"Kenneth E Hagin","score":"0","currentage":"14","aggregate":"0.000","tableName":"demiladeoladipuposcores","currentTotalAggregate":"0.714"},{"id":"6","date":"2016-02-21","exercise":"Opted for Group Discussion","type":"Group Discussion","source":"Youths","score":"0","currentage":"14","aggregate":"0.000","tableName":"demiladeoladipuposcores","currentTotalAggregate":"0.714"},{"id":"7","date":"2016-03-13","exercise":"Repositioning for Exploits","type":"Review","source":"Bishop David Oyedepo","score":"17","currentage":"14","aggregate":"1.214","tableName":"demiladeoladipuposcores","currentTotalAggregate":"1.928"},{"id":"8","date":"2016-03-27","exercise":"1John 4:4","type":"Synonyms","source":"Lanre Ibironke","score":"0","currentage":"14","aggregate":"0.000","tableName":"demiladeoladipuposcores","currentTotalAggregate":"1.928"},{"id":"9","date":"2016-04-03","exercise":"Hand Sequence ","type":"Focus Test","source":"Lanre Ibironke","score":"0","currentage":"14","aggregate":"0.000","tableName":"demiladeoladipuposcores","currentTotalAggregate":"1.928"},{"id":"10","date":"2016-04-10","exercise":"Yesterday, Today and Tomorrow","type":"Annotation and Silence Half Hour","source":"Lanre Ibironke","score":"71","currentage":"14","aggregate":"5.071","tableName":"demiladeoladipuposcores","currentTotalAggregate":"6.999"},{"id":"11","date":"2016-04-17","exercise":"Your Abilities","type":"Annotation and Hand Sequence","source":"Lanre Ibironke","score":"60","currentage":"14","aggregate":"4.286","tableName":"demiladeoladipuposcores","currentTotalAggregate":"11.285"},{"id":"12","date":"2016-04-24","exercise":"Maximizing Your Most Valuable Asset","type":"Home Work","source":"Lanre Ibironke","score":"0","currentage":"14","aggregate":"0.000","tableName":"demiladeoladipuposcores","currentTotalAggregate":"11.285"},{"id":"13","date":"2016-05-01","exercise":"Character Custodian of Destiny","type":"Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"14","aggregate":"0.000","tableName":"demiladeoladipuposcores","currentTotalAggregate":"11.285"},{"id":"14","date":"2016-05-08","exercise":"The Myth of Singleness","type":"Question","source":"Dr Myles Munroe","score":"0","currentage":"14","aggregate":"0.000","tableName":"demiladeoladipuposcores","currentTotalAggregate":"11.285"},{"id":"15","date":"2016-05-15","exercise":"Being Still (Psalms 46vs10)","type":"Chicken on Egg Scenario","source":"Lanre Ibironke","score":"0","currentage":"14","aggregate":"0.000","tableName":"demiladeoladipuposcores","currentTotalAggregate":"11.285"},{"id":"16","date":"2016-05-22","exercise":"Selecting the Most Appropriate Word Replacement","type":"Quiz","source":"Lanre Ibironke","score":"0","currentage":"14","aggregate":"0.000","tableName":"demiladeoladipuposcores","currentTotalAggregate":"11.285"},{"id":"17","date":"2016-05-29","exercise":"Personalizing Scripture","type":"Theory Question","source":"Lanre Ibironke","score":"0","currentage":"14","aggregate":"0","tableName":"demiladeoladipuposcores","currentTotalAggregate":"11.285"},{"id":"18","date":"2016-06-05","exercise":"Inner Counsel","type":"Annotation","source":"Lanre Ibironke","score":"35","currentage":"14","aggregate":"2.5","tableName":"demiladeoladipuposcores","currentTotalAggregate":"13.785"},{"id":"19","date":"2016-06-12","exercise":"Bible Questions","type":"General Quiz","source":"Lanre ibironke","score":"51","currentage":"14","aggregate":"3.643","tableName":"demiladeoladipuposcores","currentTotalAggregate":"17.428"},{"id":"20","date":"2016-06-19","exercise":"Marathon Question","type":"Quiz 3","source":"Lanre Ibironke","score":"112","currentage":"14","aggregate":"8","tableName":"demiladeoladipuposcores","currentTotalAggregate":"25.428"},{"id":"21","date":"2016-06-26","exercise":"Uzziah''s Story","type":"Annotation","source":"Lanre Ibironke","score":"10","currentage":"15","aggregate":"0.667","tableName":"demiladeoladipuposcores","currentTotalAggregate":"26.095"},{"id":"22","date":"2016-07-03","exercise":"Multiple Choice","type":"General Quiz 3","source":"Lanre Ibironke","score":"0","currentage":"15","aggregate":"0","tableName":"demiladeoladipuposcores","currentTotalAggregate":"26.095"},{"id":"23","date":"2016-07-10","exercise":"4-Cards","type":"Bible Game","source":"Lanre Ibironke","score":"0","currentage":"15","aggregate":"0","tableName":"demiladeoladipuposcores","currentTotalAggregate":"26.095"},{"id":"24","date":"2016-07-24","exercise":"Memory Test","type":"Theory Questions","source":"Lanre Ibironke","score":"0","currentage":"15","aggregate":"0","tableName":"demiladeoladipuposcores","currentTotalAggregate":"26.095"},{"id":"25","date":"2016-07-31","exercise":"Scripture Expansion","type":"Presentation","source":"Lanre Ibironke","score":"0","currentage":"15","aggregate":"0","tableName":"demiladeoladipuposcores","currentTotalAggregate":"26.095"},{"id":"26","date":"2016-08-07","exercise":"Multiple Choice","type":"General Quiz 4","source":"Lanre Ibironke","score":"0","currentage":"15","aggregate":"0","tableName":"demiladeoladipuposcores","currentTotalAggregate":"26.095"},{"id":"27","date":"2016-08-14","exercise":"Tower of Hanoi & Marriage","type":"Puzzle  & Annotation","source":"Lanre Ibironke","score":"80","currentage":"15","aggregate":"5.333","tableName":"demiladeoladipuposcores","currentTotalAggregate":"31.428"},{"id":"28","date":"2016-08-21","exercise":"The Innovative Demands of Leadership","type":"Quiz 5","source":"Myles Munroe","score":"54","currentage":"15","aggregate":"3.6","tableName":"demiladeoladipuposcores","currentTotalAggregate":"35.028"},{"id":"29","date":"2016-08-28","exercise":"The Best Kept Secret","type":"Quiz 6 & Annotation","source":"Lanre Ibironke","score":"70","currentage":"15","aggregate":"4.667","tableName":"demiladeoladipuposcores","currentTotalAggregate":"39.695"},{"id":"30","date":"2016-09-04","exercise":"Divine Secrets","type":"Annotation","source":"Lanre Ibironke","score":"68","currentage":"15","aggregate":"4.533","tableName":"demiladeoladipuposcores","currentTotalAggregate":"44.228"},{"id":"31","date":"2016-09-11","exercise":"Repositioning for Exploits","type":"Online Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"15","aggregate":"0","tableName":"demiladeoladipuposcores","currentTotalAggregate":"44.228"}]', '{"cTab":"Message","wQAnswered":"15","wQGotten":"15","wQMissed":"0","mQAnswered":"57","mQGotten":"53","mQMissed":"4","sTyped":"20","sWordsTyped":"Proverbs 7:20-He has taken a bag of money with him and will not come home at the day appointed [at the full moon].","sGotten":"18","sMissed":"2","tPoints":"436","eAForToday":"29.04","totalAggregate":"632.097","email":"demmy.oladipupo01@gmail.com","age":"15"}');
INSERT INTO `profiles` VALUES(10, 'Funto', 'Adeniyi', '14', 'funtoadeniyi2016@yahoo.com', 'd85930a2b3bfa82b5c2d3c7b3023e54e33605f2e', '484.844', '10th', '0', 'CC1E68', 'FA', 'ladybug003', 'funtoadeniyiscores', '[{"id":"1","date":"2016-01-03","exercise":"Eternal Life","type":"Review","source":"Andrew Wommack","score":"0","currentage":"12","aggregate":"0.000","tableName":"funtoadeniyiscores","currentTotalAggregate":"0"},{"id":"2","date":"2016-01-10","exercise":"Close Encounter of the God Kind","type":"Review","source":"Jesse Duplantis","score":"0","currentage":"12","aggregate":"0.000","tableName":"funtoadeniyiscores","currentTotalAggregate":"0"},{"id":"3","date":"2016-01-31","exercise":"Growing Up Spiritually","type":"Review","source":"Kenneth E Hagin","score":"2","currentage":"12","aggregate":"0.167","tableName":"funtoadeniyiscores","currentTotalAggregate":"0.167"},{"id":"4","date":"2016-02-07","exercise":"The Cost of a Crown","type":"Quiz","source":"Bishop David Oyedepo","score":"20","currentage":"12","aggregate":"1.667","tableName":"funtoadeniyiscores","currentTotalAggregate":"1.834"},{"id":"5","date":"2016-02-14","exercise":"The Love Walk","type":"Review","source":"Kenneth E Hagin","score":"7","currentage":"12","aggregate":"0.583","tableName":"funtoadeniyiscores","currentTotalAggregate":"2.417"},{"id":"6","date":"2016-02-21","exercise":"Opted for Group Discussion","type":"Group Discussion","source":"Youths","score":"0","currentage":"12","aggregate":"0.000","tableName":"funtoadeniyiscores","currentTotalAggregate":"2.417"},{"id":"7","date":"2016-03-13","exercise":"Repositioning for Exploits","type":"Review","source":"Bishop David Oyedepo","score":"0","currentage":"12","aggregate":"0.000","tableName":"funtoadeniyiscores","currentTotalAggregate":"2.417"},{"id":"8","date":"2016-03-27","exercise":"1John 4:4","type":"Synonyms","source":"Lanre Ibironke","score":"25","currentage":"12","aggregate":"2.083","tableName":"funtoadeniyiscores","currentTotalAggregate":"4.5"},{"id":"9","date":"2016-04-03","exercise":"Hand Sequence","type":"Focus Test","source":"Lanre Ibironke","score":"48","currentage":"12","aggregate":"4.000","tableName":"funtoadeniyiscores","currentTotalAggregate":"8.5"},{"id":"10","date":"2016-04-10","exercise":"Yesterday, Today and Tomorrow","type":"Annotation and Silence Half Hour","source":"Lanre Ibironke","score":"0","currentage":"12","aggregate":"0.000","tableName":"funtoadeniyiscores","currentTotalAggregate":"8.5"},{"id":"11","date":"2016-04-17","exercise":"Your Abilities","type":"Annotation and Hand Sequence","source":"Lanre Ibironke","score":"17","currentage":"12","aggregate":"1.417","tableName":"funtoadeniyiscores","currentTotalAggregate":"9.917"},{"id":"12","date":"2016-04-24","exercise":"Maximizing Your Most Valuable Asset","type":"Home Work","source":"Lanre Ibironke","score":"0","currentage":"12","aggregate":"0.000","tableName":"funtoadeniyiscores","currentTotalAggregate":"9.917"},{"id":"13","date":"2016-05-01","exercise":"Character Custodian of Destiny","type":"Quiz","source":"Bishop David Oyedepo","score":"12","currentage":"12","aggregate":"1.000","tableName":"funtoadeniyiscores","currentTotalAggregate":"10.917"},{"id":"14","date":"2016-05-08","exercise":"The Myth of Singleness","type":"Questions","source":"Dr Myles Munroe","score":"12","currentage":"12","aggregate":"1.000","tableName":"funtoadeniyiscores","currentTotalAggregate":"11.917"},{"id":"15","date":"2016-05-15","exercise":"Being Still (Psalms 46vs10)","type":"Chicken on Egg Scenario","source":"Lanre Ibironke","score":"7","currentage":"13","aggregate":"0.538","tableName":"funtoadeniyiscores","currentTotalAggregate":"12.455"},{"id":"16","date":"2016-05-22","exercise":"Selecting the Most Appropriate Word Replacement","type":"Quiz","source":"Lanre Ibironke","score":"35","currentage":"13","aggregate":"2.692","tableName":"funtoadeniyiscores","currentTotalAggregate":"15.147"},{"id":"17","date":"2016-05-29","exercise":"Personalizing Scripture","type":"Theory Question","source":"Lanre Ibironke","score":"5","currentage":"13","aggregate":"0.385","tableName":"funtoadeniyiscores","currentTotalAggregate":"15.532"},{"id":"18","date":"2016-06-05","exercise":"Inner Counsel","type":"Annotation","source":"Lanre Ibironke","score":"20","currentage":"13","aggregate":"1.538","tableName":"funtoadeniyiscores","currentTotalAggregate":"17.07"},{"id":"19","date":"2016-06-12","exercise":"Bible Questions","type":"General Quiz","source":"Lanre Ibironke","score":"39","currentage":"13","aggregate":"3","tableName":"funtoadeniyiscores","currentTotalAggregate":"20.07"},{"id":"20","date":"2016-06-19","exercise":"Marathon Question","type":"General Quiz 2","source":"Lanre Ibironke","score":"42","currentage":"13","aggregate":"3.231","tableName":"funtoadeniyiscores","currentTotalAggregate":"23.301"},{"id":"21","date":"2016-06-26","exercise":"Uzziah''s Story","type":"Annotation","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0","tableName":"funtoadeniyiscores","currentTotalAggregate":"23.301"},{"id":"22","date":"2016-07-03","exercise":"Multiple Choice","type":"General Quiz 3","source":"Lanre Ibironke","score":"31","currentage":"13","aggregate":"2.385","tableName":"funtoadeniyiscores","currentTotalAggregate":"25.686"},{"id":"23","date":"2016-07-10","exercise":"4-Cards","type":"Bible Game","source":"Lanre Ibironke","score":"23","currentage":"13","aggregate":"1.769","tableName":"funtoadeniyiscores","currentTotalAggregate":"27.455"},{"id":"24","date":"2016-07-24","exercise":"Memory Test","type":"Theory Questions","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0","tableName":"funtoadeniyiscores","currentTotalAggregate":"27.455"},{"id":"25","date":"2016-07-31","exercise":"Scripture Expansion","type":"Presentation","source":"Lanre Ibironke","score":"35","currentage":"13","aggregate":"2.692","tableName":"funtoadeniyiscores","currentTotalAggregate":"30.147"},{"id":"26","date":"2016-08-07","exercise":"Multiple Choice","type":"General Quiz 4","source":"Lanre Ibironke","score":"47","currentage":"13","aggregate":"3.615","tableName":"funtoadeniyiscores","currentTotalAggregate":"33.762"},{"id":"27","date":"2016-08-14","exercise":"Tower of Hanoi & Marriage","type":"Puzzle  & Annotation","source":"Lanre Ibironke","score":"34","currentage":"13","aggregate":"2.615","tableName":"funtoadeniyiscores","currentTotalAggregate":"36.377"},{"id":"28","date":"2016-08-21","exercise":"The Innovative Demands of Leadership","type":"Quiz 5","source":"Myles Munroe","score":"0","currentage":"13","aggregate":"0","tableName":"funtoadeniyiscores","currentTotalAggregate":"36.377"},{"id":"29","date":"2016-08-28","exercise":"The Best Kept Secret","type":"Quiz 6 & Annotation","source":"Lanre Ibironke","score":"47","currentage":"13","aggregate":"3.615","tableName":"funtoadeniyiscores","currentTotalAggregate":"39.992"},{"id":"30","date":"2016-09-04","exercise":"Divine Secrets","type":"Annotation","source":"Lanre Ibironke","score":"59","currentage":"13","aggregate":"4.538","tableName":"funtoadeniyiscores","currentTotalAggregate":"44.53"},{"id":"31","date":"2016-09-11","exercise":"Repositioning for Exploits","type":"Online Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"13","aggregate":"0","tableName":"funtoadeniyiscores","currentTotalAggregate":"39.992"}]', '');
INSERT INTO `profiles` VALUES(11, 'Esther', 'Shonde', '15', 'esthershonde@gmail.com', '3f909d3d73f921605090add7f56ce1670995a7d4', '467.652', '12th', '0', '080B46', 'ES', '591738', 'esthershondescores', '[{"id":"1","date":"2016-01-03","exercise":"Eternal Life","type":"Review","source":"Andrew Wommack","score":"0","currentage":"14","aggregate":"0.000","tableName":"esthershondescores","currentTotalAggregate":"0"},{"id":"2","date":"2016-01-10","exercise":"Close Encounter of the God Kind","type":"Review","source":"Jesse Duplantis","score":"0","currentage":"14","aggregate":"0.000","tableName":"esthershondescores","currentTotalAggregate":"0"},{"id":"3","date":"2016-01-31","exercise":"Growing Up Spiritually","type":"Review","source":"Kenneth E Hagin","score":"0","currentage":"14","aggregate":"0.000","tableName":"esthershondescores","currentTotalAggregate":"0"},{"id":"4","date":"2016-02-07","exercise":"The Cost of a Crown","type":"Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"14","aggregate":"0.000","tableName":"esthershondescores","currentTotalAggregate":"0"},{"id":"5","date":"2016-02-14","exercise":"The Love Walk","type":"Review","source":"Kenneth E Hagin","score":"0","currentage":"14","aggregate":"0.000","tableName":"esthershondescores","currentTotalAggregate":"0"},{"id":"6","date":"2016-02-21","exercise":"Opted for Group Discussion","type":"Group Discussion","source":"Youths","score":"0","currentage":"14","aggregate":"0.000","tableName":"esthershondescores","currentTotalAggregate":"0"},{"id":"7","date":"2016-03-13","exercise":"Repositioning for Exploits","type":"Review","source":"Bishop David Oyedepo","score":"0","currentage":"14","aggregate":"0.000","tableName":"esthershondescores","currentTotalAggregate":"0"},{"id":"8","date":"2016-03-27","exercise":"1John 4:4","type":"Synonyms","source":"Lanre Ibironke","score":"22","currentage":"14","aggregate":"1.571","tableName":"esthershondescores","currentTotalAggregate":"1.571"},{"id":"9","date":"2016-04-03","exercise":"Hand Sequence","type":"Focus Test","source":"Lanre Ibironke","score":"0","currentage":"14","aggregate":"0.000","tableName":"esthershondescores","currentTotalAggregate":"1.571"},{"id":"10","date":"2016-04-10","exercise":"Yesterday, Today and Tomorrow","type":"Annotation and Silence Half Hour","source":"Lanre Ibironke","score":"49","currentage":"14","aggregate":"3.500","tableName":"esthershondescores","currentTotalAggregate":"5.071"},{"id":"11","date":"2016-04-17","exercise":"Your Abilities","type":"Annotation and Hand Sequence","source":"Lanre Ibironke","score":"0","currentage":"14","aggregate":"0.000","tableName":"esthershondescores","currentTotalAggregate":"5.071"},{"id":"12","date":"2016-04-24","exercise":"Maximizing Your Most Valuable Asset","type":"Home Work","source":"Lanre Ibironke","score":"0","currentage":"14","aggregate":"0.000","tableName":"esthershondescores","currentTotalAggregate":"5.071"},{"id":"13","date":"2016-05-01","exercise":"Character Custodian of Destiny","type":"Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"14","aggregate":"0.000","tableName":"esthershondescores","currentTotalAggregate":"5.071"},{"id":"14","date":"2016-05-08","exercise":"The Myth of Singleness","type":"Questions","source":"Dr Myles Munroe","score":"20","currentage":"14","aggregate":"1.429","tableName":"esthershondescores","currentTotalAggregate":"6.5"},{"id":"15","date":"2016-05-15","exercise":"Being Still (Psalms 46vs10)","type":"Chicken on Egg Scenario","source":"Lanre Ibironke","score":"7","currentage":"14","aggregate":"0.5","tableName":"esthershondescores","currentTotalAggregate":"7"},{"id":"16","date":"2016-05-22","exercise":"Selecting the Most Appropriate Word Replacement","type":"Quiz","source":"Lanre Ibironke","score":"30","currentage":"14","aggregate":"2.143","tableName":"esthershondescores","currentTotalAggregate":"9.143"},{"id":"17","date":"2016-05-29","exercise":"Personalizing Scripture","type":"Theory Question","source":"Lanre Ibironke","score":"10","currentage":"14","aggregate":"0.714","tableName":"esthershondescores","currentTotalAggregate":"9.857"},{"id":"19","date":"2016-06-05","exercise":"Inner Counsel","type":"Annotation","source":"Lanre Ibironke","score":"0","currentage":"14","aggregate":"0","tableName":"esthershondescores","currentTotalAggregate":"9.857"},{"id":"20","date":"2016-06-12","exercise":"Bible Questions","type":"General Quiz","source":"Lanre Ibironke","score":"0","currentage":"15","aggregate":"0","tableName":"esthershondescores","currentTotalAggregate":"9.857"},{"id":"21","date":"2016-06-19","exercise":"Marathon Question","type":"General Quiz 2","source":"Lanre Ibironke","score":"0","currentage":"15","aggregate":"0","tableName":"esthershondescores","currentTotalAggregate":"9.857"},{"id":"22","date":"2016-06-26","exercise":"Uzziah''s Story","type":"Annotation","source":"Lanre Ibironke","score":"14","currentage":"15","aggregate":"0.933","tableName":"esthershondescores","currentTotalAggregate":"10.79"},{"id":"23","date":"2016-07-03","exercise":"Multiple Choice","type":"General Quiz 3","source":"Lanre Ibironke","score":"0","currentage":"15","aggregate":"0","tableName":"esthershondescores","currentTotalAggregate":"10.79"},{"id":"24","date":"2016-07-10","exercise":"4-Cards","type":"Bible Game","source":"Lanre Ibironke","score":"21","currentage":"15","aggregate":"1.4","tableName":"esthershondescores","currentTotalAggregate":"12.19"},{"id":"25","date":"2016-07-24","exercise":"Memory Test","type":"Theory Questions","source":"Lanre Ibironke","score":"0","currentage":"15","aggregate":"0","tableName":"esthershondescores","currentTotalAggregate":"12.19"},{"id":"26","date":"2016-07-31","exercise":"Scripture Expansion","type":"Presentation","source":"Lanre Ibironke","score":"45","currentage":"15","aggregate":"3","tableName":"esthershondescores","currentTotalAggregate":"15.19"},{"id":"27","date":"2016-08-07","exercise":"Multiple Choice","type":"General Quiz 4","source":"Lanre Ibironke","score":"62","currentage":"15","aggregate":"4.133","tableName":"esthershondescores","currentTotalAggregate":"19.323"},{"id":"28","date":"2016-08-14","exercise":"Tower of Hanoi & Marriage","type":"Puzzle  & Annotation","source":"Lanre Ibironke","score":"0","currentage":"15","aggregate":"0","tableName":"esthershondescores","currentTotalAggregate":"19.323"},{"id":"29","date":"2016-08-21","exercise":"The Innovative Demands of Leadership","type":"Quiz 5","source":"Myles Munroe","score":"29","currentage":"15","aggregate":"1.933","tableName":"esthershondescores","currentTotalAggregate":"21.256"},{"id":"30","date":"2016-08-28","exercise":"The Best Kept Secret","type":"Quiz 6 & Annotation","source":"Lanre Ibironke","score":"27","currentage":"15","aggregate":"1.8","tableName":"esthershondescores","currentTotalAggregate":"23.056"},{"id":"31","date":"2016-09-04","exercise":"Divine Secrets","type":"Annotation","source":"Lanre Ibironke","score":"40","currentage":"15","aggregate":"2.667","tableName":"esthershondescores","currentTotalAggregate":"25.723"},{"id":"32","date":"2016-09-11","exercise":"Repositioning for Exploits","type":"Online Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"15","aggregate":"0","tableName":"esthershondescores","currentTotalAggregate":"25.723"}]', '');
INSERT INTO `profiles` VALUES(12, 'Elizabeth', 'Shonde', '12', 'elizabethshonde@gmail.com', 'ffccf3a8126cce6efd829913babf3ff9a2cc8d7f', '403.875', '14th', '0', 'A60048', 'ES', 'Presel', 'elizabethshondescores', '[{"id":"1","date":"2016-01-03","exercise":"Eternal Life","type":"Review","source":"Andrew Wommack","score":"0","currentage":"10","aggregate":"0.000","tableName":"elizabethshondescores","currentTotalAggregate":"0"},{"id":"2","date":"2016-01-10","exercise":"Close Encounter of the God Kind","type":"Review","source":"Jesse Duplantis","score":"0","currentage":"10","aggregate":"0.000","tableName":"elizabethshondescores","currentTotalAggregate":"0"},{"id":"3","date":"2016-01-31","exercise":"Growing Up Spiritually","type":"Review","source":"Kenneth E Hagin","score":"0","currentage":"10","aggregate":"0.000","tableName":"elizabethshondescores","currentTotalAggregate":"0"},{"id":"4","date":"2016-02-07","exercise":"The Cost of a Crown","type":"Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"10","aggregate":"0.000","tableName":"elizabethshondescores","currentTotalAggregate":"0"},{"id":"5","date":"2016-02-14","exercise":"The Love Walk","type":"Review","source":"Kenneth E Hagin","score":"0","currentage":"10","aggregate":"0.000","tableName":"elizabethshondescores","currentTotalAggregate":"0"},{"id":"6","date":"2016-02-21","exercise":"Opted for Group Discussion","type":"Group Discussion","source":"Youth","score":"0","currentage":"10","aggregate":"0.000","tableName":"elizabethshondescores","currentTotalAggregate":"0"},{"id":"7","date":"2016-03-13","exercise":"Repositioning for Exploits","type":"Review","source":"Bishop David Oyedepo","score":"0","currentage":"11","aggregate":"0.000","tableName":"elizabethshondescores","currentTotalAggregate":"0"},{"id":"8","date":"2016-03-27","exercise":"1John 4:4","type":"Synonyms","source":"Lanre Ibironke","score":"19","currentage":"11","aggregate":"1.727","tableName":"elizabethshondescores","currentTotalAggregate":"1.727"},{"id":"9","date":"2016-04-03","exercise":"Hand Sequence","type":"Focus Test","source":"Lanre Ibironke","score":"0","currentage":"11","aggregate":"0.000","tableName":"elizabethshondescores","currentTotalAggregate":"1.727"},{"id":"10","date":"2016-04-10","exercise":"Yesterday, Today and Tomorrow","type":"Annotation and Silence Half Hour","source":"Lanre Ibironke","score":"35","currentage":"11","aggregate":"3.182","tableName":"elizabethshondescores","currentTotalAggregate":"4.909"},{"id":"11","date":"2016-04-17","exercise":"Your Abilities","type":"Annotation and Hand Sequence","source":"Lanre Ibironke","score":"0","currentage":"11","aggregate":"0.000","tableName":"elizabethshondescores","currentTotalAggregate":"4.909"},{"id":"12","date":"2016-04-24","exercise":"Maximizing Your Most Valuable Asset","type":"Home Work","source":"Lanre Ibironke","score":"0","currentage":"11","aggregate":"0.000","tableName":"elizabethshondescores","currentTotalAggregate":"4.909"},{"id":"13","date":"2016-05-01","exercise":"Character Custodian of Destiny","type":"Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"11","aggregate":"0.000","tableName":"elizabethshondescores","currentTotalAggregate":"4.909"},{"id":"14","date":"2016-05-08","exercise":"The Myth of Singleness","type":"Questions","source":"Dr Myles Munroe","score":"17","currentage":"11","aggregate":"1.545","tableName":"elizabethshondescores","currentTotalAggregate":"6.454"},{"id":"15","date":"2016-05-15","exercise":"Being Still (Psalms 46vs10)","type":"Chicken on Egg Scenario","source":"Lanre Ibironke","score":"7","currentage":"11","aggregate":"0.636","tableName":"elizabethshondescores","currentTotalAggregate":"7.09"},{"id":"16","date":"2016-05-22","exercise":"Selecting the Most Appropriate Word Replacement","type":"Quiz","source":"Lanre Ibironke","score":"50","currentage":"11","aggregate":"4.545","tableName":"elizabethshondescores","currentTotalAggregate":"11.635"},{"id":"17","date":"2016-05-29","exercise":"Personalizing Scripture","type":"Theory Question","source":"Lanre Ibironke","score":"4","currentage":"11","aggregate":"0.364","tableName":"elizabethshondescores","currentTotalAggregate":"11.999"},{"id":"18","date":"2016-06-05","exercise":"Inner Counsel","type":"Annotation","source":"Lanre Ibironke","score":"0","currentage":"11","aggregate":"0","tableName":"elizabethshondescores","currentTotalAggregate":"11.999"},{"id":"19","date":"2016-06-12","exercise":"Bible Questions","type":"General Quiz","source":"Lanre Ibironke","score":"0","currentage":"11","aggregate":"0","tableName":"elizabethshondescores","currentTotalAggregate":"11.999"},{"id":"20","date":"2016-06-19","exercise":"Marathon Question","type":"General Quiz 2","source":"Lanre Ibironke","score":"0","currentage":"11","aggregate":"0","tableName":"elizabethshondescores","currentTotalAggregate":"11.999"},{"id":"21","date":"2016-06-26","exercise":"Uzziah''s Story","type":"Annotation","source":"Lanre Ibironke","score":"12","currentage":"11","aggregate":"1.091","tableName":"elizabethshondescores","currentTotalAggregate":"13.09"},{"id":"22","date":"2016-07-03","exercise":"Multiple Choice","type":"General Quiz 3","source":"Lanre Ibironke","score":"0","currentage":"11","aggregate":"0","tableName":"elizabethshondescores","currentTotalAggregate":"13.09"},{"id":"23","date":"2016-07-10","exercise":"4-Cards","type":"Bible Game","source":"Lanre Ibironke","score":"20","currentage":"11","aggregate":"1.818","tableName":"elizabethshondescores","currentTotalAggregate":"14.908"},{"id":"24","date":"2016-07-24","exercise":"Memory Test","type":"Theory Questions","source":"Lanre Ibironke","score":"0","currentage":"11","aggregate":"0","tableName":"elizabethshondescores","currentTotalAggregate":"14.908"},{"id":"25","date":"2016-07-31","exercise":"Scripture Expansion","type":"Presentation","source":"Lanre Ibironke","score":"25","currentage":"11","aggregate":"2.273","tableName":"elizabethshondescores","currentTotalAggregate":"17.181"},{"id":"26","date":"2016-08-07","exercise":"Multiple Choice","type":"General Quiz 4","source":"Lanre Ibironke","score":"48","currentage":"11","aggregate":"4.364","tableName":"elizabethshondescores","currentTotalAggregate":"21.545"},{"id":"27","date":"2016-08-14","exercise":"Tower of Hanoi & Marriage","type":"Puzzle  & Annotation","source":"Lanre Ibironke","score":"0","currentage":"11","aggregate":"0","tableName":"elizabethshondescores","currentTotalAggregate":"21.545"},{"id":"28","date":"2016-08-21","exercise":"The Innovative Demands of Leadership","type":"Quiz 5","source":"Myles Munroe","score":"22","currentage":"11","aggregate":"2","tableName":"elizabethshondescores","currentTotalAggregate":"23.545"},{"id":"29","date":"2016-08-28","exercise":"The Best Kept Secret","type":"Quiz 6 & Annotation","source":"Lanre Ibironke","score":"12","currentage":"11","aggregate":"1.091","tableName":"elizabethshondescores","currentTotalAggregate":"24.636"},{"id":"30","date":"2016-09-04","exercise":"Divine Secrets","type":"Annotation","source":"Lanre Ibironke","score":"32","currentage":"11","aggregate":"2.909","tableName":"elizabethshondescores","currentTotalAggregate":"27.544999999999998"},{"id":"31","date":"2016-09-11","exercise":"Repositioning for Exploits","type":"Online Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"11","aggregate":"0","tableName":"elizabethshondescores","currentTotalAggregate":"27.545"}]', '');
INSERT INTO `profiles` VALUES(13, 'Oyin', 'Alofe', '12', 'oyinalofe@gmail.com', '217ec76423ce9bfc37dbb5b392985f5c18c4f018', '1165.196', '3rd', '47', '3B0A4F', 'OA', 'Xx_panda_xX', 'oyinalofescores', '[{"id":"1","date":"2016-01-03","exercise":"Eternal Life","type":"Review","source":"Andrew Wommack","score":"0","currentage":"10","aggregate":"0.000","tableName":"oyinalofescores","currentTotalAggregate":"0"},{"id":"2","date":"2016-01-10","exercise":"Close Encounter of the God Kind","type":"Review","source":"Jesse Duplantis","score":"0","currentage":"10","aggregate":"0.000","tableName":"oyinalofescores","currentTotalAggregate":"0"},{"id":"3","date":"2016-01-31","exercise":"Growing Up Spiritually","type":"Review","source":"Kenneth E Hagin","score":"0","currentage":"11","aggregate":"0.000","tableName":"oyinalofescores","currentTotalAggregate":"0"},{"id":"4","date":"2016-02-07","exercise":"The Cost of a Crown","type":"Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"11","aggregate":"0.000","tableName":"oyinalofescores","currentTotalAggregate":"0"},{"id":"5","date":"2016-02-14","exercise":"The Love Walk","type":"Review","source":"Kenneth E Hagin","score":"0","currentage":"11","aggregate":"0.000","tableName":"oyinalofescores","currentTotalAggregate":"0"},{"id":"6","date":"2016-02-21","exercise":"Opted for Group Discussion","type":"Group Discussion","source":"Youth","score":"0","currentage":"11","aggregate":"0.000","tableName":"oyinalofescores","currentTotalAggregate":"0"},{"id":"7","date":"2016-03-13","exercise":"Repositioning for Exploits","type":"Review","source":"Bishop David Oyedepo","score":"0","currentage":"11","aggregate":"0.000","tableName":"oyinalofescores","currentTotalAggregate":"0"},{"id":"8","date":"2016-03-27","exercise":"1John 4:4","type":"Synonyms","source":"Lanre Ibironke","score":"0","currentage":"11","aggregate":"0.000","tableName":"oyinalofescores","currentTotalAggregate":"0"},{"id":"9","date":"2016-04-03","exercise":"Hand Sequence","type":"Focus Test","source":"Lanre Ibironke","score":"18","currentage":"11","aggregate":"1.636","tableName":"oyinalofescores","currentTotalAggregate":"1.636"},{"id":"10","date":"2016-04-10","exercise":"Yesterday, Today and Tomorrow","type":"Annotation and Silence Half Hour","source":"Lanre Ibironke","score":"32","currentage":"11","aggregate":"2.909","tableName":"oyinalofescores","currentTotalAggregate":"4.545"},{"id":"11","date":"2016-04-17","exercise":"Your Abilities","type":"Annotation and Hand Sequence","source":"Lanre Ibironke","score":"2","currentage":"11","aggregate":"0.182","tableName":"oyinalofescores","currentTotalAggregate":"4.727"},{"id":"12","date":"2016-04-24","exercise":"Maximizing Your Most Valuable Asset","type":"Home Work","source":"Lanre Ibironke","score":"0","currentage":"11","aggregate":"0.000","tableName":"oyinalofescores","currentTotalAggregate":"4.727"},{"id":"13","date":"2016-05-01","exercise":"Character Custodian of Destiny","type":"Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"11","aggregate":"0.000","tableName":"oyinalofescores","currentTotalAggregate":"4.727"},{"id":"15","date":"2016-05-08","exercise":"The Myth of Singleness","type":"Questions","source":"Dr Myles Munroe","score":"0","currentage":"11","aggregate":"0.000","tableName":"oyinalofescores","currentTotalAggregate":"4.727"},{"id":"16","date":"2016-05-15","exercise":"Being Still (Psalms 46vs10)","type":"Chicken on Egg Scenario","source":"Lanre Ibironke","score":"0","currentage":"11","aggregate":"0.000","tableName":"oyinalofescores","currentTotalAggregate":"4.727"},{"id":"17","date":"2016-05-22","exercise":"Selecting the Most Appropriate Word Replacement","type":"Quiz","source":"Lanre Ibironke","score":"30","currentage":"11","aggregate":"2.727","tableName":"oyinalofescores","currentTotalAggregate":"7.454"},{"id":"18","date":"2016-05-29","exercise":"Personalizing Scripture","type":"Theory Question","source":"Lanre Ibironke","score":"41","currentage":"11","aggregate":"3.727","tableName":"oyinalofescores","currentTotalAggregate":"11.181"},{"id":"19","date":"2016-06-05","exercise":"Inner Counsel","type":"Annotation","source":"Lanre Ibironke","score":"30","currentage":"11","aggregate":"2.727","tableName":"oyinalofescores","currentTotalAggregate":"13.908"},{"id":"20","date":"2016-06-12","exercise":"Bible Questions","type":"General Quiz","source":"Lanre Ibironke","score":"33","currentage":"11","aggregate":"3","tableName":"oyinalofescores","currentTotalAggregate":"16.908"},{"id":"21","date":"2016-06-19","exercise":"Marathon Question","type":"General Quiz 2","source":"Lanre Ibironke","score":"42","currentage":"11","aggregate":"3.818","tableName":"oyinalofescores","currentTotalAggregate":"20.726"},{"id":"22","date":"2016-06-26","exercise":"Uzziah''s Story","type":"Annotation","source":"Lanre Ibironke","score":"33","currentage":"11","aggregate":"3","tableName":"oyinalofescores","currentTotalAggregate":"23.726"},{"id":"23","date":"2016-07-03","exercise":"Multiple Choice","type":"General Quiz 3","source":"Lanre Ibironke","score":"0","currentage":"11","aggregate":"0","tableName":"oyinalofescores","currentTotalAggregate":"23.726"},{"id":"24","date":"2016-07-10","exercise":"4-Cards","type":"Bible Game","source":"Lanre Ibironke","score":"0","currentage":"11","aggregate":"0","tableName":"oyinalofescores","currentTotalAggregate":"23.726"},{"id":"25","date":"2016-07-24","exercise":"Memory Test","type":"Theory Questions","source":"Lanre Ibironke","score":"27","currentage":"11","aggregate":"2.455","tableName":"oyinalofescores","currentTotalAggregate":"26.181"},{"id":"26","date":"2016-07-31","exercise":"Scripture Expansion","type":"Presentation","source":"Lanre Ibironke","score":"17","currentage":"11","aggregate":"1.545","tableName":"oyinalofescores","currentTotalAggregate":"27.726"},{"id":"27","date":"2016-08-07","exercise":"Multiple Choice","type":"General Quiz 4","source":"Lanre Ibironke","score":"57","currentage":"11","aggregate":"5.182","tableName":"oyinalofescores","currentTotalAggregate":"32.908"},{"id":"28","date":"2016-08-14","exercise":"Tower of Hanoi & Marriage","type":"Puzzle  & Annotation","source":"Lanre Ibironke","score":"0","currentage":"11","aggregate":"0","tableName":"oyinalofescores","currentTotalAggregate":"32.908"},{"id":"29","date":"2016-08-21","exercise":"The Innovative Demands of Leadership","type":"Quiz 5","source":"Myles Munroe","score":"40","currentage":"11","aggregate":"3.636","tableName":"oyinalofescores","currentTotalAggregate":"36.544"},{"id":"30","date":"2016-08-28","exercise":"The Best Kept Secret","type":"Quiz 6 & Annotation","source":"Lanre Ibironke","score":"40","currentage":"11","aggregate":"3.636","tableName":"oyinalofescores","currentTotalAggregate":"40.18"},{"id":"31","date":"2016-09-04","exercise":"Divine Secrets","type":"Annotation","source":"Lanre Ibironke","score":"75","currentage":"11","aggregate":"6.818","tableName":"oyinalofescores","currentTotalAggregate":"46.998"},{"id":"32","date":"2016-09-11","exercise":"Repositioning for Exploits","type":"Online Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"11","aggregate":"0","tableName":"oyinalofescores","currentTotalAggregate":"46.998"}]', '{"cTab":"Message","wQAnswered":"15","wQGotten":"13","wQMissed":"2","mQAnswered":"36","mQGotten":"30","mQMissed":"6","sTyped":"2","sWordsTyped":"Proverbs 7;2-Keep my commandments and live, and keep my law and teaching as the apple (the pupil) of your eye.","sGotten":"0","sMissed":"2","tPoints":"225","eAForToday":"18.761","totalAggregate":"1165.196","email":"oyinalofe@gmail.com","age":"12"}');
INSERT INTO `profiles` VALUES(14, 'Elijah', 'Shonde', '14', 'elijahshonde@gmail.com', 'b8e11e2d4cf35d6e1c7df1db642f7a4fea4921d6', '405.342', '13th', '0', '3F0E00', 'ES', 'GOAL23', 'elijahshondescores', '[{"id":"1","date":"2016-01-03","exercise":"Eternal Life","type":"Review","source":"Andrew Wommack","score":"0","currentage":"12","aggregate":"0.000","tableName":"elijahshondescores","currentTotalAggregate":"0"},{"id":"2","date":"2016-01-10","exercise":"Close Encounter of the God Kind","type":"Review ","source":"Jesse Duplantis","score":"0","currentage":"12","aggregate":"0.000","tableName":"elijahshondescores","currentTotalAggregate":"0"},{"id":"3","date":"2016-01-31","exercise":"Growing Up Spiritually","type":"Review","source":"Kenneth E Hagin","score":"0","currentage":"12","aggregate":"0.000","tableName":"elijahshondescores","currentTotalAggregate":"0"},{"id":"4","date":"2016-02-07","exercise":"The Cost of a Crown","type":"Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"12","aggregate":"0.000","tableName":"elijahshondescores","currentTotalAggregate":"0"},{"id":"5","date":"2016-02-14","exercise":"The Love Walk","type":"Review","source":"Kenneth E Hagin","score":"0","currentage":"12","aggregate":"0.000","tableName":"elijahshondescores","currentTotalAggregate":"0"},{"id":"6","date":"2016-02-21","exercise":"Opted for Group Discussion","type":"Group Discussion","source":"Youths","score":"0","currentage":"13","aggregate":"0.000","tableName":"elijahshondescores","currentTotalAggregate":"0"},{"id":"7","date":"2016-03-13","exercise":"Repositioning for Exploits","type":"Review","source":"Bishop David Oyedepo","score":"0","currentage":"13","aggregate":"0.000","tableName":"elijahshondescores","currentTotalAggregate":"0"},{"id":"8","date":"2016-03-27","exercise":"1John 4:4","type":"Synonyms","source":"Lanre Ibironke","score":"26","currentage":"13","aggregate":"2.000","tableName":"elijahshondescores","currentTotalAggregate":"2"},{"id":"9","date":"2016-04-03","exercise":"Hand Sequence","type":"Focus Test","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0.000","tableName":"elijahshondescores","currentTotalAggregate":"2"},{"id":"10","date":"2016-04-10","exercise":"Yesterday, Today and Tomorrow","type":"Annotation and Silence Half Hour","source":"Lanre Ibironke","score":"33","currentage":"13","aggregate":"2.538","tableName":"elijahshondescores","currentTotalAggregate":"4.538"},{"id":"11","date":"2016-04-17","exercise":"Your Abilities","type":"Annotation and Hand Sequence","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0.000","tableName":"elijahshondescores","currentTotalAggregate":"4.538"},{"id":"12","date":"2016-04-24","exercise":"Maximizing Your Most Valuable Asset","type":"Home Work","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0.000","tableName":"elijahshondescores","currentTotalAggregate":"4.538"},{"id":"13","date":"2016-05-01","exercise":"Character Custodian of Destiny","type":"Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"13","aggregate":"0.000","tableName":"elijahshondescores","currentTotalAggregate":"4.538"},{"id":"14","date":"2016-05-08","exercise":"The Myth of Singleness","type":"Question","source":"The Myth of Singleness","score":"25","currentage":"13","aggregate":"1.923","tableName":"elijahshondescores","currentTotalAggregate":"6.461"},{"id":"15","date":"2016-05-15","exercise":"Being Still (Psalms 46vs10)","type":"Chicken on Egg Scenario","source":"Lanre Ibironke","score":"5","currentage":"13","aggregate":"0.385","tableName":"elijahshondescores","currentTotalAggregate":"6.846"},{"id":"16","date":"2016-05-22","exercise":"Selecting the Most Appropriate Word Replacement","type":"Quiz","source":"Lanre Ibironke","score":"45","currentage":"13","aggregate":"3.462","tableName":"elijahshondescores","currentTotalAggregate":"10.308"},{"id":"17","date":"2016-05-29","exercise":"Personalizing Scripture","type":"Theory Question","source":"Lanre Ibironke","score":"4","currentage":"13","aggregate":"0.308","tableName":"elijahshondescores","currentTotalAggregate":"10.616"},{"id":"18","date":"2016-06-05","exercise":"Inner Counsel","type":"Annotation","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0","tableName":"elijahshondescores","currentTotalAggregate":"10.616"},{"id":"19","date":"2016-06-12","exercise":"Bible Questions","type":"General Quiz","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0","tableName":"elijahshondescores","currentTotalAggregate":"10.616"},{"id":"20","date":"2016-06-19","exercise":"Marathon Question","type":"General Quiz 2","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0","tableName":"elijahshondescores","currentTotalAggregate":"10.616"},{"id":"21","date":"2016-06-26","exercise":"Uzziah''s Story","type":"Annotation","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0","tableName":"elijahshondescores","currentTotalAggregate":"10.616"},{"id":"22","date":"2016-07-03","exercise":"Multiple Choice","type":"General Quiz 3","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0","tableName":"elijahshondescores","currentTotalAggregate":"10.616"},{"id":"23","date":"2016-07-10","exercise":"4-Cards","type":"Bible Game","source":"Lanre Ibironke","score":"19","currentage":"13","aggregate":"1.462","tableName":"elijahshondescores","currentTotalAggregate":"12.078"},{"id":"24","date":"2016-07-24","exercise":"Memory Test","type":"Theory Questions","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0","tableName":"elijahshondescores","currentTotalAggregate":"12.078"},{"id":"25","date":"2016-07-31","exercise":"Scripture Expansion","type":"Presentation","source":"Lanre Ibironke","score":"24","currentage":"13","aggregate":"1.846","tableName":"elijahshondescores","currentTotalAggregate":"13.924"},{"id":"26","date":"2016-08-07","exercise":"Multiple Choice","type":"General Quiz 4","source":"Lanre Ibironke","score":"58","currentage":"13","aggregate":"4.462","tableName":"elijahshondescores","currentTotalAggregate":"18.386"},{"id":"27","date":"2016-08-14","exercise":"Tower of Hanoi & Marriage","type":"Puzzle  & Annotation","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0","tableName":"elijahshondescores","currentTotalAggregate":"18.386"},{"id":"28","date":"2016-08-21","exercise":"The Innovative Demands of Leadership","type":"Quiz 5","source":"Myles Munroe","score":"25","currentage":"13","aggregate":"1.923","tableName":"elijahshondescores","currentTotalAggregate":"20.309"},{"id":"29","date":"2016-08-28","exercise":"The Best Kept Secret","type":"Quiz 6 & Annotation","source":"Lanre Ibironke","score":"15","currentage":"13","aggregate":"1.154","tableName":"elijahshondescores","currentTotalAggregate":"21.463"},{"id":"30","date":"2016-09-04","exercise":"Divine Secrets","type":"Annotation","source":"Lanre Ibironke","score":"60","currentage":"13","aggregate":"4.615","tableName":"elijahshondescores","currentTotalAggregate":"26.078000000000003"},{"id":"31","date":"2016-09-11","exercise":"Repositioning for Exploits","type":"Online Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"13","aggregate":"0","tableName":"elijahshondescores","currentTotalAggregate":"26.078"}]', '');
INSERT INTO `profiles` VALUES(15, 'Precious', 'Falodun', '14', 'ayomideprecious.falodun@gmail.com', 'afeb56ed5db401b876db4d25527fc2bc77a947b1', '318.984', '16th', '0', '291515', 'PF', 'PreciousF234', 'preciousfalodunscores', '[{"id":"1","date":"2016-01-03","exercise":"Eternal Life","type":"Review","source":"Andrew Wommack","score":"0","currentage":"17","aggregate":"0.000","tableName":"sholaapetujescores","currentTotalAggregate":"0"},{"id":"2","date":"2016-01-10","exercise":"Close Encounter of the God Kind","type":"Review","source":"Jesse Duplantis","score":"0","currentage":"17","aggregate":"0.000","tableName":"sholaapetujescores","currentTotalAggregate":"0"},{"id":"3","date":"2016-01-31","exercise":"Growing Up Spiritually","type":"Review","source":"Kenneth E Hagin","score":"0","currentage":"17","aggregate":"0.000","tableName":"sholaapetujescores","currentTotalAggregate":"0"},{"id":"4","date":"2016-02-07","exercise":"The Cost of a Crown","type":"Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"17","aggregate":"0.000","tableName":"sholaapetujescores","currentTotalAggregate":"0"},{"id":"5","date":"2016-02-14","exercise":"The Love Walk","type":"Review","source":"Kenneth E Hagin","score":"18","currentage":"17","aggregate":"1.059","tableName":"sholaapetujescores","currentTotalAggregate":"1.059"},{"id":"6","date":"2016-02-21","exercise":"Opted for Group Discussion","type":"Group Discussion","source":"Youths","score":"0","currentage":"17","aggregate":"0.000","tableName":"sholaapetujescores","currentTotalAggregate":"1.059"},{"id":"7","date":"2016-03-13","exercise":"Repositioning for Exploits","type":"Review","source":"Bishop David Oyedepo","score":"0","currentage":"17","aggregate":"0.000","tableName":"sholaapetujescores","currentTotalAggregate":"1.059"},{"id":"8","date":"2016-03-27","exercise":"1John 4:4","type":"Synonyms","source":"Lanre Ibironke","score":"0","currentage":"17","aggregate":"0.000","tableName":"sholaapetujescores","currentTotalAggregate":"1.059"},{"id":"9","date":"2016-04-03","exercise":"Hand Sequence","type":"Focus Test","source":"Lanre Ibironke","score":"53","currentage":"17","aggregate":"3.118","tableName":"sholaapetujescores","currentTotalAggregate":"4.177"},{"id":"10","date":"2016-04-10","exercise":"Yesterday, Today and Tomorrow","type":"Annotation and Silence Half Hour","source":"Lanre Ibironke","score":"0","currentage":"17","aggregate":"0.000","tableName":"sholaapetujescores","currentTotalAggregate":"4.177"},{"id":"11","date":"2016-04-17","exercise":"Your Abilities","type":"Annotation and Hand Sequence","source":"Lanre Ibironke","score":"0","currentage":"17","aggregate":"0.000","tableName":"sholaapetujescores","currentTotalAggregate":"4.177"},{"id":"12","date":"2016-04-24","exercise":"Maximizing Your Most Valuable Asset","type":"Home Work","source":"Lanre Ibironke","score":"0","currentage":"17","aggregate":"0.000","tableName":"sholaapetujescores","currentTotalAggregate":"4.177"},{"id":"13","date":"2016-05-01","exercise":"Character Custodian of Destiny","type":"Quiz","source":"Bishop David Oyedepo","score":"50","currentage":"17","aggregate":"2.941","tableName":"sholaapetujescores","currentTotalAggregate":"7.118"},{"id":"14","date":"2016-05-08","exercise":"The Myth of Singleness","type":"Questions","source":"Dr Myles Munroe","score":"0","currentage":"17","aggregate":"0.000","tableName":"sholaapetujescores","currentTotalAggregate":"7.118"},{"id":"15","date":"2016-05-15","exercise":"Being Still (Psalms 46vs10)","type":"Chicken on Egg Scenario","source":"Lanre Ibironke","score":"0","currentage":"17","aggregate":"0.000","tableName":"sholaapetujescores","currentTotalAggregate":"7.118"},{"id":"16","date":"2016-05-22","exercise":"Selecting the Most Appropriate Word Replacement","type":"Quiz","source":"Lanre Ibironke","score":"0","currentage":"17","aggregate":"0.000","tableName":"sholaapetujescores","currentTotalAggregate":"7.118"},{"id":"17","date":"2016-05-29","exercise":"Personalizing Scripture","type":"Theory Question","source":"Lanre Ibironke","score":"0","currentage":"17","aggregate":"0","tableName":"sholaapetujescores","currentTotalAggregate":"7.118"},{"id":"18","date":"2016-06-05","exercise":"Inner Counsel","type":"Annotation","source":"Lanre Ibironke","score":"30","currentage":"17","aggregate":"1.765","tableName":"sholaapetujescores","currentTotalAggregate":"8.883"},{"id":"19","date":"2016-06-12","exercise":"Bible Questions","type":"General Quiz","source":"Lanre Ibironke","score":"0","currentage":"17","aggregate":"0","tableName":"sholaapetujescores","currentTotalAggregate":"8.883"},{"id":"20","date":"2016-06-19","exercise":"Marathon Question","type":"General Quiz 2","source":"Lanre Ibironke","score":"0","currentage":"17","aggregate":"0","tableName":"sholaapetujescores","currentTotalAggregate":"8.883"},{"id":"21","date":"2016-06-26","exercise":"Uzziah''s Story","type":"Annotation","source":"Lanre Ibironke","score":"5","currentage":"17","aggregate":"0.294","tableName":"sholaapetujescores","currentTotalAggregate":"9.177"},{"id":"22","date":"2016-07-03","exercise":"Multiple Choice","type":"General Quiz 3","source":"Lanre Ibironke","score":"48","currentage":"17","aggregate":"2.824","tableName":"sholaapetujescores","currentTotalAggregate":"12.001"},{"id":"23","date":"2016-07-10","exercise":"4-Cards","type":"Bible Game","source":"Lanre Ibironke","score":"12","currentage":"17","aggregate":"0.706","tableName":"sholaapetujescores","currentTotalAggregate":"12.707"},{"id":"24","date":"2016-07-24","exercise":"Memory Test","type":"Theory Questions","source":"Lanre Ibironke","score":"0","currentage":"17","aggregate":"0","tableName":"sholaapetujescores","currentTotalAggregate":"12.707"},{"id":"25","date":"2016-07-31","exercise":"Scripture Expansion","type":"Presentation","source":"Lanre Ibironke","score":"0","currentage":"17","aggregate":"0","tableName":"sholaapetujescores","currentTotalAggregate":"12.707"},{"id":"26","date":"2016-08-07","exercise":"Multiple Choice","type":"General Quiz 4","source":"Lanre Ibironke","score":"0","currentage":"17","aggregate":"0","tableName":"sholaapetujescores","currentTotalAggregate":"12.707"},{"id":"27","date":"2016-08-14","exercise":"Tower of Hanoi & Marriage","type":"Puzzle  & Annotation","source":"Lanre Ibironke","score":"0","currentage":"17","aggregate":"0","tableName":"sholaapetujescores","currentTotalAggregate":"12.707"},{"id":"28","date":"2016-08-21","exercise":"The Innovative Demands of Leadership","type":"Quiz 5","source":"Myles Munroe","score":"0","currentage":"17","aggregate":"0","tableName":"sholaapetujescores","currentTotalAggregate":"12.707"},{"id":"29","date":"2016-08-28","exercise":"The Best Kept Secret","type":"Quiz 6 & Annotation","source":"Lanre Ibironke","score":"0","currentage":"17","aggregate":"0","tableName":"sholaapetujescores","currentTotalAggregate":"12.707"},{"id":"30","date":"2016-09-04","exercise":"Divine Secrets","type":"Annotation","source":"Lanre Ibironke","score":"0","currentage":"17","aggregate":"0","tableName":"sholaapetujescores","currentTotalAggregate":"12.707"},{"id":"31","date":"2016-09-11","exercise":"Repositioning for Exploits","type":"Online Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"17","aggregate":"0","tableName":"sholaapetujescores","currentTotalAggregate":"12.707"}]', '{"cTab":"Message","wQAnswered":"15","wQGotten":"15","wQMissed":"0","mQAnswered":"76","mQGotten":"71","mQMissed":"5","sTyped":"0","sWordsTyped":"","sGotten":"0","sMissed":"0","tPoints":"435","eAForToday":"31.057","totalAggregate":"318.984","email":"ayomideprecious.falodun@gmail.com","age":"14"}');
INSERT INTO `profiles` VALUES(16, 'Tolu', 'Apetuje', '16', 'toluapetuje@gmail.com', '114b218c1f97e835a64b6e2f236c96624a011d24', '352.19', '15th', '0', 'D13401', 'TA', '15', 'toluapetujescores', '[{"id":"1","date":"2016-01-03","exercise":"Eternal Life","type":"Review","source":"Andrew Wommack","score":"0","currentage":"15","aggregate":"0.000","tableName":"toluapetujescores","currentTotalAggregate":"0"},{"id":"2","date":"2016-01-10","exercise":"Close Encounter of the God Kind","type":"Review","source":"Jesse Duplantis","score":"0","currentage":"15","aggregate":"0.000","tableName":"toluapetujescores","currentTotalAggregate":"0"},{"id":"3","date":"2016-01-31","exercise":"Growing Up Spiritually","type":"Review","source":"Kenneth E Hagin","score":"0","currentage":"15","aggregate":"0.000","tableName":"toluapetujescores","currentTotalAggregate":"0"},{"id":"4","date":"2016-02-07","exercise":"The Cost of a Crown","type":"Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"15","aggregate":"0.000","tableName":"toluapetujescores","currentTotalAggregate":"0"},{"id":"5","date":"2016-02-14","exercise":"The Love Walk","type":"Review","source":"Kenneth E Hagin","score":"0","currentage":"15","aggregate":"0.000","tableName":"toluapetujescores","currentTotalAggregate":"0"},{"id":"6","date":"2016-02-21","exercise":"Opted for Group Discussion","type":"Group Discussion","source":"Youth","score":"0","currentage":"15","aggregate":"0.000","tableName":"toluapetujescores","currentTotalAggregate":"0"},{"id":"7","date":"2016-03-13","exercise":"Repositioning for Exploits","type":"Review","source":"Bishop David Oyedepo","score":"0","currentage":"15","aggregate":"0.000","tableName":"toluapetujescores","currentTotalAggregate":"0"},{"id":"8","date":"2016-03-27","exercise":"1John 4:4","type":"Synonyms","source":"Lanre Ibironke","score":"0","currentage":"15","aggregate":"0.000","tableName":"toluapetujescores","currentTotalAggregate":"0"},{"id":"9","date":"2016-04-03","exercise":"Hand Sequence ","type":"Focus Test","source":"Lanre Ibironke","score":"52","currentage":"15","aggregate":"3.467","tableName":"toluapetujescores","currentTotalAggregate":"3.467"},{"id":"10","date":"2016-04-10","exercise":"Yesterday, Today and Tomorrow","type":"Annotation and Silence Half Hour","source":"Lanre Ibironke","score":"0","currentage":"15","aggregate":"0.000","tableName":"toluapetujescores","currentTotalAggregate":"3.467"},{"id":"11","date":"2016-04-17","exercise":"Your Abilities","type":"Annotation and Hand Sequence","source":"Lanre Ibironke","score":"0","currentage":"15","aggregate":"0.000","tableName":"toluapetujescores","currentTotalAggregate":"3.467"},{"id":"12","date":"2016-04-24","exercise":"Maximizing Your Most Valuable Asset","type":"Home Work","source":"Lanre Ibironke","score":"0","currentage":"15","aggregate":"0.000","tableName":"toluapetujescores","currentTotalAggregate":"3.467"},{"id":"13","date":"2016-05-01","exercise":"Character Custodian of Destiny","type":"Quiz","source":"Lanre Ibironke","score":"0","currentage":"15","aggregate":"0.000","tableName":"toluapetujescores","currentTotalAggregate":"3.467"},{"id":"14","date":"2016-05-08","exercise":"The Myth of Singleness","type":"Questions","source":"Dr Myles Munroe","score":"0","currentage":"15","aggregate":"0.000","tableName":"toluapetujescores","currentTotalAggregate":"3.467"},{"id":"15","date":"2016-05-15","exercise":"Being Still (Psalms 46vs10)","type":"Chicken on Egg Scenario","source":"Lanre Ibironke","score":"2","currentage":"15","aggregate":"0.133","tableName":"toluapetujescores","currentTotalAggregate":"3.6"},{"id":"16","date":"2016-05-22","exercise":"Selecting the Most Appropriate Word Replacement","type":"Quiz","source":"Lanre Ibironke","score":"45","currentage":"15","aggregate":"3.000","tableName":"toluapetujescores","currentTotalAggregate":"6.6"},{"id":"17","date":"2016-05-29","exercise":"Personalizing Scripture","type":"Theory Question","source":"Lanre Ibironke","score":"30","currentage":"15","aggregate":"2","tableName":"toluapetujescores","currentTotalAggregate":"8.6"},{"id":"18","date":"2016-06-05","exercise":"Inner Counsel","type":"Annotation","source":"Lanre Ibironke","score":"35","currentage":"15","aggregate":"2.333","tableName":"toluapetujescores","currentTotalAggregate":"10.933"},{"id":"19","date":"2016-06-12","exercise":"Bible Questions","type":"General Quiz","source":"Lanre Ibironke","score":"0","currentage":"15","aggregate":"0","tableName":"toluapetujescores","currentTotalAggregate":"10.933"},{"id":"20","date":"2016-06-19","exercise":"Marathon Question","type":"General Quiz 2","source":"Lanre Ibironke","score":"0","currentage":"15","aggregate":"0","tableName":"toluapetujescores","currentTotalAggregate":"10.933"},{"id":"21","date":"2016-06-26","exercise":"Uzziah''s Story","type":"Annotation","source":"Lanre Ibironke","score":"0","currentage":"15","aggregate":"0","tableName":"toluapetujescores","currentTotalAggregate":"10.933"},{"id":"22","date":"2016-07-03","exercise":"Multiple Choice","type":"General Quiz 3","source":"Lanre Ibironke","score":"48","currentage":"15","aggregate":"3.2","tableName":"toluapetujescores","currentTotalAggregate":"14.133"},{"id":"23","date":"2016-07-10","exercise":"4-Cards","type":"Bible Game","source":"Lanre Ibironke","score":"11","currentage":"15","aggregate":"0.733","tableName":"toluapetujescores","currentTotalAggregate":"14.866"},{"id":"24","date":"2016-07-24","exercise":"Memory Test","type":"Theory Questions","source":"Lanre Ibironke","score":"0","currentage":"15","aggregate":"0","tableName":"toluapetujescores","currentTotalAggregate":"14.866"},{"id":"25","date":"2016-07-31","exercise":"Scripture Expansion","type":"Presentation","source":"Lanre Ibironke","score":"0","currentage":"15","aggregate":"0","tableName":"toluapetujescores","currentTotalAggregate":"14.866"},{"id":"26","date":"2016-08-07","exercise":"Multiple Choice","type":"General Quiz 4","source":"Lanre Ibironke","score":"70","currentage":"15","aggregate":"4.667","tableName":"toluapetujescores","currentTotalAggregate":"19.533"},{"id":"27","date":"2016-08-14","exercise":"Tower of Hanoi & Marriage","type":"Puzzle  & Annotation","source":"Lanre Ibironke","score":"0","currentage":"15","aggregate":"0","tableName":"toluapetujescores","currentTotalAggregate":"19.533"},{"id":"28","date":"2016-08-21","exercise":"The Innovative Demands of Leadership","type":"Quiz 5","source":"Myles Munroe","score":"23","currentage":"15","aggregate":"1.533","tableName":"toluapetujescores","currentTotalAggregate":"21.066"},{"id":"29","date":"2016-08-28","exercise":"The Best Kept Secret","type":"Quiz 6 & Annotation","source":"Lanre Ibironke","score":"20","currentage":"15","aggregate":"1.333","tableName":"toluapetujescores","currentTotalAggregate":"22.399"},{"id":"30","date":"2016-09-04","exercise":"Divine Secrets","type":"Annotation","source":"Lanre Ibironke","score":"73","currentage":"15","aggregate":"4.867","tableName":"toluapetujescores","currentTotalAggregate":"27.266000000000002"},{"id":"31","date":"2016-09-11","exercise":"Repositioning for Exploits","type":"Online Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"15","aggregate":"0","tableName":"toluapetujescores","currentTotalAggregate":"27.266"}]', '');
INSERT INTO `profiles` VALUES(17, 'Ebubechukwu', 'Igwegbe', '13', 'ebubechukwuigwegbe@gmail.com', '32b8908ca46926885afb68e5f26024714aba4b3a', '31.261', '25th', '0', '80305D', 'EI', 'ei', 'ebubechukwuigwegbescores', '[{"id":"1","date":"2016-01-03","exercise":"Eternal Life","type":"Review","source":"Andrew Wommack","score":"0","currentage":"12","aggregate":"0.000","tableName":"ebubechukwuigwegbescores","currentTotalAggregate":"0"},{"id":"2","date":"2016-01-10","exercise":"Close Encounter of the God Kind","type":"Review","source":"Jesse Duplantis","score":"0","currentage":"12","aggregate":"0.000","tableName":"ebubechukwuigwegbescores","currentTotalAggregate":"0"},{"id":"3","date":"2016-01-31","exercise":"Growing Up Spiritually","type":"Review","source":"Kenneth E Hagin","score":"0","currentage":"12","aggregate":"0.000","tableName":"ebubechukwuigwegbescores","currentTotalAggregate":"0"},{"id":"4","date":"2016-02-07","exercise":"The Cost of a Crown","type":"Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"13","aggregate":"0.000","tableName":"ebubechukwuigwegbescores","currentTotalAggregate":"0"},{"id":"5","date":"2016-02-14","exercise":"The Love Walk","type":"Review","source":"Kenneth E Hagin","score":"0","currentage":"13","aggregate":"0.000","tableName":"ebubechukwuigwegbescores","currentTotalAggregate":"0"},{"id":"6","date":"2016-02-21","exercise":"Opted for Group Discussion","type":"Group Discussion","source":"Youths","score":"0","currentage":"13","aggregate":"0.000","tableName":"ebubechukwuigwegbescores","currentTotalAggregate":"0"},{"id":"7","date":"2016-03-13","exercise":"Repositioning for Exploits","type":"Review","source":"Bishop David Oyedepo","score":"0","currentage":"13","aggregate":"0.000","tableName":"ebubechukwuigwegbescores","currentTotalAggregate":"0"},{"id":"8","date":"2016-03-27","exercise":"1John 4:4","type":"Synonyms","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0.000","tableName":"ebubechukwuigwegbescores","currentTotalAggregate":"0"},{"id":"9","date":"2016-04-03","exercise":"Hand Sequence","type":"Focus Test","source":"Lanre Ibironke","score":"18","currentage":"13","aggregate":"1.385","tableName":"ebubechukwuigwegbescores","currentTotalAggregate":"1.385"},{"id":"10","date":"2016-04-10","exercise":"Yesterday, Today and Tomorrow","type":"Annotation and Silence Half Hour","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0.000","tableName":"ebubechukwuigwegbescores","currentTotalAggregate":"1.385"},{"id":"11","date":"2016-04-17","exercise":"Your Abilities","type":"Annotation and Hand Sequence","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0.000","tableName":"ebubechukwuigwegbescores","currentTotalAggregate":"1.385"},{"id":"12","date":"2016-04-24","exercise":"Maximizing Your Most Valuable Asset","type":"Home Work","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0.000","tableName":"ebubechukwuigwegbescores","currentTotalAggregate":"1.385"},{"id":"13","date":"2016-05-01","exercise":"Character, Custodian of Destiny","type":"Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"13","aggregate":"0.000","tableName":"ebubechukwuigwegbescores","currentTotalAggregate":"1.385"},{"id":"14","date":"2016-05-08","exercise":"The Myth of Singleness","type":"Questions","source":"Myles Munroe","score":"0","currentage":"13","aggregate":"0.000","tableName":"ebubechukwuigwegbescores","currentTotalAggregate":"1.385"},{"id":"15","date":"2016-05-15","exercise":"Being Still (Psalms 46vs10)","type":"Chicken on Egg Scenario","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0.000","tableName":"ebubechukwuigwegbescores","currentTotalAggregate":"1.385"},{"id":"16","date":"2016-05-22","exercise":"Selecting the Most Appropriate Word Replacement","type":"Quiz","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0.000","tableName":"ebubechukwuigwegbescores","currentTotalAggregate":"1.385"},{"id":"17","date":"2016-05-29","exercise":"Personalizing Scripture","type":"Theory Question","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0","tableName":"ebubechukwuigwegbescores","currentTotalAggregate":"1.385"},{"id":"18","date":"2016-06-05","exercise":"Inner Counsel","type":"Annotation","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0","tableName":"ebubechukwuigwegbescores","currentTotalAggregate":"1.385"},{"id":"19","date":"2016-06-12","exercise":"Bible Questions","type":"General Quiz","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0","tableName":"ebubechukwuigwegbescores","currentTotalAggregate":"1.385"},{"id":"20","date":"2016-06-19","exercise":"Marathon Question","type":"General Quiz 2","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0","tableName":"ebubechukwuigwegbescores","currentTotalAggregate":"1.385"},{"id":"21","date":"2016-06-26","exercise":"Uzziah''s Story","type":"Annotation","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0","tableName":"ebubechukwuigwegbescores","currentTotalAggregate":"1.385"},{"id":"22","date":"2016-07-03","exercise":"Multiple Choice","type":"General Quiz 3","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0","tableName":"ebubechukwuigwegbescores","currentTotalAggregate":"1.385"},{"id":"23","date":"2016-07-10","exercise":"4-Cards","type":"Bible Game","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0","tableName":"ebubechukwuigwegbescores","currentTotalAggregate":"1.385"},{"id":"24","date":"2016-07-24","exercise":"Memory Test","type":"Theory Questions","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0","tableName":"ebubechukwuigwegbescores","currentTotalAggregate":"1.385"},{"id":"25","date":"2016-07-31","exercise":"Scripture Expansion","type":"Presentation","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0","tableName":"ebubechukwuigwegbescores","currentTotalAggregate":"1.385"},{"id":"26","date":"2016-08-07","exercise":"Multiple Choice","type":"General Quiz 4","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0","tableName":"ebubechukwuigwegbescores","currentTotalAggregate":"1.385"},{"id":"27","date":"2016-08-14","exercise":"Tower of Hanoi & Marriage","type":"Puzzle  & Annotation","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0","tableName":"ebubechukwuigwegbescores","currentTotalAggregate":"1.385"},{"id":"28","date":"2016-08-21","exercise":"The Innovative Demands of Leadership","type":"Quiz 5","source":"Myles Munroe","score":"0","currentage":"13","aggregate":"0","tableName":"ebubechukwuigwegbescores","currentTotalAggregate":"1.385"},{"id":"29","date":"2016-08-28","exercise":"The Best Kept Secret","type":"Quiz 6 & Annotation","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0","tableName":"ebubechukwuigwegbescores","currentTotalAggregate":"1.385"},{"id":"30","date":"2016-09-04","exercise":"Divine Secrets","type":"Annotation","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0","tableName":"ebubechukwuigwegbescores","currentTotalAggregate":"1.385"},{"id":"31","date":"2016-09-11","exercise":"Repositioning for Exploits","type":"Online Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"13","aggregate":"0","tableName":"ebubechukwuigwegbescores","currentTotalAggregate":"1.385"}]', '');
INSERT INTO `profiles` VALUES(18, 'David', 'Alamu', '16', 'jarvis.alamu@gmail.com', 'f5b470627f796cce9f3df5b1a271768b8f4b7295', '217.978', '19th', '0', '200F0D', 'DA', 'motumbo', 'davidalamuscores', '[{"id":"1","date":"2016-01-03","exercise":"Eternal Life","type":"Review","source":"Andrew Wommack","score":"0","currentage":"15","aggregate":"0.000","tableName":"davidalamuscores","currentTotalAggregate":"0"},{"id":"2","date":"2016-01-10","exercise":"Close Encounter of the God Kind","type":"Review","source":"Jesse Duplantis","score":"0","currentage":"15","aggregate":"0.000","tableName":"davidalamuscores","currentTotalAggregate":"0"},{"id":"3","date":"2016-01-31","exercise":"Growing Up Spiritually","type":"Review","source":"Kenneth E Hagin","score":"0","currentage":"15","aggregate":"0.000","tableName":"davidalamuscores","currentTotalAggregate":"0"},{"id":"4","date":"2016-02-07","exercise":"The Cost of a Crown","type":"Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"15","aggregate":"0.000","tableName":"davidalamuscores","currentTotalAggregate":"0"},{"id":"5","date":"2016-02-14","exercise":"The Love Walk","type":"Review","source":"Kenneth E Hagin","score":"0","currentage":"15","aggregate":"0.000","tableName":"davidalamuscores","currentTotalAggregate":"0"},{"id":"6","date":"2016-02-21","exercise":"Opted for Group Discussion","type":"Group Discussion","source":"Youth","score":"0","currentage":"15","aggregate":"0.000","tableName":"davidalamuscores","currentTotalAggregate":"0"},{"id":"7","date":"2016-03-13","exercise":"Repositioning for Exploits","type":"Review","source":"Bishop David Oyedepo","score":"0","currentage":"15","aggregate":"0.000","tableName":"davidalamuscores","currentTotalAggregate":"0"},{"id":"8","date":"2016-03-27","exercise":"1John 4:4","type":"Synonyms","source":"Lanre Ibironke","score":"0","currentage":"15","aggregate":"0.000","tableName":"davidalamuscores","currentTotalAggregate":"0"},{"id":"9","date":"2016-04-03","exercise":"Hand Sequence","type":"Focus Test","source":"Lanre Ibironke","score":"0","currentage":"15","aggregate":"0.000","tableName":"davidalamuscores","currentTotalAggregate":"0"},{"id":"10","date":"2016-04-10","exercise":"Yesterday, Today and Tomorrow","type":"Annotation and Silence Half Hour","source":"Lanre Ibironke","score":"0","currentage":"15","aggregate":"0.000","tableName":"davidalamuscores","currentTotalAggregate":"0"},{"id":"11","date":"2016-04-17","exercise":"Your Abilities","type":"Annotation and Hand Sequence","source":"Lanre Ibironke","score":"0","currentage":"15","aggregate":"0.000","tableName":"davidalamuscores","currentTotalAggregate":"0"},{"id":"12","date":"2016-04-24","exercise":"Maximizing Your Most Valuable Asset","type":"Home Work","source":"Lanre Ibironke","score":"0","currentage":"15","aggregate":"0.000","tableName":"davidalamuscores","currentTotalAggregate":"0"},{"id":"13","date":"2016-05-01","exercise":"Character Custodian of Destiny","type":"Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"15","aggregate":"0.000","tableName":"davidalamuscores","currentTotalAggregate":"0"},{"id":"14","date":"2016-05-08","exercise":"The Myth of Singleness","type":"Questions","source":"Dr Myles Munroe","score":"0","currentage":"15","aggregate":"0.000","tableName":"davidalamuscores","currentTotalAggregate":"0"},{"id":"15","date":"2016-05-15","exercise":"Being Still (Psalms 46vs10)","type":"Chicken on Egg Scenario","source":"Lanre Ibironke","score":"9","currentage":"15","aggregate":"0.600","tableName":"davidalamuscores","currentTotalAggregate":"0.6"},{"id":"16","date":"2016-05-22","exercise":"Selecting the Most Appropriate Word Replacement","type":"Quiz","source":"Lanre Ibironke","score":"45","currentage":"15","aggregate":"3.000","tableName":"davidalamuscores","currentTotalAggregate":"3.6"},{"id":"17","date":"2016-05-29","exercise":"Personalizing Scripture","type":"Theory Question","source":"Lanre Ibironke","score":"31","currentage":"15","aggregate":"2.067","tableName":"davidalamuscores","currentTotalAggregate":"5.667"},{"id":"18","date":"2016-06-05","exercise":"Inner Counsel","type":"Annotation","source":"Lanre Ibironke","score":"35","currentage":"15","aggregate":"2.333","tableName":"davidalamuscores","currentTotalAggregate":"8"},{"id":"19","date":"2016-06-12","exercise":"Bible Questions","type":"General Quiz","source":"Lanre Ibironke","score":"0","currentage":"15","aggregate":"0","tableName":"davidalamuscores","currentTotalAggregate":"8"},{"id":"20","date":"2016-06-19","exercise":"Marathon Question","type":"General Quiz 2","source":"Lanre Ibironke","score":"0","currentage":"15","aggregate":"0","tableName":"davidalamuscores","currentTotalAggregate":"8"},{"id":"21","date":"2016-06-26","exercise":"Uzziah''s Story","type":"Annotation","source":"Lanre Ibironke","score":"0","currentage":"15","aggregate":"0","tableName":"davidalamuscores","currentTotalAggregate":"8"},{"id":"22","date":"2016-07-03","exercise":"Multiple Choice","type":"General Quiz 3","source":"Lanre Ibironke","score":"57","currentage":"15","aggregate":"3.8","tableName":"davidalamuscores","currentTotalAggregate":"11.8"},{"id":"23","date":"2016-07-10","exercise":"4-Cards","type":"Bible Game","source":"Lanre Ibironke","score":"11","currentage":"15","aggregate":"0.733","tableName":"davidalamuscores","currentTotalAggregate":"12.533"},{"id":"24","date":"2016-07-24","exercise":"Memory Test","type":"Theory Questions","source":"Lanre Ibironke","score":"0","currentage":"15","aggregate":"0","tableName":"davidalamuscores","currentTotalAggregate":"12.533"},{"id":"25","date":"2016-07-31","exercise":"Scripture Expansion","type":"Presentation","source":"Lanre Ibironke","score":"0","currentage":"15","aggregate":"0","tableName":"davidalamuscores","currentTotalAggregate":"12.533"},{"id":"26","date":"2016-08-07","exercise":"Multiple Choice","type":"General Quiz 4","source":"Lanre Ibironke","score":"53","currentage":"15","aggregate":"3.533","tableName":"davidalamuscores","currentTotalAggregate":"16.066"},{"id":"27","date":"2016-08-14","exercise":"Tower of Hanoi & Marriage","type":"Puzzle  & Annotation","source":"Lanre Ibironke","score":"0","currentage":"15","aggregate":"0","tableName":"davidalamuscores","currentTotalAggregate":"16.066"},{"id":"28","date":"2016-08-21","exercise":"The Innovative Demands of Leadership","type":"Quiz 5","source":"Myles Munroe","score":"16","currentage":"15","aggregate":"1.067","tableName":"davidalamuscores","currentTotalAggregate":"17.133"},{"id":"29","date":"2016-08-28","exercise":"The Best Kept Secret","type":"Quiz 6 & Annotation","source":"Lanre Ibironke","score":"14","currentage":"15","aggregate":"0.933","tableName":"davidalamuscores","currentTotalAggregate":"18.066"},{"id":"30","date":"2016-09-04","exercise":"Divine Secrets","type":"Annotation","source":"Lanre Ibironke","score":"30","currentage":"15","aggregate":"2","tableName":"davidalamuscores","currentTotalAggregate":"20.066"},{"id":"31","date":"2016-09-11","exercise":"Repositioning for Exploits","type":"Online Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"15","aggregate":"0","tableName":"davidalamuscores","currentTotalAggregate":"20.066"}]', '');
INSERT INTO `profiles` VALUES(19, 'Praise', 'Shonde', '11', 'praiseshonde@gmail.com', '3a2df635607564dca00cfed89bb2ec60b6df119b', '482.2', '11th', '0', 'F5100C', 'PS', '7707T', 'praiseshondescores', '[{"id":"10","date":"2016-01-03","exercise":"Eternal Life","type":"Review","source":"Andrew Wommack","score":"0","currentage":"10","aggregate":"0","tableName":"praiseshondescores","currentTotalAggregate":"0"},{"id":"11","date":"2016-01-10","exercise":"Close Encounter of the God Kind","type":"Review","source":"Jesse Duplantis","score":"0","currentage":"10","aggregate":"0","tableName":"praiseshondescores","currentTotalAggregate":"0"},{"id":"12","date":"2016-01-31","exercise":"Growing Up Sppiritually","type":"Review","source":"Kenneth E Hagin","score":"0","currentage":"10","aggregate":"0","tableName":"praiseshondescores","currentTotalAggregate":"0"},{"id":"13","date":"2016-02-07","exercise":"The Cost of a Crown","type":"Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"10","aggregate":"0","tableName":"praiseshondescores","currentTotalAggregate":"0"},{"id":"14","date":"2016-02-14","exercise":"The Love Walk","type":"Review","source":"Kenneth E Hagin","score":"0","currentage":"10","aggregate":"0","tableName":"praiseshondescores","currentTotalAggregate":"0"},{"id":"15","date":"2016-02-21","exercise":"Opted for Group Discussion","type":"Group Discussion","source":"Youths","score":"0","currentage":"10","aggregate":"0","tableName":"praiseshondescores","currentTotalAggregate":"0"},{"id":"16","date":"2016-03-13","exercise":"Repositioning for Exploits","type":"Review","source":"Bishop David Oyedepo","score":"0","currentage":"10","aggregate":"0","tableName":"praiseshondescores","currentTotalAggregate":"0"},{"id":"17","date":"2016-03-27","exercise":"1John 4:4","type":"Synonyms","source":"Lanre Ibironke","score":"0","currentage":"10","aggregate":"0","tableName":"praiseshondescores","currentTotalAggregate":"0"},{"id":"18","date":"2016-04-03","exercise":"Hand Sequence","type":"Focus Test ","source":"Lanre Ibironke","score":"0","currentage":"10","aggregate":"0","tableName":"praiseshondescores","currentTotalAggregate":"0"},{"id":"19","date":"2016-04-10","exercise":"Yesterday, Today and Tomorrow","type":"Annotation and Silence Half Hour","source":"Lanre Ibironke","score":"0","currentage":"10","aggregate":"0","tableName":"praiseshondescores","currentTotalAggregate":"0"},{"id":"20","date":"2016-04-17","exercise":"Your Abilities","type":"Annotation and Hand Sequence","source":"Lanre Ibironke","score":"0","currentage":"10","aggregate":"0","tableName":"praiseshondescores","currentTotalAggregate":"0"},{"id":"21","date":"2016-04-24","exercise":"Maximizing Your Most Valuable Asset","type":"Home Work","source":"Lanre Ibironke","score":"0","currentage":"10","aggregate":"0","tableName":"praiseshondescores","currentTotalAggregate":"0"},{"id":"22","date":"2016-05-01","exercise":"Character Custodian of Destiny","type":"Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"10","aggregate":"0","tableName":"praiseshondescores","currentTotalAggregate":"0"},{"id":"23","date":"2016-05-08","exercise":"The Myth of Singleness","type":"Questions","source":"Dr Myles Munroe","score":"0","currentage":"10","aggregate":"0","tableName":"praiseshondescores","currentTotalAggregate":"0"},{"id":"24","date":"2016-05-15","exercise":"Being Still (Psalms 46vs10)","type":"Chicken on Egg Scenario","source":"Lanre Ibironke","score":"0","currentage":"10","aggregate":"0","tableName":"praiseshondescores","currentTotalAggregate":"0"},{"id":"25","date":"2016-05-22","exercise":"Selecting the Most Appropriate Word Replacement","type":"Quiz","source":"Lanre Ibironke","score":"0","currentage":"10","aggregate":"0","tableName":"praiseshondescores","currentTotalAggregate":"0"},{"id":"26","date":"2016-05-29","exercise":"Personalizing Scripture","type":"Theory Question","source":"Lanre Ibironke","score":"0","currentage":"10","aggregate":"0","tableName":"praiseshondescores","currentTotalAggregate":"0"},{"id":"27","date":"2016-06-05","exercise":"Inner Counsel","type":"Annotation","source":"Lanre Ibironke","score":"0","currentage":"10","aggregate":"0","tableName":"praiseshondescores","currentTotalAggregate":"0"},{"id":"28","date":"2016-06-12","exercise":"Bible Questions","type":"General Quiz","source":"Lanre Ibironke","score":"0","currentage":"10","aggregate":"0","tableName":"praiseshondescores","currentTotalAggregate":"0"},{"id":"29","date":"2016-06-19","exercise":"Marathon Question","type":"General Quiz 2","source":"Lanre Ibironke","score":"0","currentage":"10","aggregate":"0","tableName":"praiseshondescores","currentTotalAggregate":"0"},{"id":"33","date":"2016-06-26","exercise":"Uzziah''s Story","type":"Annotation","source":"Lanre Ibironke","score":"70","currentage":"10","aggregate":"7","tableName":"praiseshondescores","currentTotalAggregate":"7"},{"id":"34","date":"2016-07-03","exercise":"Multiple Choice","type":"General Quiz 3","source":"Lanre Ibironke","score":"0","currentage":"10","aggregate":"0","tableName":"praiseshondescores","currentTotalAggregate":"7"},{"id":"35","date":"2016-07-10","exercise":"4-Cards","type":"Bible Game","source":"Lanre Ibironke","score":"14","currentage":"10","aggregate":"1.4","tableName":"praiseshondescores","currentTotalAggregate":"8.4"},{"id":"46","date":"2016-07-24","exercise":"Memory Test","type":"Theory Questions","source":"Lanre Ibironke","score":"0","currentage":"10","aggregate":"0","tableName":"praiseshondescores","currentTotalAggregate":"8.4"},{"id":"47","date":"2016-07-31","exercise":"Scripture Expansion","type":"Presentation","source":"Lanre Ibironke","score":"24","currentage":"10","aggregate":"2.4","tableName":"praiseshondescores","currentTotalAggregate":"10.8"},{"id":"48","date":"2016-08-07","exercise":"Multiple Choice","type":"General Quiz 4","source":"Lanre Ibironke","score":"48","currentage":"10","aggregate":"4.8","tableName":"praiseshondescores","currentTotalAggregate":"15.6"},{"id":"49","date":"2016-08-14","exercise":"Tower of Hanoi & Marriage","type":"Puzzle & Annotation","source":"Lanre Ibironke","score":"0","currentage":"10","aggregate":"0","tableName":"praiseshondescores","currentTotalAggregate":"15.6"},{"id":"50","date":"2016-08-21","exercise":"The Innovative Demands of Leadership","type":"Quiz 5","source":"Myles Munroe","score":"17","currentage":"10","aggregate":"1.7","tableName":"praiseshondescores","currentTotalAggregate":"17.3"},{"id":"51","date":"2016-08-28","exercise":"The Best Kept Secret","type":"Quiz 6 & Annotation","source":"Lanre Ibironke","score":"12","currentage":"10","aggregate":"1.2","tableName":"praiseshondescores","currentTotalAggregate":"18.5"},{"id":"52","date":"2016-09-04","exercise":"Divine Secrets","type":"Annotation","source":"Lanre Ibironke","score":"40","currentage":"10","aggregate":"4","tableName":"praiseshondescores","currentTotalAggregate":"22.5"},{"id":"53","date":"2016-09-11","exercise":"Repositioning for Exploits","type":"Online Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"10","aggregate":"0","tableName":"praiseshondescores","currentTotalAggregate":"22.5"}]', '');
INSERT INTO `profiles` VALUES(22, 'Ebunoluwa', 'Ajiboye', '14', 'ebunoluwaajiboye@gmail.com', '92a24aadbcf252c162cc3cae2c15ec37bcacd9ba', '1090.599', '4th', '44', '16140C', 'EA', 'Wumight', 'ebunoluwaajiboyescores', '[{"id":"1","date":"2016-01-03","exercise":"Eternal Life","type":"Review","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0","tableName":"kolawolesaintmarkscores","currentTotalAggregate":"0"},{"id":"2","date":"2016-01-10","exercise":"Close Encounter of the God Kind","type":"Review","source":"Jesse Duplantis","score":"0","currentage":"13","aggregate":"0","tableName":"kolawolesaintmarkscores","currentTotalAggregate":"0"},{"id":"3","date":"2016-01-31","exercise":"Growing Up Spiritually","type":"Review","source":"Kenneth E Hagin","score":"0","currentage":"13","aggregate":"0","tableName":"kolawolesaintmarkscores","currentTotalAggregate":"0"},{"id":"4","date":"2016-02-07","exercise":"The Cost of a Crown","type":"Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"13","aggregate":"0","tableName":"kolawolesaintmarkscores","currentTotalAggregate":"0"},{"id":"5","date":"2016-02-14","exercise":"The Love Walk","type":"Review","source":"Kenneth E Hagin","score":"0","currentage":"13","aggregate":"0","tableName":"kolawolesaintmarkscores","currentTotalAggregate":"0"},{"id":"6","date":"2016-02-21","exercise":"Opted for Group Discussion","type":"Group Discussion","source":"Youths","score":"0","currentage":"13","aggregate":"0","tableName":"kolawolesaintmarkscores","currentTotalAggregate":"0"},{"id":"7","date":"2016-03-13","exercise":"Repositioning for Exploits","type":"Review","source":"Bishop David Oyedepo","score":"0","currentage":"13","aggregate":"0","tableName":"kolawolesaintmarkscores","currentTotalAggregate":"0"},{"id":"8","date":"2016-03-27","exercise":"1John 4:4","type":"Synonyms","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0","tableName":"kolawolesaintmarkscores","currentTotalAggregate":"0"},{"id":"9","date":"2016-04-03","exercise":"Hand Sequence","type":"Focus Test","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0","tableName":"kolawolesaintmarkscores","currentTotalAggregate":"0"},{"id":"10","date":"2016-04-10","exercise":"Yesterday, Today and Tomorrow","type":"Annotation and Silence Half Hour","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0","tableName":"kolawolesaintmarkscores","currentTotalAggregate":"0"},{"id":"11","date":"2016-04-17","exercise":"Your Abilities","type":"Annotation & Hand Sequence","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0","tableName":"kolawolesaintmarkscores","currentTotalAggregate":"0"},{"id":"12","date":"2016-04-24","exercise":"Maximizing Your Most Valuable Asset","type":"Home Work","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0","tableName":"kolawolesaintmarkscores","currentTotalAggregate":"0"},{"id":"13","date":"2016-05-01","exercise":"Character Custodian of Destiny","type":"Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"13","aggregate":"0","tableName":"kolawolesaintmarkscores","currentTotalAggregate":"0"},{"id":"14","date":"2016-05-08","exercise":"The Myth of Singleness","type":"Questions","source":"Dr Myles Munroe","score":"0","currentage":"13","aggregate":"0","tableName":"kolawolesaintmarkscores","currentTotalAggregate":"0"},{"id":"15","date":"2016-05-15","exercise":"Being Still (Psalms 46vs10)","type":"Chicken on Egg Scenario","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0","tableName":"kolawolesaintmarkscores","currentTotalAggregate":"0"},{"id":"16","date":"2016-05-22","exercise":"Selecting the Most Appropriate Word Replacement","type":"Quiz","source":"Lanre Ibironke","score":"0","currentage":"13","aggregate":"0","tableName":"kolawolesaintmarkscores","currentTotalAggregate":"0"},{"id":"17","date":"2016-05-29","exercise":"Personalizing Scripture","type":"Theory Question","source":"Lanre Ibironke","score":"0","currentage":"14","aggregate":"0","tableName":"kolawolesaintmarkscores","currentTotalAggregate":"0"},{"id":"18","date":"2016-06-05","exercise":"Inner Counsel","type":"Annotation","source":"Lanre Ibironke","score":"0","currentage":"14","aggregate":"0","tableName":"kolawolesaintmarkscores","currentTotalAggregate":"0"},{"id":"19","date":"2016-06-12","exercise":"Bible Questions","type":"General Quiz","source":"Lanre Ibironke","score":"0","currentage":"14","aggregate":"0","tableName":"kolawolesaintmarkscores","currentTotalAggregate":"0"},{"id":"20","date":"2016-06-19","exercise":"Marathon Question","type":"General Quiz 2","source":"Lanre Ibironke","score":"0","currentage":"14","aggregate":"0","tableName":"kolawolesaintmarkscores","currentTotalAggregate":"0"},{"id":"21","date":"2016-06-26","exercise":"Uzziah''s Story","type":"Annotation","source":"Lanre Ibironke","score":"0","currentage":"14","aggregate":"0","tableName":"kolawolesaintmarkscores","currentTotalAggregate":"0"},{"id":"22","date":"2016-07-03","exercise":"Multiple Choice","type":"General Quiz 3","source":"Lanre Ibironke","score":"0","currentage":"14","aggregate":"0","tableName":"kolawolesaintmarkscores","currentTotalAggregate":"0"},{"id":"23","date":"2016-07-10","exercise":"4-Cards","type":"Bible Game","source":"Lanre Ibironke","score":"0","currentage":"14","aggregate":"0","tableName":"kolawolesaintmarkscores","currentTotalAggregate":"0"},{"id":"24","date":"2016-07-24","exercise":"Memory Test","type":"Theory Questions","source":"Lanre Ibironke","score":"0","currentage":"14","aggregate":"0","tableName":"kolawolesaintmarkscores","currentTotalAggregate":"0"},{"id":"25","date":"2016-07-31","exercise":"Scripture Expansion","type":"Presentation","source":"Lanre Ibironke","score":"0","currentage":"14","aggregate":"0","tableName":"kolawolesaintmarkscores","currentTotalAggregate":"0"},{"id":"26","date":"2016-08-07","exercise":"Multiple Choice","type":"General Quiz 4","source":"Lanre Ibironke","score":"0","currentage":"14","aggregate":"0","tableName":"kolawolesaintmarkscores","currentTotalAggregate":"0"},{"id":"27","date":"2016-08-14","exercise":"Tower of Hanoi & Marriage","type":"Puzzle & Annotation","source":"Lanre Ibironke","score":"0","currentage":"14","aggregate":"0","tableName":"kolawolesaintmarkscores","currentTotalAggregate":"0"},{"id":"28","date":"2016-08-21","exercise":"The Innovative Demands of Leadership","type":"Quiz 5","source":"Myles Munroe","score":"0","currentage":"14","aggregate":"0","tableName":"kolawolesaintmarkscores","currentTotalAggregate":"0"},{"id":"29","date":"2016-08-28","exercise":"The Best Kept Secret","type":"Quiz 6 & Annotation","source":"Lanre Ibironke","score":"191","currentage":"14","aggregate":"13.643","tableName":"kolawolesaintmarkscores","currentTotalAggregate":"13.643"},{"id":"30","date":"2016-09-04","exercise":"Divine Secrets","type":"Annotation","source":"Lanre Ibironke","score":"40","currentage":"14","aggregate":"2.857","tableName":"kolawolesaintmarkscores","currentTotalAggregate":"16.5"},{"id":"31","date":"2016-09-05","exercise":"Repositioning for Exploits","type":"Online Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"14","aggregate":"0","tableName":"kolawolesaintmarkscores","currentTotalAggregate":"16.5"},{"id":"32","date":"2016-09-11","exercise":"Repositioning for Exploits","type":"Online Quiz","source":"Bishop David Oyedepo","score":"0","currentage":"14","aggregate":"0","tableName":"kolawolesaintmarkscores","currentTotalAggregate":"16.5"}]', '{"cTab":"Scripture","wQAnswered":"15","wQGotten":"15","wQMissed":"0","mQAnswered":"187","mQGotten":"160","mQMissed":"27","sTyped":"187","sWordsTyped":"Proverbs 13:15-Good understanding wins favor, but the way of the transgressor is hard [like the barren, dry soil or the impassable swamp.","sGotten":"170","sMissed":"17","tPoints":"1769","eAForToday":"126.289","totalAggregate":"1090.599","email":"ebunoluwaajiboye@gmail.com","age":"14"}');
INSERT INTO `profiles` VALUES(23, 'Hannah', 'Ojo', '19', 'ojohannah818@gmail.com', 'bd14b5b4665829ae1cc18dc74850c712c31adfb4', '1203.012', '2nd', '49', '3C3140', 'HO', 'krystal', 'hannahojoscores', '', '{"cTab":"Scripture","wQAnswered":"15","wQGotten":"15","wQMissed":"0","mQAnswered":"187","mQGotten":"159","mQMissed":"28","sTyped":"187","sWordsTyped":"Proverbs 13:15-Good understanding wins favor, but the way of the transgressor is hard [like the barren, dry soul or the impassable swamp].","sGotten":"124","sMissed":"63","tPoints":"1581","eAForToday":"83.197","totalAggregate":"1203.012","email":"ojohannah818@gmail.com","age":"19"}');
INSERT INTO `profiles` VALUES(24, 'Charles', 'Abiola', '11', 'charlesabiola@gmail.com', 'db4cc850e47bb406389d2aa8d6ecbf9c5577b39c', '143.933', '21st', '0', '004000', 'CA', 'chas7777', 'charlesabiolascores', '', '{"cTab":"Message","wQAnswered":"15","wQGotten":"14","wQMissed":"1","mQAnswered":"187","mQGotten":"102","mQMissed":"85","sTyped":"1","sWordsTyped":"My son, keep my words;  lay up within you my commandments (for use when needed) and treasure them.","sGotten":"0","sMissed":"1","tPoints":"667","eAForToday":"60.697","totalAggregate":"143.933","email":"charlesabiola@gmail.com","age":"11"}');
INSERT INTO `profiles` VALUES(25, 'Oluwanifemi', 'Fawale', '11', 'oluwanifemifawale@gmail.com', '5f1cf5af2ac6807754b1825d0250ee8be60ed712', '147.3', '20th', '0', 'ff0080', 'OF', 'pink_femi838', 'oluwanifemifawalescores', '', '');
INSERT INTO `profiles` VALUES(26, 'Bolu', 'Ayodele', '12', 'boluayodele@gmail.com', 'c83f1de735de8aac5000a7773b24bfb03674df08', '75.842', '22nd', '0', '400040', 'BA', 'chris', 'boluayodelescores', '', '{"cTab":"Message","wQAnswered":"15","wQGotten":"12","wQMissed":"3","mQAnswered":"6","mQGotten":"5","mQMissed":"1","sTyped":"0","sWordsTyped":"","sGotten":"0","sMissed":"0","tPoints":"89","eAForToday":"7.421","totalAggregate":"75.842","email":"boluayodele@gmail.com","age":"12"}');
INSERT INTO `profiles` VALUES(27, 'Oluwaseyi', 'Alofe', '10', 'oluwaseyialofe13@gmail.com', '9125a5ca7d2d99dec906b5548dec123f66da5711', '40.62', '24th', '0', 'FF530C', 'OA', 'Lilshay', 'oluwaseyialofescores', '', '{"cTab":"Scripture","wQAnswered":"15","wQGotten":"15","wQMissed":"0","mQAnswered":"9","mQGotten":"6","mQMissed":"3","sTyped":"4","sWordsTyped":"Proverbs 7:4-Say to skillful and godly wisdom, You are my sister, and regard understanding or insight as your intimate friend-","sGotten":"1","sMissed":"3","tPoints":"116","eAForToday":"11.6","totalAggregate":"40.62","email":"oluwaseyialofe13@gmail.com","age":"10"}');

-- --------------------------------------------------------

--
-- Table structure for table `quizsettings`
--

CREATE TABLE `quizsettings` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `page` varchar(20) NOT NULL,
  `details` varchar(20) NOT NULL,
  `date` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `quizsettings`
--

INSERT INTO `quizsettings` VALUES(1, 'quiz', 'Materials', '2017-05-19 23:58:00');

-- --------------------------------------------------------

--
-- Table structure for table `scripturematerials`
--

CREATE TABLE `scripturematerials` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `book` varchar(50) NOT NULL,
  `chapter` int(3) NOT NULL,
  `verse` int(3) NOT NULL,
  `words` varchar(500) NOT NULL,
  `reference` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1701 ;

--
-- Dumping data for table `scripturematerials`
--

INSERT INTO `scripturematerials` VALUES(1514, 'Proverbs', 7, 1, 'Proverbs 7:1-My son, keep my words; lay up within you my commandments [for use when needed] and treasure them.', 'Proverbs 7:1');
INSERT INTO `scripturematerials` VALUES(1515, 'Proverbs', 7, 2, 'Proverbs 7:2-Keep my commandments and live, and keep my law and teaching as the apple (the pupil) of your eye.', 'Proverbs 7:2');
INSERT INTO `scripturematerials` VALUES(1516, 'Proverbs', 7, 3, 'Proverbs 7:3-Bind them on your fingers; write them on the tablet of your heart.', 'Proverbs 7:3');
INSERT INTO `scripturematerials` VALUES(1517, 'Proverbs', 7, 4, 'Proverbs 7:4-Say to skillful and godly Wisdom, You are my sister, and regard understanding or insight as your intimate friend-', 'Proverbs 7:4');
INSERT INTO `scripturematerials` VALUES(1518, 'Proverbs', 7, 5, 'Proverbs 7:5-That they may keep you from the loose woman, from the adventuress who flatters with and makes smooth her words.', 'Proverbs 7:5');
INSERT INTO `scripturematerials` VALUES(1519, 'Proverbs', 7, 6, 'Proverbs 7:6-For at the window of my house I looked out through my lattice.', 'Proverbs 7:6');
INSERT INTO `scripturematerials` VALUES(1520, 'Proverbs', 7, 7, 'Proverbs 7:7-And among the simple (empty-headed and empty hearted) ones, I perceived among the youths a young man void of good sense,', 'Proverbs 7:7');
INSERT INTO `scripturematerials` VALUES(1521, 'Proverbs', 7, 8, 'Proverbs 7:8-Sauntering through the street near the [loose woman''s] corner; and he went the way to her house', 'Proverbs 7:8');
INSERT INTO `scripturematerials` VALUES(1522, 'Proverbs', 7, 9, 'Proverbs 7:9-In the twilight, in the evening; night black and dense was falling [over the young man''s life].', 'Proverbs 7:9');
INSERT INTO `scripturematerials` VALUES(1523, 'Proverbs', 7, 10, 'Proverbs 7:10-And behold, there met him a woman, dressed as a harlot and sly and cunning of heart.', 'Proverbs 7:10');
INSERT INTO `scripturematerials` VALUES(1524, 'Proverbs', 7, 11, 'Proverbs 7:11-She is turbulent and willful; her feet stay not in her house;', 'Proverbs 7:11');
INSERT INTO `scripturematerials` VALUES(1525, 'Proverbs', 7, 12, 'Proverbs 7:12-Now in the streets, now in the market places, she sets her ambush at every corner.', 'Proverbs 7:12');
INSERT INTO `scripturematerials` VALUES(1526, 'Proverbs', 7, 13, 'Proverbs 7:13-So she caught him and kissed him and with impudent face she said to him,', 'Proverbs 7:13');
INSERT INTO `scripturematerials` VALUES(1527, 'Proverbs', 7, 14, 'Proverbs 7:14-Sacrifices of peace offerings were due from me; this day I paid my vows.', 'Proverbs 7:14');
INSERT INTO `scripturematerials` VALUES(1528, 'Proverbs', 7, 15, 'Proverbs 7:15-So I came forth to meet you [that you might share with me the feast from my offering]; diligently I sought your face, and I have found you.', 'Proverbs 7:15');
INSERT INTO `scripturematerials` VALUES(1529, 'Proverbs', 7, 16, 'Proverbs 7:16-I have spread my couch with rugs and cushions of tapestry, with striped sheets of fine linen of Egypt.', 'Proverbs 7:16');
INSERT INTO `scripturematerials` VALUES(1530, 'Proverbs', 7, 17, 'Proverbs 7:17-I have perfumed my bed with myrrh, aloes, and cinnamon.', 'Proverbs 7:17');
INSERT INTO `scripturematerials` VALUES(1531, 'Proverbs', 7, 18, 'Proverbs 7:18-Come, let us take our fill of love until morning; let us console and delight ourselves with love.', 'Proverbs 7:18');
INSERT INTO `scripturematerials` VALUES(1532, 'Proverbs', 7, 19, 'Proverbs 7:19-For the man is not at home; he is gone on a long journey;', 'Proverbs 7:19');
INSERT INTO `scripturematerials` VALUES(1533, 'Proverbs', 7, 20, 'Proverbs 7:20-He has taken a bag of money with him and will not come home at the day appointed [at the full moon].', 'Proverbs 7:20');
INSERT INTO `scripturematerials` VALUES(1534, 'Proverbs', 7, 21, 'Proverbs 7:21-With much justifying and enticing argument she persuades him, with the allurements of her lips she leads him [to overcome his conscience and his fears] and forces him along.', 'Proverbs 7:21');
INSERT INTO `scripturematerials` VALUES(1535, 'Proverbs', 7, 22, 'Proverbs 7:22-Suddenly he [yields and] follows her reluctantly like an ox moving to the slaughter, like one in fetters going to the correction [to be given] to a fool or like a dog enticed by food to the muzzle', 'Proverbs 7:22');
INSERT INTO `scripturematerials` VALUES(1536, 'Proverbs', 7, 23, 'Proverbs 7:23-Till a dart [of passion] pierces and inflames his vitals; then like a bird fluttering straight into the net [he hastens], not knowing that it will cost him his life.', 'Proverbs 7:23');
INSERT INTO `scripturematerials` VALUES(1537, 'Proverbs', 7, 24, 'Proverbs 7:24-Listen to me now therefore, O you sons, and be attentive to the words of my mouth.', 'Proverbs 7:24');
INSERT INTO `scripturematerials` VALUES(1538, 'Proverbs', 7, 25, 'Proverbs 7:25-Let not your heart incline toward her ways, do not stray into her paths.', 'Proverbs 7:25');
INSERT INTO `scripturematerials` VALUES(1539, 'Proverbs', 7, 26, 'Proverbs 7:26-For she has cast down many wounded; indeed, all her slain are a mighty host.', 'Proverbs 7:26');
INSERT INTO `scripturematerials` VALUES(1540, 'Proverbs', 7, 27, 'Proverbs 7:27-Her house is the way to Sheol (Hades, the place of the dead), going to the chambers of death.', 'Proverbs 7:27');
INSERT INTO `scripturematerials` VALUES(1541, 'Proverbs', 8, 1, 'Proverbs 8:1-Does not skillful and godly Wisdom cry out, and understanding raise her voice [in contrast to the loose woman]?', 'Proverbs 8:1');
INSERT INTO `scripturematerials` VALUES(1542, 'Proverbs', 8, 2, 'Proverbs 8:2-On the top of the heights beside the way, where the paths meet, stands Wisdom [skillful and godly];', 'Proverbs 8:2');
INSERT INTO `scripturematerials` VALUES(1543, 'Proverbs', 8, 3, 'Proverbs 8:3-At the gates at the entrance of the town, at the coming in at the doors, she cries out:', 'Proverbs 8:3');
INSERT INTO `scripturematerials` VALUES(1544, 'Proverbs', 8, 4, 'Proverbs 8:4-To you, O men, I call, and my voice is directed to the sons of men.', 'Proverbs 8:4');
INSERT INTO `scripturematerials` VALUES(1545, 'Proverbs', 8, 5, 'Proverbs 8:5-O you simple and thoughtless ones, understand prudence; you [self-confident] fools, be of an understanding heart.', 'Proverbs 8:5');
INSERT INTO `scripturematerials` VALUES(1546, 'Proverbs', 8, 6, 'Proverbs 8:6-Hear, for I will speak excellent and princely things; and the opening of my lips shall be for right things.', 'Proverbs 8:6');
INSERT INTO `scripturematerials` VALUES(1547, 'Proverbs', 8, 7, 'Proverbs 8:7-For my mouth shall utter truth, and wrongdoing is detestable and loathsome to my lips.', 'Proverbs 8:7');
INSERT INTO `scripturematerials` VALUES(1548, 'Proverbs', 8, 8, 'Proverbs 8:8-All the words of my mouth are righteous (upright and in right standing with God); there is nothing contrary to truth or crooked in them.', 'Proverbs 8:8');
INSERT INTO `scripturematerials` VALUES(1549, 'Proverbs', 8, 9, 'Proverbs 8:9-They are all plain to him who understands [and opens his heart], and right to those who find knowledge [and live by it].', 'Proverbs 8:9');
INSERT INTO `scripturematerials` VALUES(1550, 'Proverbs', 8, 10, 'Proverbs 8:10-Receive my instruction in preference to [striving for] silver, and knowledge rather than choice gold.', 'Proverbs 8:10');
INSERT INTO `scripturematerials` VALUES(1551, 'Proverbs', 8, 11, 'Proverbs 8:11-For skillful and godly Wisdom is better than rubies or pearls, and all the things that may be desired are not to be compared to it.', 'Proverbs 8:11');
INSERT INTO `scripturematerials` VALUES(1552, 'Proverbs', 8, 12, 'Proverbs 8:12-I, Wisdom [from God], make prudence my dwelling, and I find out knowledge and discretion.', 'Proverbs 8:12');
INSERT INTO `scripturematerials` VALUES(1553, 'Proverbs', 8, 13, 'Proverbs 8:13-The reverent fear and worshipful awe of the Lord [includes] the hatred of evil; pride, arrogance, the evil way, and perverted and twisted speech I hate.', 'Proverbs 8:13');
INSERT INTO `scripturematerials` VALUES(1554, 'Proverbs', 8, 14, 'Proverbs 8:14-I have counsel and sound knowledge, I have understanding, I have might and power.', 'Proverbs 8:14');
INSERT INTO `scripturematerials` VALUES(1555, 'Proverbs', 8, 15, 'Proverbs 8:15-By me kings reign and rulers decree justice.', 'Proverbs 8:15');
INSERT INTO `scripturematerials` VALUES(1556, 'Proverbs', 8, 16, 'Proverbs 8:16-By me princes rule, and nobles, even all the judges and governors of the earth.', 'Proverbs 8:16');
INSERT INTO `scripturematerials` VALUES(1557, 'Proverbs', 8, 17, 'Proverbs 8:17-I love those who love me, and those who seek me early and diligently shall find me.', 'Proverbs 8:17');
INSERT INTO `scripturematerials` VALUES(1558, 'Proverbs', 8, 18, 'Proverbs 8:18-Riches and honor are with me, enduring wealth and righteousness (uprightness in every area and relation, and right standing with God).', 'Proverbs 8:18');
INSERT INTO `scripturematerials` VALUES(1559, 'Proverbs', 8, 19, 'Proverbs 8:19-My fruit is better than gold, yes, than refined gold, and my increase than choice silver.', 'Proverbs 8:19');
INSERT INTO `scripturematerials` VALUES(1560, 'Proverbs', 8, 20, 'Proverbs 8:20-I [Wisdom] walk in the way of righteousness (moral and spiritual rectitude in every area and relation), in the midst of the paths of justice,', 'Proverbs 8:20');
INSERT INTO `scripturematerials` VALUES(1561, 'Proverbs', 8, 21, 'Proverbs 8:21-That I may cause those who love me to inherit [true] riches and that I may fill their treasuries.', 'Proverbs 8:21');
INSERT INTO `scripturematerials` VALUES(1562, 'Proverbs', 8, 22, 'Proverbs 8:22-The Lord formed and brought me [Wisdom] forth at the beginning of His way, before His acts of old.', 'Proverbs 8:22');
INSERT INTO `scripturematerials` VALUES(1563, 'Proverbs', 8, 23, 'Proverbs 8:23-I [Wisdom] was inaugurated and ordained from everlasting, from the beginning before ever the earth existed.', 'Proverbs 8:23');
INSERT INTO `scripturematerials` VALUES(1564, 'Proverbs', 8, 24, 'Proverbs 8:24-When there were no deeps, I was brought forth, when there were no fountains laden with water.', 'Proverbs 8:24');
INSERT INTO `scripturematerials` VALUES(1565, 'Proverbs', 8, 25, 'Proverbs 8:25-Before the mountains were settled, before the hills, I was brought forth,', 'Proverbs 8:25');
INSERT INTO `scripturematerials` VALUES(1566, 'Proverbs', 8, 26, 'Proverbs 8:26-While as yet He had not made the land or the fields or the first of the dust of the earth.', 'Proverbs 8:26');
INSERT INTO `scripturematerials` VALUES(1567, 'Proverbs', 8, 27, 'Proverbs 8:27-When He prepared the heavens, I [Wisdom] was there; when He drew a circle upon the face of the deep and stretched out the firmament over it,', 'Proverbs 8:27');
INSERT INTO `scripturematerials` VALUES(1568, 'Proverbs', 8, 28, 'Proverbs 8:28-When He made firm the skies above, when He established the fountains of the deep,', 'Proverbs 8:28');
INSERT INTO `scripturematerials` VALUES(1569, 'Proverbs', 8, 29, 'Proverbs 8:29-When He gave to the sea its limit and His decree that the waters should not transgress [across the boundaries set by] His command, when He appointed the foundations of the earth-', 'Proverbs 8:29');
INSERT INTO `scripturematerials` VALUES(1570, 'Proverbs', 8, 30, 'Proverbs 8:30-Then I [Wisdom] was beside Him as a master and director of the work; and I was daily His delight, rejoicing before Him always,', 'Proverbs 8:30');
INSERT INTO `scripturematerials` VALUES(1571, 'Proverbs', 8, 31, 'Proverbs 8:31-Rejoicing in His inhabited earth and delighting in the sons of men.', 'Proverbs 8:31');
INSERT INTO `scripturematerials` VALUES(1572, 'Proverbs', 8, 32, 'Proverbs 8:32-Now therefore listen to me, O you sons; for blessed (happy, fortunate, to be envied) are those who keep my ways.', 'Proverbs 8:32');
INSERT INTO `scripturematerials` VALUES(1573, 'Proverbs', 8, 33, 'Proverbs 8:33-Hear instruction and be wise, and do not refuse or neglect it.', 'Proverbs 8:33');
INSERT INTO `scripturematerials` VALUES(1574, 'Proverbs', 8, 34, 'Proverbs 8:34-Blessed (happy, fortunate, to be envied) is the man who listens to me, watching daily at my gates, waiting at the posts of my doors.', 'Proverbs 8:34');
INSERT INTO `scripturematerials` VALUES(1575, 'Proverbs', 8, 35, 'Proverbs 8:35-For whoever finds me [Wisdom] finds life and draws forth and obtains favor from the Lord.', 'Proverbs 8:35');
INSERT INTO `scripturematerials` VALUES(1576, 'Proverbs', 8, 36, 'Proverbs 8:36-But he who misses me or sins against me wrongs and injures himself; all who hate me love and court death.', 'Proverbs 8:36');
INSERT INTO `scripturematerials` VALUES(1577, 'Proverbs', 9, 1, 'Proverbs 9:1-Wisdom has built her house; she has hewn out and set up her seven [perfect number of] pillars.', 'Proverbs 9:1');
INSERT INTO `scripturematerials` VALUES(1578, 'Proverbs', 9, 2, 'Proverbs 9:2-She has killed her beasts, she has mixed her [spiritual] wine; she has also set her table.', 'Proverbs 9:2');
INSERT INTO `scripturematerials` VALUES(1579, 'Proverbs', 9, 3, 'Proverbs 9:3-She has sent out her maids to cry from the highest places of the town:', 'Proverbs 9:3');
INSERT INTO `scripturematerials` VALUES(1580, 'Proverbs', 9, 4, 'Proverbs 9:4-Whoever is simple (easily led astray and wavering), let him turn in here! As for him who lacks understanding, [God''s] Wisdom says to him,', 'Proverbs 9:4');
INSERT INTO `scripturematerials` VALUES(1581, 'Proverbs', 9, 5, 'Proverbs 9:5-Come, eat of my bread and drink of the [spiritual] wine which I have mixed.', 'Proverbs 9:5');
INSERT INTO `scripturematerials` VALUES(1582, 'Proverbs', 9, 6, 'Proverbs 9:6-Leave off, simple ones [forsake the foolish and simpleminded] and live! And walk in the way of insight and understanding.', 'Proverbs 9:6');
INSERT INTO `scripturematerials` VALUES(1583, 'Proverbs', 9, 7, 'Proverbs 9:7-He who rebukes a scorner heaps upon himself abuse, and he who reproves a wicked man gets for himself bruises.', 'Proverbs 9:7');
INSERT INTO `scripturematerials` VALUES(1584, 'Proverbs', 9, 8, 'Proverbs 9:8-Reprove not a scorner, lest he hate you; reprove a wise man, and he will love you.', 'Proverbs 9:8');
INSERT INTO `scripturematerials` VALUES(1585, 'Proverbs', 9, 9, 'Proverbs 9:9-Give instruction to a wise man and he will be yet wiser; teach a righteous man (one upright and in right standing with God) and he will increase in learning.', 'Proverbs 9:9');
INSERT INTO `scripturematerials` VALUES(1586, 'Proverbs', 9, 10, 'Proverbs 9:10-The reverent and worshipful fear of the Lord is the beginning (the chief and choice part) of Wisdom, and the knowledge of the Holy One is insight and understanding.', 'Proverbs 9:10');
INSERT INTO `scripturematerials` VALUES(1587, 'Proverbs', 9, 11, 'Proverbs 9:11-For by me [Wisdom from God] your days shall be multiplied, and the years of your life shall be increased.', 'Proverbs 9:11');
INSERT INTO `scripturematerials` VALUES(1588, 'Proverbs', 9, 12, 'Proverbs 9:12-If you are wise, you are wise for yourself; if you scorn, you alone will bear it and pay the penalty.', 'Proverbs 9:12');
INSERT INTO `scripturematerials` VALUES(1589, 'Proverbs', 9, 13, 'Proverbs 9:13-The foolish woman is noisy; she is simple and open to all forms of evil, she [willfully and recklessly] knows nothing whatever [of eternal value].', 'Proverbs 9:13');
INSERT INTO `scripturematerials` VALUES(1590, 'Proverbs', 9, 14, 'Proverbs 9:14-For she sits at the door of her house or on a seat in the conspicuous (noticeable) places of the town,', 'Proverbs 9:14');
INSERT INTO `scripturematerials` VALUES(1591, 'Proverbs', 9, 15, 'Proverbs 9:15-Calling to those who pass by, who go uprightly on their way:', 'Proverbs 9:15');
INSERT INTO `scripturematerials` VALUES(1592, 'Proverbs', 9, 16, 'Proverbs 9:16-Whoever is simple (wavering and easily led astray), let him turn in here! And as for him who lacks understanding, she says to him,', 'Proverbs 9:16');
INSERT INTO `scripturematerials` VALUES(1593, 'Proverbs', 9, 17, 'Proverbs 9:17-Stolen waters (pleasures) are sweet [because they are forbidden]; and bread eaten in secret is pleasant.', 'Proverbs 9:17');
INSERT INTO `scripturematerials` VALUES(1594, 'Proverbs', 9, 18, 'Proverbs 9:18-But he knows not that the shades of the dead are there [specters haunting the scene of past transgressions], and that her invited guests are [already sunk] in the depths of Sheol (the lower world, Hades, the place of the dead).', 'Proverbs 9:18');
INSERT INTO `scripturematerials` VALUES(1595, 'Proverbs', 10, 1, 'Proverbs 10:1-The proverbs of Solomon: A wise son makes a glad father, but a foolish and self-confident son is a grief to his mother.', 'Proverbs 10:1');
INSERT INTO `scripturematerials` VALUES(1596, 'Proverbs', 10, 2, 'Proverbs 10:2-Treasures of wickedness profit for nothing, but righteousness (moral and spiritual rectitude in every area and relation) delivers from death.', 'Proverbs 10:2');
INSERT INTO `scripturematerials` VALUES(1597, 'Proverbs', 10, 3, 'Proverbs 10:3-The Lord will not allow the [uncompromisingly] righteous to famish, but He thwarts the desire of the wicked.', 'Proverbs 10:3');
INSERT INTO `scripturematerials` VALUES(1598, 'Proverbs', 10, 4, 'Proverbs 10:4-He becomes poor who works with a slack and idle hand, but the hand of the diligent makes rich.', 'Proverbs 10:4');
INSERT INTO `scripturematerials` VALUES(1599, 'Proverbs', 10, 5, 'Proverbs 10:5-He who gathers in summer is a wise son, but he who sleeps in harvest is a son who causes shame.', 'Proverbs 10:5');
INSERT INTO `scripturematerials` VALUES(1600, 'Proverbs', 10, 6, 'Proverbs 10:6-Blessings are upon the head of the [uncompromisingly] righteous (the upright, in right standing with God) but the mouth of the wicked conceals violence.', 'Proverbs 10:6');
INSERT INTO `scripturematerials` VALUES(1601, 'Proverbs', 10, 7, 'Proverbs 10:7-The memory of the [uncompromisingly] righteous is a blessing, but the name of the wicked shall rot.', 'Proverbs 10:7');
INSERT INTO `scripturematerials` VALUES(1602, 'Proverbs', 10, 8, 'Proverbs 10:8-The wise in heart will accept and obey commandments, but the foolish lips will fall headlong.', 'Proverbs 10:8');
INSERT INTO `scripturematerials` VALUES(1603, 'Proverbs', 10, 9, 'Proverbs 10:9-He who walks uprightly walks securely, but he who takes a crooked way shall be found out and punished.', 'Proverbs 10:9');
INSERT INTO `scripturematerials` VALUES(1604, 'Proverbs', 10, 10, 'Proverbs 10:10-He who winks with the eye [craftily and with malice] causes sorrow; the foolish of lips will fall headlong but he who boldly reproves makes peace.', 'Proverbs 10:10');
INSERT INTO `scripturematerials` VALUES(1605, 'Proverbs', 10, 11, 'Proverbs 10:11-The mouth of the [uncompromisingly] righteous man is a well of life, but the mouth of the wicked conceals violence.', 'Proverbs 10:11');
INSERT INTO `scripturematerials` VALUES(1606, 'Proverbs', 10, 12, 'Proverbs 10:12-Hatred stirs up contentions, but love covers all transgressions.', 'Proverbs 10:12');
INSERT INTO `scripturematerials` VALUES(1607, 'Proverbs', 10, 13, 'Proverbs 10:13-On the lips of him who has discernment skillful and godly Wisdom is found, but discipline and the rod are for the back of him who is without sense and understanding.', 'Proverbs 10:13');
INSERT INTO `scripturematerials` VALUES(1608, 'Proverbs', 10, 14, 'Proverbs 10:14-Wise men store up knowledge [in mind and heart], but the mouth of the foolish is a present destruction.', 'Proverbs 10:14');
INSERT INTO `scripturematerials` VALUES(1609, 'Proverbs', 10, 15, 'Proverbs 10:15-The rich man''s wealth is his strong city; the poverty of the poor is their ruin.', 'Proverbs 10:15');
INSERT INTO `scripturematerials` VALUES(1610, 'Proverbs', 10, 16, 'Proverbs 10:16-The earnings of the righteous (the upright, in right standing with God) lead to life, but the profit of the wicked leads to further sin.', 'Proverbs 10:16');
INSERT INTO `scripturematerials` VALUES(1611, 'Proverbs', 10, 17, 'Proverbs 10:17-He who heeds instruction and correction is [not only himself] in the way of life [but also] is a way of life for others. And he who neglects or refuses reproof [not only himself] goes astray [but also] causes to err and is a path toward ruin for others.', 'Proverbs 10:17');
INSERT INTO `scripturematerials` VALUES(1612, 'Proverbs', 10, 18, 'Proverbs 10:18-He who hides hatred is of lying lips, and he who utters slander is a [self-confident] fool.', 'Proverbs 10:18');
INSERT INTO `scripturematerials` VALUES(1613, 'Proverbs', 10, 19, 'Proverbs 10:19-In a multitude of words transgression is not lacking, but he who restrains his lips is prudent.', 'Proverbs 10:19');
INSERT INTO `scripturematerials` VALUES(1614, 'Proverbs', 10, 20, 'Proverbs 10:20-The tongues of those who are upright and in right standing with God are as choice silver; the minds of those who are wicked and out of harmony with God are of little value.', 'Proverbs 10:20');
INSERT INTO `scripturematerials` VALUES(1615, 'Proverbs', 10, 21, 'Proverbs 10:21-The lips of the [uncompromisingly] righteous feed and guide many, but fools die for want of Wisdom.', 'Proverbs 10:21');
INSERT INTO `scripturematerials` VALUES(1616, 'Proverbs', 10, 22, 'Proverbs 10:22-The blessing of the Lord-it makes [truly] rich, and He adds no sorrow with it [neither does toiling increase it].', 'Proverbs 10:22');
INSERT INTO `scripturematerials` VALUES(1617, 'Proverbs', 10, 23, 'Proverbs 10:23-It is as sport to a [self-confident] fool to do wickedness, but to have skillful and godly Wisdom is pleasure and relaxation to a man of Understanding.', 'Proverbs 10:23');
INSERT INTO `scripturematerials` VALUES(1618, 'Proverbs', 10, 24, 'Proverbs 10:24-The thing a wicked man fears shall come upon him, but the desire of the [uncompromisingly] righteous shall be granted.', 'Proverbs 10:24');
INSERT INTO `scripturematerials` VALUES(1619, 'Proverbs', 10, 25, 'Proverbs 10:25-When the whirlwind passes, the wicked are no more, but the [uncompromisingly] righteous have an everlasting foundation.', 'Proverbs 10:25');
INSERT INTO `scripturematerials` VALUES(1620, 'Proverbs', 10, 26, 'Proverbs 10:26-As vinegar to the teeth and as smoke to the eyes, so is the sluggard to those who employ and send him.', 'Proverbs 10:26');
INSERT INTO `scripturematerials` VALUES(1621, 'Proverbs', 10, 27, 'Proverbs 10:27-The reverent and worshipful fear of the Lord prolongs one''s days, but the years of the wicked shall be made short.', 'Proverbs 10:27');
INSERT INTO `scripturematerials` VALUES(1622, 'Proverbs', 10, 28, 'Proverbs 10:28-The hope of the [uncompromisingly] righteous (the upright, in right standing with God) is gladness, but the expectation of the wicked (those who are out of harmony with God) comes to nothing.', 'Proverbs 10:28');
INSERT INTO `scripturematerials` VALUES(1623, 'Proverbs', 10, 29, 'Proverbs 10:29-The way of the Lord is strength and a stronghold to the upright, but it is destruction to the workers of iniquity.', 'Proverbs 10:29');
INSERT INTO `scripturematerials` VALUES(1624, 'Proverbs', 10, 30, 'Proverbs 10:30-The [consistently] righteous shall never be removed, but the wicked shall not inhabit the earth.', 'Proverbs 10:30');
INSERT INTO `scripturematerials` VALUES(1625, 'Proverbs', 10, 31, 'Proverbs 10:31-The mouths of the righteous (those harmonious with God) bring forth skillful and godly Wisdom, but the perverse tongue shall be cut down [like a barren and rotten tree].', 'Proverbs 10:31');
INSERT INTO `scripturematerials` VALUES(1626, 'Proverbs', 10, 32, 'Proverbs 10:32-The lips of the [uncompromisingly] righteous know [and therefore utter] what is acceptable, but the mouth of the wicked knows [and therefore speaks only] what is obstinately willful and contrary.', 'Proverbs 10:32');
INSERT INTO `scripturematerials` VALUES(1627, 'Proverbs', 11, 1, 'Proverbs 11:1-A false balance and unrighteous dealings are extremely offensive and shamefully sinful to the Lord, but a just weight is His delight.', 'Proverbs 11:1');
INSERT INTO `scripturematerials` VALUES(1628, 'Proverbs', 11, 2, 'Proverbs 11:2-When swelling and pride come, then emptiness and shame come also, but with the humble (those who are lowly, who have been pruned or chiseled by God''s Word, and renounce self) are skillful and godly Wisdom and soundness.', 'Proverbs 11:2');
INSERT INTO `scripturematerials` VALUES(1629, 'Proverbs', 11, 3, 'Proverbs 11:3-The integrity of the upright shall guide them, but the willful contrariness and crookedness of the treacherous shall destroy them.', 'Proverbs 11:3');
INSERT INTO `scripturematerials` VALUES(1630, 'Proverbs', 11, 4, 'Proverbs 11:4-Riches provide no security in the day of wrath and judgment, but righteousness (uprightness and right standing with God) delivers from death.', 'Proverbs 11:4');
INSERT INTO `scripturematerials` VALUES(1631, 'Proverbs', 11, 5, 'Proverbs 11:5-The righteousness of the blameless shall rectify and make plain their way and keep it straight, but the wicked shall fall by their own wickedness.', 'Proverbs 11:5');
INSERT INTO `scripturematerials` VALUES(1632, 'Proverbs', 11, 6, 'Proverbs 11:6-The righteousness of the upright [their rectitude in every area and relation] shall deliver them, but the treacherous shall be taken in their own iniquity and greedy desire.', 'Proverbs 11:6');
INSERT INTO `scripturematerials` VALUES(1633, 'Proverbs', 11, 7, 'Proverbs 11:7-When the wicked man dies, his hope [for the future] perishes; and the expectation of the godless comes to nothing.', 'Proverbs 11:7');
INSERT INTO `scripturematerials` VALUES(1634, 'Proverbs', 11, 8, 'Proverbs 11:8-The [uncompromisingly] righteous is delivered out of trouble, and the wicked gets into it instead.', 'Proverbs 11:8');
INSERT INTO `scripturematerials` VALUES(1635, 'Proverbs', 11, 9, 'Proverbs 11:9-With his mouth the godless man destroys his neighbor, but through knowledge and superior discernment shall the righteous be delivered.', 'Proverbs 11:9');
INSERT INTO `scripturematerials` VALUES(1636, 'Proverbs', 11, 10, 'Proverbs 11:10-When it goes well with the [uncompromisingly] righteous, the city rejoices, but when the wicked perish, there are shouts of joy.', 'Proverbs 11:10');
INSERT INTO `scripturematerials` VALUES(1637, 'Proverbs', 11, 11, 'Proverbs 11:11-By the blessing of the influence of the upright and God''s favor [because of them] the city is exalted, but it is overthrown by the mouth of the wicked.', 'Proverbs 11:11');
INSERT INTO `scripturematerials` VALUES(1638, 'Proverbs', 11, 12, 'Proverbs 11:12-He who belittles and despises his neighbor lacks sense, but a man of understanding keeps silent.', 'Proverbs 11:12');
INSERT INTO `scripturematerials` VALUES(1639, 'Proverbs', 11, 13, 'Proverbs 11:13-He who goes about as a talebearer reveals secrets, but he who is trustworthy and faithful in spirit keeps the matter hidden.', 'Proverbs 11:13');
INSERT INTO `scripturematerials` VALUES(1640, 'Proverbs', 11, 14, 'Proverbs 11:14-Where no wise guidance is, the people fall, but in the multitude of counselors there is safety.', 'Proverbs 11:14');
INSERT INTO `scripturematerials` VALUES(1641, 'Proverbs', 11, 15, 'Proverbs 11:15-He who becomes security for an outsider shall smart for it, but he who hates suretyship is secure [from its penalties].', 'Proverbs 11:15');
INSERT INTO `scripturematerials` VALUES(1642, 'Proverbs', 11, 16, 'Proverbs 11:16-A gracious and good woman wins honor [for her husband], and strong men win riches but a woman who hates righteousness is a throne of dishonor for him.', 'Proverbs 11:16');
INSERT INTO `scripturematerials` VALUES(1643, 'Proverbs', 11, 17, 'Proverbs 11:17-The merciful, kind, and generous man benefits himself [for his deeds return to bless him], but he who is cruel and callous [to the wants of others] brings on himself retribution.', 'Proverbs 11:17');
INSERT INTO `scripturematerials` VALUES(1644, 'Proverbs', 11, 18, 'Proverbs 11:18-The wicked man earns deceitful wages, but he who sows righteousness (moral and spiritual rectitude in every area and relation) shall have a sure reward [permanent and satisfying].', 'Proverbs 11:18');
INSERT INTO `scripturematerials` VALUES(1645, 'Proverbs', 11, 19, 'Proverbs 11:19-He who is steadfast in righteousness (uprightness and right standing with God) attains to life, but he who pursues evil does it to his own death.', 'Proverbs 11:19');
INSERT INTO `scripturematerials` VALUES(1646, 'Proverbs', 11, 20, 'Proverbs 11:20-They who are willfully contrary in heart are extremely disgusting and shamefully vile in the eyes of the Lord, but such as are blameless and wholehearted in their ways are His delight!', 'Proverbs 11:20');
INSERT INTO `scripturematerials` VALUES(1647, 'Proverbs', 11, 21, 'Proverbs 11:21-Assured [I pledge it] the wicked shall not go unpunished, but the multitude of the [uncompromisingly] righteous shall be delivered.', 'Proverbs 11:21');
INSERT INTO `scripturematerials` VALUES(1648, 'Proverbs', 11, 22, 'Proverbs 11:22-As a ring of gold in a swine''s snout, so is a fair woman who is without discretion.', 'Proverbs 11:22');
INSERT INTO `scripturematerials` VALUES(1649, 'Proverbs', 11, 23, 'Proverbs 11:23-The desire of the [consistently] righteous brings only good, but the expectation of the wicked brings wrath.', 'Proverbs 11:23');
INSERT INTO `scripturematerials` VALUES(1650, 'Proverbs', 11, 24, 'Proverbs 11:24-There are those who [generously] scatter abroad, and yet increase more; there are those who withhold more than is fitting or what is justly due, but it results only in want.', 'Proverbs 11:24');
INSERT INTO `scripturematerials` VALUES(1651, 'Proverbs', 11, 25, 'Proverbs 11:25-The liberal person shall be enriched, and he who waters shall himself be watered.', 'Proverbs 11:25');
INSERT INTO `scripturematerials` VALUES(1652, 'Proverbs', 11, 26, 'Proverbs 11:26-The people curse him who holds back grain [when the public needs it], but a blessing [from God and man] is upon the head of him who sells it.', 'Proverbs 11:26');
INSERT INTO `scripturematerials` VALUES(1653, 'Proverbs', 11, 27, 'Proverbs 11:27-He who diligently seeks good seeks [God''s] favor, but he who searches after evil, it shall come upon him.', 'Proverbs 11:27');
INSERT INTO `scripturematerials` VALUES(1654, 'Proverbs', 11, 28, 'Proverbs 11:28-He who leans on, trusts in, and is confident in his riches shall fall, but the [uncompromisingly] righteous shall flourish like the green bough.', 'Proverbs 11:28');
INSERT INTO `scripturematerials` VALUES(1655, 'Proverbs', 11, 29, 'Proverbs 11:29-He who troubles his own house shall inherit the wind, and the foolish shall be servant to the wise of heart.', 'Proverbs 11:29');
INSERT INTO `scripturematerials` VALUES(1656, 'Proverbs', 11, 30, 'Proverbs 11:30-The fruit of the [uncompromisingly] righteous is a tree of life, and he who is wise captures human lives [for God, as a fisher of men-he gathers and receives them for eternity].', 'Proverbs 11:30');
INSERT INTO `scripturematerials` VALUES(1657, 'Proverbs', 11, 31, 'Proverbs 11:31-Behold, the [uncompromisingly] righteous shall be recompensed on earth; how much more the wicked and the sinner! And if the righteous are barely saved, what will become of the ungodly and wicked?', 'Proverbs 11:31');
INSERT INTO `scripturematerials` VALUES(1658, 'Proverbs', 12, 1, 'Proverbs 12:1-Whoever loves instruction and correction loves knowledge, but he who hates reproof is like a brute beast, stupid and indiscriminating.', 'Proverbs 12:1');
INSERT INTO `scripturematerials` VALUES(1659, 'Proverbs', 12, 2, 'Proverbs 12:2-A good man obtains favor from the Lord, but a man of wicked devices He condemns.', 'Proverbs 12:2');
INSERT INTO `scripturematerials` VALUES(1660, 'Proverbs', 12, 3, 'Proverbs 12:3-A man shall not be established by wickedness, but the root of the [uncompromisingly] righteous shall never be moved.', 'Proverbs 12:3');
INSERT INTO `scripturematerials` VALUES(1661, 'Proverbs', 12, 4, 'Proverbs 12:4-A virtuous and worthy wife [earnest and strong in character] is a crowning joy to her husband, but she who makes him ashamed is as rottenness in his bones.', 'Proverbs 12:4');
INSERT INTO `scripturematerials` VALUES(1662, 'Proverbs', 12, 5, 'Proverbs 12:5-The thoughts and purposes of the [consistently] righteous are honest and reliable, but the counsels and designs of the wicked are treacherous.', 'Proverbs 12:5');
INSERT INTO `scripturematerials` VALUES(1663, 'Proverbs', 12, 6, 'Proverbs 12:6-The words of the wicked lie in wait for blood, but the mouth of the upright shall deliver them and the innocent ones [thus endangered].', 'Proverbs 12:6');
INSERT INTO `scripturematerials` VALUES(1664, 'Proverbs', 12, 7, 'Proverbs 12:7-The wicked are overthrown and are not, but the house of the [uncompromisingly] righteous shall stand.', 'Proverbs 12:7');
INSERT INTO `scripturematerials` VALUES(1665, 'Proverbs', 12, 8, 'Proverbs 12:8-A man shall be commended according to his Wisdom [godly Wisdom, which is comprehensive insight into the ways and purposes of God], but he who is of a perverse heart shall be despised.', 'Proverbs 12:8');
INSERT INTO `scripturematerials` VALUES(1666, 'Proverbs', 12, 9, 'Proverbs 12:9-Better is he who is lightly esteemed but works for his own support than he who assumes honor for himself and lacks bread.', 'Proverbs 12:9');
INSERT INTO `scripturematerials` VALUES(1667, 'Proverbs', 12, 10, 'Proverbs 12:10-A [consistently] righteous man regards the life of his beast, but even the tender mercies of the wicked are cruel.', 'Proverbs 12:10');
INSERT INTO `scripturematerials` VALUES(1668, 'Proverbs', 12, 11, 'Proverbs 12:11-He who tills his land shall be satisfied with bread, but he who follows worthless pursuits is lacking in sense and is without understanding.', 'Proverbs 12:11');
INSERT INTO `scripturematerials` VALUES(1669, 'Proverbs', 12, 12, 'Proverbs 12:12-The wicked desire the booty of evil men, but the root of the [uncompromisingly] righteous yields [richer fruitage].', 'Proverbs 12:12');
INSERT INTO `scripturematerials` VALUES(1670, 'Proverbs', 12, 13, 'Proverbs 12:13-The wicked is [dangerously] snared by the transgression of his lips, but the [uncompromisingly] righteous shall come out of trouble.', 'Proverbs 12:13');
INSERT INTO `scripturematerials` VALUES(1671, 'Proverbs', 12, 14, 'Proverbs 12:14-From the fruit of his words a man shall be satisfied with good, and the work of a man''s hands shall come back to him [as a harvest].', 'Proverbs 12:14');
INSERT INTO `scripturematerials` VALUES(1672, 'Proverbs', 12, 15, 'Proverbs 12:15-The way of a fool is right in his own eyes, but he who listens to counsel is wise.', 'Proverbs 12:15');
INSERT INTO `scripturematerials` VALUES(1673, 'Proverbs', 12, 16, 'Proverbs 12:16-A fool''s wrath is quickly and openly known, but a prudent man ignores an insult.', 'Proverbs 12:16');
INSERT INTO `scripturematerials` VALUES(1674, 'Proverbs', 12, 17, 'Proverbs 12:17-He who breathes out truth shows forth righteousness (uprightness and right standing with God), but a false witness utters deceit.', 'Proverbs 12:17');
INSERT INTO `scripturematerials` VALUES(1675, 'Proverbs', 12, 18, 'Proverbs 12:18-There are those who speak rashly, like the piercing of a sword, but the tongue of the wise brings healing.', 'Proverbs 12:18');
INSERT INTO `scripturematerials` VALUES(1676, 'Proverbs', 12, 19, 'Proverbs 12:19-Truthful lips shall be established forever, but a lying tongue is [credited] but for a moment.', 'Proverbs 12:19');
INSERT INTO `scripturematerials` VALUES(1677, 'Proverbs', 12, 20, 'Proverbs 12:20-Deceit is in the hearts of those who devise evil, but for the counselors of peace there is joy.', 'Proverbs 12:20');
INSERT INTO `scripturematerials` VALUES(1678, 'Proverbs', 12, 21, 'Proverbs 12:21-No [actual] evil, misfortune, or calamity shall come upon the righteous, but the wicked shall be filled with evil, misfortune, and calamity.', 'Proverbs 12:21');
INSERT INTO `scripturematerials` VALUES(1679, 'Proverbs', 12, 22, 'Proverbs 12:22-Lying lips are extremely disgusting and hateful to the Lord, but they who deal faithfully are His delight.', 'Proverbs 12:22');
INSERT INTO `scripturematerials` VALUES(1680, 'Proverbs', 12, 23, 'Proverbs 12:23-A prudent man is reluctant to display his knowledge, but the heart of [self-confident] fools proclaims their folly.', 'Proverbs 12:23');
INSERT INTO `scripturematerials` VALUES(1681, 'Proverbs', 12, 24, 'Proverbs 12:24-The hand of the diligent will rule, but the slothful will be put to forced labor.', 'Proverbs 12:24');
INSERT INTO `scripturematerials` VALUES(1682, 'Proverbs', 12, 25, 'Proverbs 12:25-Anxiety in a man''s heart weighs it down, but an encouraging word makes it glad.', 'Proverbs 12:25');
INSERT INTO `scripturematerials` VALUES(1683, 'Proverbs', 12, 26, 'Proverbs 12:26-The [consistently] righteous man is a guide to his neighbor, but the way of the wicked causes others to go astray.', 'Proverbs 12:26');
INSERT INTO `scripturematerials` VALUES(1684, 'Proverbs', 12, 27, 'Proverbs 12:27-The slothful man does not catch his game or roast it once he kills it, but the diligent man gets precious possessions.', 'Proverbs 12:27');
INSERT INTO `scripturematerials` VALUES(1685, 'Proverbs', 12, 28, 'Proverbs 12:28-Life is in the way of righteousness (moral and spiritual rectitude in every area and relation), and in its pathway there is no death but immortality (perpetual, eternal life).', 'Proverbs 12:28');
INSERT INTO `scripturematerials` VALUES(1686, 'Proverbs', 13, 1, 'Proverbs 13:1-A wise son heeds [and is the fruit of] his father''s instruction and correction, but a scoffer listens not to rebuke.', 'Proverbs 13:1');
INSERT INTO `scripturematerials` VALUES(1687, 'Proverbs', 13, 2, 'Proverbs 13:2-A good man eats good from the fruit of his mouth, but the desire of the treacherous is for violence.', 'Proverbs 13:2');
INSERT INTO `scripturematerials` VALUES(1688, 'Proverbs', 13, 3, 'Proverbs 13:3-He who guards his mouth keeps his life, but he who opens wide his lips comes to ruin.', 'Proverbs 13:3');
INSERT INTO `scripturematerials` VALUES(1689, 'Proverbs', 13, 4, 'Proverbs 13:4-The appetite of the sluggard craves and gets nothing, but the appetite of the diligent is abundantly supplied.', 'Proverbs 13:4');
INSERT INTO `scripturematerials` VALUES(1690, 'Proverbs', 13, 5, 'Proverbs 13:5-A [consistently] righteous man hates lying and deceit, but a wicked man is loathsome [his very breath spreads pollution] and he comes [surely] to shame.', 'Proverbs 13:5');
INSERT INTO `scripturematerials` VALUES(1691, 'Proverbs', 13, 6, 'Proverbs 13:6-Righteousness (rightness and justice in every area and relation) guards him who is upright in the way, but wickedness plunges into sin and overthrows the sinner.', 'Proverbs 13:6');
INSERT INTO `scripturematerials` VALUES(1692, 'Proverbs', 13, 7, 'Proverbs 13:7-One man considers himself rich, yet has nothing [to keep permanently]; another man considers himself poor, yet has great [and indestructible] riches.', 'Proverbs 13:7');
INSERT INTO `scripturematerials` VALUES(1693, 'Proverbs', 13, 8, 'Proverbs 13:8-A rich man can buy his way out of threatened death by paying a ransom, but the poor man does not even have to listen to threats [from the envious].', 'Proverbs 13:8');
INSERT INTO `scripturematerials` VALUES(1694, 'Proverbs', 13, 9, 'Proverbs 13:9-The light of the [uncompromisingly] righteous [is within him-it grows brighter and] rejoices, but the lamp of the wicked [furnishes only a derived, temporary light and] shall be put out shortly.', 'Proverbs 13:9');
INSERT INTO `scripturematerials` VALUES(1695, 'Proverbs', 13, 10, 'Proverbs 13:10-Only by pride and insolence comes contention, but with the well-advised is skillful and godly Wisdom.', 'Proverbs 13:10');
INSERT INTO `scripturematerials` VALUES(1696, 'Proverbs', 13, 11, 'Proverbs 13:11-Wealth [not earned but] won in haste or unjustly or from the production of things for vain or detrimental use [such riches] will dwindle away, but he who gathers little by little will increase [his riches].', 'Proverbs 13:11');
INSERT INTO `scripturematerials` VALUES(1697, 'Proverbs', 13, 12, 'Proverbs 13:12-Hope deferred makes the heart sick, but when the desire is fulfilled, it is a tree of life.', 'Proverbs 13:12');
INSERT INTO `scripturematerials` VALUES(1698, 'Proverbs', 13, 13, 'Proverbs 13:13-Whoever despises the word and counsel [of God] brings destruction upon himself, but he who [reverently] fears and respects the commandment [of God] is rewarded.', 'Proverbs 13:13');
INSERT INTO `scripturematerials` VALUES(1699, 'Proverbs', 13, 14, 'Proverbs 13:14-The teaching of the wise is a fountain of life, that one may avoid the snares of death.', 'Proverbs 13:14');
INSERT INTO `scripturematerials` VALUES(1700, 'Proverbs', 13, 15, 'Proverbs 13:15-Good understanding wins favor, but the way of the transgressor is hard [like the barren, dry soil or the impassable swamp].', 'Proverbs 13:15');

-- --------------------------------------------------------

--
-- Table structure for table `sefunmiadewunmiscores`
--

CREATE TABLE `sefunmiadewunmiscores` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `exercise` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `source` varchar(200) NOT NULL,
  `score` mediumint(9) NOT NULL,
  `currentage` mediumint(9) NOT NULL,
  `aggregate` varchar(200) NOT NULL,
  `tableName` varchar(50) NOT NULL DEFAULT 'sefunmiadewunmiscores',
  `currentTotalAggregate` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=63 ;

--
-- Dumping data for table `sefunmiadewunmiscores`
--

INSERT INTO `sefunmiadewunmiscores` VALUES(1, '2016-01-03', 'Eternal Life', 'Review', 'Andrew Wommack', 0, 10, '0.000', 'sefunmiadewunmiscores', '0');
INSERT INTO `sefunmiadewunmiscores` VALUES(2, '2016-01-10', 'Close Encounter of the God Kind', 'Review', 'Jesse Duplantis', 3, 10, '0.300', 'sefunmiadewunmiscores', '0.3');
INSERT INTO `sefunmiadewunmiscores` VALUES(3, '2016-01-31', 'Growing Up Spiritually', 'Review', 'Kenneth E Hagin', 4, 10, '0.400', 'sefunmiadewunmiscores', '0.7');
INSERT INTO `sefunmiadewunmiscores` VALUES(4, '2016-02-07', 'The Cost of a Crown', 'Quiz', 'Bishop David Oyedepo', 13, 10, '1.300', 'sefunmiadewunmiscores', '2');
INSERT INTO `sefunmiadewunmiscores` VALUES(5, '2016-02-14', 'The Love Walk', 'Review', 'Kenneth E Hagin', 11, 10, '1.100', 'sefunmiadewunmiscores', '3.1');
INSERT INTO `sefunmiadewunmiscores` VALUES(6, '2016-02-21', 'Opted for Group Discussion', 'Group Discussion', 'Youths', 0, 10, '0.000', 'sefunmiadewunmiscores', '3.1');
INSERT INTO `sefunmiadewunmiscores` VALUES(7, '2016-03-13', 'Repositioning for Exploits', 'Review', 'Bishop David Oyedepo', 2, 10, '0.200', 'sefunmiadewunmiscores', '3.3');
INSERT INTO `sefunmiadewunmiscores` VALUES(8, '2016-03-27', '1John 4:4', 'Synonyms', 'Lanre Ibironke', 11, 10, '1.100', 'sefunmiadewunmiscores', '4.4');
INSERT INTO `sefunmiadewunmiscores` VALUES(9, '2016-04-03', 'Hand Sequence', 'Focus Test', 'Lanre Ibironke', 44, 11, '4.000', 'sefunmiadewunmiscores', '8.4');
INSERT INTO `sefunmiadewunmiscores` VALUES(10, '2016-04-10', 'Yesterday, Today and Tomorrow', 'Annotation and Silence Half Hour', 'Lanre Ibironke', 44, 11, '4.000', 'sefunmiadewunmiscores', '12.4');
INSERT INTO `sefunmiadewunmiscores` VALUES(11, '2016-04-17', 'Your Abilities', 'Annotation and Hand Sequence', 'Lanre Ibironke', 8, 11, '0.727', 'sefunmiadewunmiscores', '13.127');
INSERT INTO `sefunmiadewunmiscores` VALUES(12, '2016-04-24', 'Maximizing Your Most Valuable Asset', 'Home Work', 'Lanre Ibironke', 0, 11, '0.000', 'sefunmiadewunmiscores', '13.127');
INSERT INTO `sefunmiadewunmiscores` VALUES(13, '2016-05-01', 'Character Custodian of Destiny', 'Quiz', 'Bishop David Oyedepo', 27, 11, '2.455', 'sefunmiadewunmiscores', '15.582');
INSERT INTO `sefunmiadewunmiscores` VALUES(14, '2016-05-08', 'The Myth of Singleness', 'Questions', 'Dr Myles Munroe', 18, 11, '1.636', 'sefunmiadewunmiscores', '17.218');
INSERT INTO `sefunmiadewunmiscores` VALUES(15, '2016-05-15', 'Being Still (Psalms 46v10)', 'Chicken on Egg Scenario', 'Lanre Ibironke', 2, 11, '0.182', 'sefunmiadewunmiscores', '17.4');
INSERT INTO `sefunmiadewunmiscores` VALUES(16, '2016-05-22', 'Selecting the Most Appropriate Word Replacement', 'Quiz', 'Lanre Ibironke', 45, 11, '4.091', 'sefunmiadewunmiscores', '21.491');
INSERT INTO `sefunmiadewunmiscores` VALUES(20, '2016-05-29', 'Personalizing Scripture', 'Theory Question', 'Lanre Ibironke', 31, 11, '2.818', 'sefunmiadewunmiscores', '24.309');
INSERT INTO `sefunmiadewunmiscores` VALUES(21, '2016-06-05', 'Inner Counsel', 'Annotation', 'Lanre Ibironke', 65, 11, '5.909', 'sefunmiadewunmiscores', '30.218');
INSERT INTO `sefunmiadewunmiscores` VALUES(22, '2016-06-12', 'Bible Questions', 'General Quiz', 'Lanre Ibironke', 48, 11, '4.364', 'sefunmiadewunmiscores', '34.582');
INSERT INTO `sefunmiadewunmiscores` VALUES(23, '2016-06-19', 'Marathon Question', 'General Quiz 2', 'Lanre Ibironke', 137, 11, '12.455', 'sefunmiadewunmiscores', '47.037');
INSERT INTO `sefunmiadewunmiscores` VALUES(24, '2016-06-26', 'Uzziah''s Story', 'Annotation', 'Lanre Ibironke', 21, 11, '1.909', 'sefunmiadewunmiscores', '48.946');
INSERT INTO `sefunmiadewunmiscores` VALUES(25, '2016-07-03', 'Multiple Choice', 'General Quiz 3', 'Lanre Ibironke', 48, 11, '4.364', 'sefunmiadewunmiscores', '53.31');
INSERT INTO `sefunmiadewunmiscores` VALUES(26, '2016-07-10', '4-Cards', 'Bible Game', 'Lanre Ibironke', 39, 11, '3.545', 'sefunmiadewunmiscores', '56.855');
INSERT INTO `sefunmiadewunmiscores` VALUES(27, '2016-07-24', 'Memory Test', 'Theory Questions', 'Lanre Ibironke', 56, 11, '5.091', 'sefunmiadewunmiscores', '61.946');
INSERT INTO `sefunmiadewunmiscores` VALUES(28, '2016-07-31', 'Scripture Expansion', 'Presentation', 'Lanre Ibironke', 18, 11, '1.636', 'sefunmiadewunmiscores', '63.582');
INSERT INTO `sefunmiadewunmiscores` VALUES(29, '2016-08-07', 'Multiple Choice', 'General Quiz 4', 'Lanre Ibironke', 0, 11, '0', 'sefunmiadewunmiscores', '63.582');
INSERT INTO `sefunmiadewunmiscores` VALUES(30, '2016-08-14', 'Tower of Hanoi & Marriage', 'Puzzle  & Annotation', 'Lanre Ibironke', 0, 11, '0', 'sefunmiadewunmiscores', '63.582');
INSERT INTO `sefunmiadewunmiscores` VALUES(31, '2016-08-21', 'The Innovative Demands of Leadership', 'Quiz 5', 'Myles Munroe', 39, 11, '3.545', 'sefunmiadewunmiscores', '67.127');
INSERT INTO `sefunmiadewunmiscores` VALUES(32, '2016-08-28', 'The Best Kept Secret', 'Quiz 6 & Annotation', 'Lanre Ibironke', 14, 11, '1.273', 'sefunmiadewunmiscores', '68.4');
INSERT INTO `sefunmiadewunmiscores` VALUES(33, '2016-09-04', 'Divine Secrets', 'Annotation', 'Lanre Ibironke', 40, 11, '3.636', 'sefunmiadewunmiscores', '72.036');
INSERT INTO `sefunmiadewunmiscores` VALUES(34, '2016-09-11', 'Repositioning for Exploits', 'Online Quiz', 'Bishop David Oyedepo', 273, 11, '24.843', 'sefunmiadewunmiscores', '96.879');
INSERT INTO `sefunmiadewunmiscores` VALUES(35, '2016-09-18', 'Kingdom Keys to Successful Relationships', 'Online Quiz', 'Myles Munroe', 74, 11, '6.734', 'sefunmiadewunmiscores', '103.613');
INSERT INTO `sefunmiadewunmiscores` VALUES(36, '2016-09-25', 'Heralding the Emergence of World Changers', 'Online Quiz', 'Bishop David Oyedepo', 307, 11, '27.937', 'sefunmiadewunmiscores', '131.55');
INSERT INTO `sefunmiadewunmiscores` VALUES(37, '2016-10-02', 'The Encounter', 'Online Quiz', 'Pure Flix Entertainment', 116, 11, '10.556', 'sefunmiadewunmiscores', '142.106');
INSERT INTO `sefunmiadewunmiscores` VALUES(38, '2016-10-09', 'The Ten Attitudes for Leadership Development', 'Online Quiz', 'Myles Munroe & David Oyedepo', 417, 11, '37.947', 'sefunmiadewunmiscores', '180.053');
INSERT INTO `sefunmiadewunmiscores` VALUES(39, '2016-10-16', 'What is Faith?', 'Online Quiz', 'David Oyedepo', 157, 11, '14.287', 'sefunmiadewunmiscores', '194.34');
INSERT INTO `sefunmiadewunmiscores` VALUES(40, '2016-10-23', 'The Media Mandate of the Kingdom', 'Online Quiz', 'Myles Munroe', 509, 11, '46.319', 'sefunmiadewunmiscores', '240.659');
INSERT INTO `sefunmiadewunmiscores` VALUES(41, '2016-11-06', 'Vital Keys to Achieving Your Vision', 'Online Quiz', 'Myles Munroe', 453, 11, '41.223', 'sefunmiadewunmiscores', '281.882');
INSERT INTO `sefunmiadewunmiscores` VALUES(42, '2016-11-13', 'Engaging Violent Faith for Supernatural Turnaround', 'Online Quiz', 'Bishop David Oyedepo', 233, 11, '21.203', 'sefunmiadewunmiscores', '303.085');
INSERT INTO `sefunmiadewunmiscores` VALUES(43, '2016-11-20', 'The Source of the Leadership Spirit', 'Online Quiz', 'Myles Munroe', 1, 11, '0.091', 'sefunmiadewunmiscores', '303.176');
INSERT INTO `sefunmiadewunmiscores` VALUES(44, '2016-12-18', 'How to Deal With Grief 1', 'Online Quiz', 'Andrew Wommack', 376, 11, '34.216', 'sefunmiadewunmiscores', '337.392');
INSERT INTO `sefunmiadewunmiscores` VALUES(45, '2017-01-15', 'Life', 'Online Quiz', 'David Oyedepo', 42, 11, '3.822', 'sefunmiadewunmiscores', '341.214');
INSERT INTO `sefunmiadewunmiscores` VALUES(46, '2017-01-22', 'Eternal Life', 'Online Quiz', 'Andrew Wommack', 333, 11, '30.303', 'sefunmiadewunmiscores', '371.517');
INSERT INTO `sefunmiadewunmiscores` VALUES(47, '2017-01-29', 'The Holy Spirit', 'Online Quiz', 'Pastor Adeboye & Andrew Wommack', 174, 11, '15.834', 'sefunmiadewunmiscores', '387.351');
INSERT INTO `sefunmiadewunmiscores` VALUES(48, '2017-02-05', 'God''s Kind of Love To You', 'Online Quiz', 'Andrew Wommack', 348, 11, '31.668', 'sefunmiadewunmiscores', '419.019');
INSERT INTO `sefunmiadewunmiscores` VALUES(49, '2017-02-12', '7 Mistakes to avoid before marriage & End of the Harvest', 'Online Quiz', 'Pastor E.A. Adeboye & Christiano Film Group', 289, 11, '26.299', 'sefunmiadewunmiscores', '445.318');
INSERT INTO `sefunmiadewunmiscores` VALUES(50, '2017-02-19', 'Deepening your Relationship with God & 3 Types of Friends', 'Online Quiz', 'TD Jakes', 322, 11, '29.302', 'sefunmiadewunmiscores', '474.62');
INSERT INTO `sefunmiadewunmiscores` VALUES(51, '2017-02-26', 'Ultimate Myles Munroe 2016 Collection', 'Online Quiz', 'Myles Munroe', 403, 11, '36.673', 'sefunmiadewunmiscores', '511.293');
INSERT INTO `sefunmiadewunmiscores` VALUES(52, '2017-03-05', 'Spirituality the Master Key to a World of Exploits', 'Online Quiz', 'Bishop David Oyedepo', 423, 11, '38.493', 'sefunmiadewunmiscores', '549.786');
INSERT INTO `sefunmiadewunmiscores` VALUES(53, '2017-03-12', 'The Kingdom Power of Self Government', 'Online Quiz', 'Myles Munroe', 107, 11, '9.737', 'sefunmiadewunmiscores', '559.523');
INSERT INTO `sefunmiadewunmiscores` VALUES(54, '2017-03-19', 'Life 2', 'Online Quiz', 'Bishop David Oyedepo', 288, 11, '26.208', 'sefunmiadewunmiscores', '585.731');
INSERT INTO `sefunmiadewunmiscores` VALUES(55, '2017-03-26', 'Marriage Prep 101 (Birthday Mar 30)', 'Online Quiz', 'Myles Munroe', 1, 12, '0.091', 'sefunmiadewunmiscores', '585.822');
INSERT INTO `sefunmiadewunmiscores` VALUES(56, '2017-04-02', 'Salvation Testimony', 'Online Quiz', 'Kenneth Erwin Hagin', 132, 12, '10.992', 'sefunmiadewunmiscores', '596.814');
INSERT INTO `sefunmiadewunmiscores` VALUES(57, '2017-04-09', 'God\\''s Love (Love Series 3)', 'Online Quiz', 'Andrew Wommack', 190, 12, '15.834', 'sefunmiadewunmiscores', '612.648');
INSERT INTO `sefunmiadewunmiscores` VALUES(58, '2017-04-16', 'The Last Reformation(0:00-30:27)', 'Online Quiz', 'Akatio Films', 55, 12, '4.583', 'sefunmiadewunmiscores', '617.231');
INSERT INTO `sefunmiadewunmiscores` VALUES(59, '2017-04-23', 'The Power of Spiritual Depth', 'Online Quiz', 'Bishop David Oyedepo', 46, 12, '3.83', 'sefunmiadewunmiscores', '621.061');
INSERT INTO `sefunmiadewunmiscores` VALUES(60, '2017-04-28', 'The Last Reformation(30:27-The End)', 'Online Quiz', 'Akatio Films', 229, 12, '19.087', 'sefunmiadewunmiscores', '640.148');
INSERT INTO `sefunmiadewunmiscores` VALUES(61, '2017-05-05', 'The Principles of Creation', 'Online Quiz', 'Akatio Films', 431, 12, '35.941', 'sefunmiadewunmiscores', '676.089');
INSERT INTO `sefunmiadewunmiscores` VALUES(62, '2017-05-19', 'How to Walk in Confidence', 'Online Quiz', 'Myles Munroe', 431, 12, '35.939', 'sefunmiadewunmiscores', '712.028');

-- --------------------------------------------------------

--
-- Table structure for table `timilehinadeosunscores`
--

CREATE TABLE `timilehinadeosunscores` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `exercise` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `source` varchar(200) NOT NULL,
  `score` mediumint(9) NOT NULL,
  `currentage` mediumint(9) NOT NULL,
  `aggregate` varchar(200) NOT NULL,
  `tableName` varchar(50) NOT NULL DEFAULT 'timilehinadeosunscores',
  `currentTotalAggregate` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=83 ;

--
-- Dumping data for table `timilehinadeosunscores`
--

INSERT INTO `timilehinadeosunscores` VALUES(1, '2016-01-03', 'Eternal Life', 'Review', 'Andrew Wommack', 24, 13, '1.846', 'timilehinadeosunscores', '1.846');
INSERT INTO `timilehinadeosunscores` VALUES(2, '2016-01-10', 'Close Encounter of the God Kind', 'Review', 'Jesse Duplantis', 14, 13, '1.077', 'timilehinadeosunscores', '2.923');
INSERT INTO `timilehinadeosunscores` VALUES(3, '2016-01-31', 'Growing Up Spiritually', 'Review', 'Kenneth E Hagin', 11, 13, '0.846', 'timilehinadeosunscores', '3.769');
INSERT INTO `timilehinadeosunscores` VALUES(4, '2016-02-07', 'The Cost of a Crown', 'Quiz', 'Bishop David Oyedepo', 43, 13, '3.308', 'timilehinadeosunscores', '7.077');
INSERT INTO `timilehinadeosunscores` VALUES(5, '2016-02-14', 'The Love Walk', 'Review', 'Kenneth E Hagin', 34, 13, '2.615', 'timilehinadeosunscores', '9.692');
INSERT INTO `timilehinadeosunscores` VALUES(6, '2016-02-21', 'Opted for Group Discussion', 'Group Discussion', 'Youths', 0, 13, '0.000', 'timilehinadeosunscores', '9.692');
INSERT INTO `timilehinadeosunscores` VALUES(7, '2016-03-13', 'Repositioning for Exploits', 'Review ', 'Bishop David Oyedepo', 0, 13, '0.000', 'timilehinadeosunscores', '9.692');
INSERT INTO `timilehinadeosunscores` VALUES(8, '2016-03-27', '1John 4:4', 'Synonyms', 'Lanre Ibironke', 47, 13, '3.615', 'timilehinadeosunscores', '13.307');
INSERT INTO `timilehinadeosunscores` VALUES(9, '2016-04-03', 'Hand Sequence', 'Focus Test', 'Lanre Ibironke', 30, 13, '2.308', 'timilehinadeosunscores', '15.615');
INSERT INTO `timilehinadeosunscores` VALUES(10, '2016-04-10', 'Yesterday, Today and Tomorrow', 'Annotation and Silence Half Hour', 'Lanre Ibironke', 64, 13, '4.923', 'timilehinadeosunscores', '20.538');
INSERT INTO `timilehinadeosunscores` VALUES(11, '2016-04-17', 'Your Abilities', 'Annotation and Hand Sequence', 'Lanre Ibironke', 54, 13, '4.154', 'timilehinadeosunscores', '24.692');
INSERT INTO `timilehinadeosunscores` VALUES(12, '2016-04-24', 'Maximizing Your Most Valuable Asset', 'Home Work', 'Lanre Ibironke', 0, 13, '0.000', 'timilehinadeosunscores', '24.692');
INSERT INTO `timilehinadeosunscores` VALUES(13, '2016-05-01', 'Character Custodian of Destiny', 'Quiz', 'Bishop David Oyedepo', 49, 13, '3.769', 'timilehinadeosunscores', '28.461');
INSERT INTO `timilehinadeosunscores` VALUES(14, '2016-05-08', 'The Myth of Singleness', 'Questions', 'Dr Myles Munroe', 16, 13, '1.230', 'timilehinadeosunscores', '29.691');
INSERT INTO `timilehinadeosunscores` VALUES(15, '2016-05-15', 'Being Still (Psalms 46v10)', 'Chicken on Egg Scenario', 'Lanre Ibironke', 1, 13, '0.077', 'timilehinadeosunscores', '29.768');
INSERT INTO `timilehinadeosunscores` VALUES(16, '2016-05-22', 'Selecting the Most Appropriate Word Replacement', 'Quiz', 'Lanre Ibironke', 45, 13, '3.462', 'timilehinadeosunscores', '33.23');
INSERT INTO `timilehinadeosunscores` VALUES(21, '2016-05-29', 'Personalizing Scripture', 'Theory Question', 'Lanre Ibironke', 14, 13, '1.077', 'timilehinadeosunscores', '34.307');
INSERT INTO `timilehinadeosunscores` VALUES(22, '2016-06-05', 'Inner Counsel', 'Annotation', 'Lanre Ibironke', 55, 13, '4.231', 'timilehinadeosunscores', '38.538');
INSERT INTO `timilehinadeosunscores` VALUES(23, '2016-06-12', 'Bible Questions', 'General Quiz', 'Lanre Ibironke', 33, 13, '2.538', 'timilehinadeosunscores', '41.076');
INSERT INTO `timilehinadeosunscores` VALUES(24, '2016-06-19', 'Marathon Question', 'General Quiz 2', 'Lanre Ibironke', 64, 13, '4.923', 'timilehinadeosunscores', '45.999');
INSERT INTO `timilehinadeosunscores` VALUES(37, '2016-06-26', 'Uzziah''s Story', 'Annotation', 'Lanre Ibironke', 44, 13, '3.385', 'timilehinadeosunscores', '46.384');
INSERT INTO `timilehinadeosunscores` VALUES(38, '2016-07-03', 'Multiple Choice', 'General Quiz 3', 'Lanre Ibironke', 48, 13, '3.692', 'timilehinadeosunscores', '53.076');
INSERT INTO `timilehinadeosunscores` VALUES(39, '2016-07-10', '4-Cards', 'Bible Game', 'Lanre Ibironke', 42, 13, '3.231', 'timilehinadeosunscores', '56.307');
INSERT INTO `timilehinadeosunscores` VALUES(40, '2016-07-24', 'Memory Test', 'Theory Questions', 'Lanre Ibironke', 69, 13, '5.308', 'timilehinadeosunscores', '61.615');
INSERT INTO `timilehinadeosunscores` VALUES(41, '2016-07-31', 'Scripture Expansion', 'Presentation', 'Lanre Ibironke', 40, 14, '2.857', 'timilehinadeosunscores', '64.472');
INSERT INTO `timilehinadeosunscores` VALUES(42, '2016-08-07', 'Multiple Choice', 'General Quiz 4', 'Lanre Ibironke', 0, 14, '0', 'timilehinadeosunscores', '64.472');
INSERT INTO `timilehinadeosunscores` VALUES(43, '2016-08-14', 'Tower of Hanoi & Marriage', 'Puzzle & Annotation', 'Lanre Ibironke', 98, 14, '7', 'timilehinadeosunscores', '71.472');
INSERT INTO `timilehinadeosunscores` VALUES(47, '2016-08-21', 'The Innovative Demands of Leadership', 'Quiz 5', 'Myles Munroe', 26, 14, '1.857', 'timilehinadeosunscores', '73.329');
INSERT INTO `timilehinadeosunscores` VALUES(48, '2016-08-28', 'The Best Kept Secret', 'Quiz 6 & Annotation', 'Lanre Ibironke', 41, 14, '2.929', 'timilehinadeosunscores', '76.258');
INSERT INTO `timilehinadeosunscores` VALUES(49, '2016-09-04', 'Divine Secrets', 'Annotation', 'Lanre Ibironke', 73, 14, '5.214', 'timilehinadeosunscores', '81.472');
INSERT INTO `timilehinadeosunscores` VALUES(50, '2016-09-11', 'Repositioning for Exploits', 'Online Quiz', 'Bishop David Oyedepo', 40, 14, '2.858', 'timilehinadeosunscores', '84.33');
INSERT INTO `timilehinadeosunscores` VALUES(51, '2016-09-18', 'Kingdom Keys to Successful Relationships', 'Online Quiz', 'Myles Munroe', 330, 14, '23.574', 'timilehinadeosunscores', '107.904');
INSERT INTO `timilehinadeosunscores` VALUES(52, '2016-09-25', 'Heralding the Emergence of World Changers', 'Online Quiz', 'Bishop David Oyedepo', 564, 14, '40.212', 'timilehinadeosunscores', '148.116');
INSERT INTO `timilehinadeosunscores` VALUES(53, '2016-10-02', 'The Encounter', 'Online Quiz', 'Pure Flix Entertainment', 302, 14, '21.55', 'timilehinadeosunscores', '169.666');
INSERT INTO `timilehinadeosunscores` VALUES(54, '2016-10-09', 'The Ten Attitudes for Leadership Development', 'Online Quiz', 'Myles Munroe & David Oyedepo', 385, 14, '27.441', 'timilehinadeosunscores', '197.107');
INSERT INTO `timilehinadeosunscores` VALUES(55, '2016-10-16', 'What is Faith?', 'Online Quiz', 'David Oyedepo', 125, 14, '8.903', 'timilehinadeosunscores', '206.01');
INSERT INTO `timilehinadeosunscores` VALUES(56, '2016-10-23', 'The Media Mandate of the Kingdom', 'Online Quiz', 'Myles Munroe', 325, 14, '23.173', 'timilehinadeosunscores', '229.183');
INSERT INTO `timilehinadeosunscores` VALUES(57, '2016-10-30', 'Engaging the Armour of Light for Total Deliverance', 'Online Quiz', 'Bishop David Oyedepo', 331, 14, '23.605', 'timilehinadeosunscores', '252.788');
INSERT INTO `timilehinadeosunscores` VALUES(58, '2016-11-06', 'Vital Keys to Achieving Your Vision', 'Online Quiz', 'Myles Munroe', 408, 14, '29.092', 'timilehinadeosunscores', '281.88');
INSERT INTO `timilehinadeosunscores` VALUES(59, '2016-11-13', 'Engaging Violent Faith for Supernatural Turnaround', 'Online Quiz', 'Bishop David Oyedepo', 46, 14, '3.278', 'timilehinadeosunscores', '285.158');
INSERT INTO `timilehinadeosunscores` VALUES(62, '2016-11-27', 'How to Excel in Your Field', 'Online Quiz', 'Bishop David Oyedepo', 285, 14, '20.357', 'timilehinadeosunscores', '305.515');
INSERT INTO `timilehinadeosunscores` VALUES(64, '2016-12-11', 'The Stronghold of Faith', 'Online Quiz', 'Bishop David Oyedepo', 500, 14, '35.66', 'timilehinadeosunscores', '341.175');
INSERT INTO `timilehinadeosunscores` VALUES(65, '2016-12-25', 'How to Deal with Grief 2/4', 'Online Quiz', 'Andrew Wommack', 362, 14, '25.824', 'timilehinadeosunscores', '366.999');
INSERT INTO `timilehinadeosunscores` VALUES(66, '2017-01-08', 'Christmas Jubilee and Direction', 'Online Quiz', 'Myles Munroe', 359, 14, '25.597', 'timilehinadeosunscores', '392.596');
INSERT INTO `timilehinadeosunscores` VALUES(67, '2017-01-22', 'Eternal Life', 'Online Quiz', 'Andrew Wommack', 38, 14, '2.71', 'timilehinadeosunscores', '395.306');
INSERT INTO `timilehinadeosunscores` VALUES(68, '2017-01-29', 'The Holy Spirit', 'Online Quiz', 'Pastor E.A. Adeboye & Andrew Wommack', 242, 14, '17.258', 'timilehinadeosunscores', '412.564');
INSERT INTO `timilehinadeosunscores` VALUES(69, '2017-02-05', 'God''s Kind of Love To You', 'Online Quiz', 'Andrew Wommack', 300, 14, '21.388', 'timilehinadeosunscores', '433.952');
INSERT INTO `timilehinadeosunscores` VALUES(70, '2017-02-12', '7 Mistakes to avoid before marriage & End of the Harvest', 'Online Quiz', 'Pastor E.A. Adeboye & Christiano Film Group', 236, 14, '16.836', 'timilehinadeosunscores', '450.788');
INSERT INTO `timilehinadeosunscores` VALUES(71, '2017-02-19', 'Deepening your Relationship with God & 3 Types of Friends', 'Online Quiz', 'TD Jakes', 195, 14, '13.905', 'timilehinadeosunscores', '464.693');
INSERT INTO `timilehinadeosunscores` VALUES(72, '2017-03-05', 'Spirituality the Master Key to a World of Exploits', 'Online Quiz', 'Bishop David Oyedepo', 201, 14, '14.333', 'timilehinadeosunscores', '479.026');
INSERT INTO `timilehinadeosunscores` VALUES(73, '2017-03-19', 'Life 2', 'Online Quiz', 'Bishop David Oyedepo', 390, 14, '27.81', 'timilehinadeosunscores', '506.836');
INSERT INTO `timilehinadeosunscores` VALUES(74, '2017-03-26', 'Marriage Prep 101', 'Online Quiz', 'Myles Munroe', 694, 14, '49.506', 'timilehinadeosunscores', '556.342');
INSERT INTO `timilehinadeosunscores` VALUES(75, '2017-04-02', 'Salvation Testimony', 'Online Quiz', 'Kenneth Erwin Hagin', 67, 14, '4.781', 'timilehinadeosunscores', '561.123');
INSERT INTO `timilehinadeosunscores` VALUES(76, '2017-04-09', 'God\\''s Love (Love Series 3)', 'Online Quiz', 'Andrew Wommack', 546, 14, '38.926', 'timilehinadeosunscores', '600.049');
INSERT INTO `timilehinadeosunscores` VALUES(77, '2017-04-16', 'The Last Reformation 1(0:00-30:27)', 'Online Quiz', 'Akatio Films', 849, 14, '60.605', 'timilehinadeosunscores', '660.654');
INSERT INTO `timilehinadeosunscores` VALUES(78, '2017-04-23', 'The Power of Spiritual Depth', 'Online Quiz', 'Bishop David Oyedepo', 264, 14, '18.848', 'timilehinadeosunscores', '679.502');
INSERT INTO `timilehinadeosunscores` VALUES(79, '2017-04-28', 'The Last Reformation(30:27-The End)', 'Online Quiz', 'Akatio Films', 1451, 14, '103.589', 'timilehinadeosunscores', '783.091');
INSERT INTO `timilehinadeosunscores` VALUES(80, '2017-05-05', 'The Principles of Creation', 'Online Quiz', 'Myles Munroe', 767, 14, '54.729', 'timilehinadeosunscores', '837.82');
INSERT INTO `timilehinadeosunscores` VALUES(81, '2017-05-12', 'Drive Through History Holy Land 1', 'Online Quiz', 'Myles Munroe', 1099, 14, '78.465', 'timilehinadeosunscores', '916.285');
INSERT INTO `timilehinadeosunscores` VALUES(82, '2017-05-19', 'How to Walk in Confidence', 'Online Quiz', 'Myles Munroe', 798, 14, '56.926', 'timilehinadeosunscores', '973.211');

-- --------------------------------------------------------

--
-- Table structure for table `toluapetujescores`
--

CREATE TABLE `toluapetujescores` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `exercise` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `source` varchar(200) NOT NULL,
  `score` mediumint(9) NOT NULL,
  `currentage` mediumint(9) NOT NULL,
  `aggregate` varchar(200) NOT NULL,
  `tableName` varchar(50) NOT NULL DEFAULT 'toluapetujescores',
  `currentTotalAggregate` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=48 ;

--
-- Dumping data for table `toluapetujescores`
--

INSERT INTO `toluapetujescores` VALUES(1, '2016-01-03', 'Eternal Life', 'Review', 'Andrew Wommack', 0, 15, '0.000', 'toluapetujescores', '0');
INSERT INTO `toluapetujescores` VALUES(2, '2016-01-10', 'Close Encounter of the God Kind', 'Review', 'Jesse Duplantis', 0, 15, '0.000', 'toluapetujescores', '0');
INSERT INTO `toluapetujescores` VALUES(3, '2016-01-31', 'Growing Up Spiritually', 'Review', 'Kenneth E Hagin', 0, 15, '0.000', 'toluapetujescores', '0');
INSERT INTO `toluapetujescores` VALUES(4, '2016-02-07', 'The Cost of a Crown', 'Quiz', 'Bishop David Oyedepo', 0, 15, '0.000', 'toluapetujescores', '0');
INSERT INTO `toluapetujescores` VALUES(5, '2016-02-14', 'The Love Walk', 'Review', 'Kenneth E Hagin', 0, 15, '0.000', 'toluapetujescores', '0');
INSERT INTO `toluapetujescores` VALUES(6, '2016-02-21', 'Opted for Group Discussion', 'Group Discussion', 'Youth', 0, 15, '0.000', 'toluapetujescores', '0');
INSERT INTO `toluapetujescores` VALUES(7, '2016-03-13', 'Repositioning for Exploits', 'Review', 'Bishop David Oyedepo', 0, 15, '0.000', 'toluapetujescores', '0');
INSERT INTO `toluapetujescores` VALUES(8, '2016-03-27', '1John 4:4', 'Synonyms', 'Lanre Ibironke', 0, 15, '0.000', 'toluapetujescores', '0');
INSERT INTO `toluapetujescores` VALUES(9, '2016-04-03', 'Hand Sequence ', 'Focus Test', 'Lanre Ibironke', 52, 15, '3.467', 'toluapetujescores', '3.467');
INSERT INTO `toluapetujescores` VALUES(10, '2016-04-10', 'Yesterday, Today and Tomorrow', 'Annotation and Silence Half Hour', 'Lanre Ibironke', 0, 15, '0.000', 'toluapetujescores', '3.467');
INSERT INTO `toluapetujescores` VALUES(11, '2016-04-17', 'Your Abilities', 'Annotation and Hand Sequence', 'Lanre Ibironke', 0, 15, '0.000', 'toluapetujescores', '3.467');
INSERT INTO `toluapetujescores` VALUES(12, '2016-04-24', 'Maximizing Your Most Valuable Asset', 'Home Work', 'Lanre Ibironke', 0, 15, '0.000', 'toluapetujescores', '3.467');
INSERT INTO `toluapetujescores` VALUES(13, '2016-05-01', 'Character Custodian of Destiny', 'Quiz', 'Lanre Ibironke', 0, 15, '0.000', 'toluapetujescores', '3.467');
INSERT INTO `toluapetujescores` VALUES(14, '2016-05-08', 'The Myth of Singleness', 'Questions', 'Dr Myles Munroe', 0, 15, '0.000', 'toluapetujescores', '3.467');
INSERT INTO `toluapetujescores` VALUES(15, '2016-05-15', 'Being Still (Psalms 46vs10)', 'Chicken on Egg Scenario', 'Lanre Ibironke', 2, 15, '0.133', 'toluapetujescores', '3.6');
INSERT INTO `toluapetujescores` VALUES(16, '2016-05-22', 'Selecting the Most Appropriate Word Replacement', 'Quiz', 'Lanre Ibironke', 45, 15, '3.000', 'toluapetujescores', '6.6');
INSERT INTO `toluapetujescores` VALUES(17, '2016-05-29', 'Personalizing Scripture', 'Theory Question', 'Lanre Ibironke', 30, 15, '2', 'toluapetujescores', '8.6');
INSERT INTO `toluapetujescores` VALUES(18, '2016-06-05', 'Inner Counsel', 'Annotation', 'Lanre Ibironke', 35, 15, '2.333', 'toluapetujescores', '10.933');
INSERT INTO `toluapetujescores` VALUES(19, '2016-06-12', 'Bible Questions', 'General Quiz', 'Lanre Ibironke', 0, 15, '0', 'toluapetujescores', '10.933');
INSERT INTO `toluapetujescores` VALUES(20, '2016-06-19', 'Marathon Question', 'General Quiz 2', 'Lanre Ibironke', 0, 15, '0', 'toluapetujescores', '10.933');
INSERT INTO `toluapetujescores` VALUES(21, '2016-06-26', 'Uzziah''s Story', 'Annotation', 'Lanre Ibironke', 0, 15, '0', 'toluapetujescores', '10.933');
INSERT INTO `toluapetujescores` VALUES(22, '2016-07-03', 'Multiple Choice', 'General Quiz 3', 'Lanre Ibironke', 48, 15, '3.2', 'toluapetujescores', '14.133');
INSERT INTO `toluapetujescores` VALUES(23, '2016-07-10', '4-Cards', 'Bible Game', 'Lanre Ibironke', 11, 15, '0.733', 'toluapetujescores', '14.866');
INSERT INTO `toluapetujescores` VALUES(24, '2016-07-24', 'Memory Test', 'Theory Questions', 'Lanre Ibironke', 0, 15, '0', 'toluapetujescores', '14.866');
INSERT INTO `toluapetujescores` VALUES(25, '2016-07-31', 'Scripture Expansion', 'Presentation', 'Lanre Ibironke', 0, 15, '0', 'toluapetujescores', '14.866');
INSERT INTO `toluapetujescores` VALUES(26, '2016-08-07', 'Multiple Choice', 'General Quiz 4', 'Lanre Ibironke', 70, 15, '4.667', 'toluapetujescores', '19.533');
INSERT INTO `toluapetujescores` VALUES(27, '2016-08-14', 'Tower of Hanoi & Marriage', 'Puzzle  & Annotation', 'Lanre Ibironke', 0, 15, '0', 'toluapetujescores', '19.533');
INSERT INTO `toluapetujescores` VALUES(28, '2016-08-21', 'The Innovative Demands of Leadership', 'Quiz 5', 'Myles Munroe', 23, 15, '1.533', 'toluapetujescores', '21.066');
INSERT INTO `toluapetujescores` VALUES(29, '2016-08-28', 'The Best Kept Secret', 'Quiz 6 & Annotation', 'Lanre Ibironke', 20, 15, '1.333', 'toluapetujescores', '22.399');
INSERT INTO `toluapetujescores` VALUES(30, '2016-09-04', 'Divine Secrets', 'Annotation', 'Lanre Ibironke', 73, 15, '4.867', 'toluapetujescores', '27.266000000000002');
INSERT INTO `toluapetujescores` VALUES(31, '2016-09-11', 'Repositioning for Exploits', 'Online Quiz', 'Bishop David Oyedepo', 36, 15, '2.396', 'toluapetujescores', '29.662');
INSERT INTO `toluapetujescores` VALUES(32, '2016-10-02', 'The Encounter', 'Online Quiz', 'Pure Flix Entertainment', 171, 15, '11.415', 'toluapetujescores', '41.077');
INSERT INTO `toluapetujescores` VALUES(33, '2016-10-09', 'The Ten Attitudes for Leadership Development', 'Online Quiz', 'Myles Munroe & David Oyedepo', 290, 15, '19.354', 'toluapetujescores', '60.431');
INSERT INTO `toluapetujescores` VALUES(34, '2016-10-16', 'What is Faith?', 'Online Quiz', 'David Oyedepo', 173, 15, '11.539', 'toluapetujescores', '71.97');
INSERT INTO `toluapetujescores` VALUES(35, '2016-10-30', 'The Media Mandate of the Kingdom', 'Online Quiz', 'Myles Munroe', 235, 15, '15.689', 'toluapetujescores', '87.659');
INSERT INTO `toluapetujescores` VALUES(36, '2016-11-06', 'Engaging the Armour of Light for Total Deliverance', 'Online Quiz', 'David Oyedepo', 94, 15, '6.268', 'toluapetujescores', '93.927');
INSERT INTO `toluapetujescores` VALUES(37, '2016-11-27', 'How to Excel in Your Field', 'Online Quiz', 'Bishop David Oyedepo', 333, 15, '22.195', 'toluapetujescores', '116.122');
INSERT INTO `toluapetujescores` VALUES(38, '2016-12-11', 'The Stronghold of Faith', 'Online Quiz', 'Bishop David Oyedepo', 496, 16, '31', 'toluapetujescores', '147.122');
INSERT INTO `toluapetujescores` VALUES(39, '2016-12-25', 'How to Deal with Grief 2/4', 'Online Quiz', 'Andrew Wommack', 342, 16, '21.434', 'toluapetujescores', '168.556');
INSERT INTO `toluapetujescores` VALUES(40, '2017-01-08', 'Christmas Jubilee and Direction', 'Online Quiz', 'Myles Munroe', 395, 16, '24.759', 'toluapetujescores', '193.315');
INSERT INTO `toluapetujescores` VALUES(41, '2017-01-22', 'Eternal Life', 'Online Quiz', 'Andrew Wommack', 271, 16, '16.991', 'toluapetujescores', '210.306');
INSERT INTO `toluapetujescores` VALUES(42, '2017-02-19', 'Deepening your Relationship with God & 3 Types of Friends', 'Online Quiz', 'TD Jakes', 330, 16, '20.676', 'toluapetujescores', '230.982');
INSERT INTO `toluapetujescores` VALUES(43, '2017-03-05', 'Spirituality the Master Key to a World of Exploits', 'Online Quiz', 'Bishop David Oyedepo', 556, 16, '34.838', 'toluapetujescores', '265.82');
INSERT INTO `toluapetujescores` VALUES(44, '2017-03-12', 'The Kingdom Power of Self Government', 'Online Quiz', 'Myles Munroe', 564, 16, '35.34', 'toluapetujescores', '301.16');
INSERT INTO `toluapetujescores` VALUES(45, '2017-03-19', 'The Kingdom Power of Self Government', 'Online Quiz', 'Myles Munroe', 383, 16, '24.009', 'toluapetujescores', '325.169');
INSERT INTO `toluapetujescores` VALUES(46, '2017-04-02', 'Salvation Testimony', 'Online Quiz', 'Kenneth Erwin Hagin', 426, 16, '26.708', 'toluapetujescores', '351.877');
INSERT INTO `toluapetujescores` VALUES(47, '2017-04-16', 'The Last Reformation 1(0:00-30:27)', 'Online Quiz', 'Akatio Films', 5, 16, '0.313', 'toluapetujescores', '352.19');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `first` varchar(50) NOT NULL,
  `last` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` VALUES(1, 'Olanrewaju', 'Ibironke', 'brnkgabriel@gmail.com', '8765cd893e935dbd3460398bd39ab07882b75f50');

-- --------------------------------------------------------

--
-- Table structure for table `wadudadamuscores`
--

CREATE TABLE `wadudadamuscores` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `exercise` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `source` varchar(200) NOT NULL,
  `score` mediumint(9) NOT NULL,
  `currentage` mediumint(9) NOT NULL,
  `aggregate` varchar(200) NOT NULL,
  `tableName` varchar(50) NOT NULL DEFAULT 'wadudadamuscores',
  `currentTotalAggregate` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=51 ;

--
-- Dumping data for table `wadudadamuscores`
--

INSERT INTO `wadudadamuscores` VALUES(1, '2016-01-03', 'Eternal Life', 'Review', 'Andrew Wommack', 10, 13, '0.769', 'wadudadamuscores', '0.769');
INSERT INTO `wadudadamuscores` VALUES(2, '2016-01-10', 'Close Encounter of the God Kind', 'Review', 'Jesse Duplantis', 3, 13, '0.231', 'wadudadamuscores', '1');
INSERT INTO `wadudadamuscores` VALUES(3, '2016-01-31', 'Growing Up Spiritually', 'Review', 'Kenneth E Hagin', 0, 13, '0.000', 'wadudadamuscores', '1');
INSERT INTO `wadudadamuscores` VALUES(4, '2016-02-07', 'The Cost of a Crown', 'Quiz', 'Bishop David Oyedepo', 43, 13, '3.308', 'wadudadamuscores', '4.308');
INSERT INTO `wadudadamuscores` VALUES(5, '2016-02-14', 'The Love Walk', 'Review', 'Kenneth E Hagin', 18, 13, '1.385', 'wadudadamuscores', '5.693');
INSERT INTO `wadudadamuscores` VALUES(6, '2016-02-21', 'Opted for Group Discussion', 'Group Discussion', 'Youths', 0, 13, '0.000', 'wadudadamuscores', '5.693');
INSERT INTO `wadudadamuscores` VALUES(7, '2016-03-13', 'Repositioning for Exploits', 'Review', 'Bishop David Oyedepo', 6, 13, '0.461', 'wadudadamuscores', '6.154');
INSERT INTO `wadudadamuscores` VALUES(8, '2016-03-27', '1John 4:4', 'Synonyms', 'Lanre Ibironke', 8, 13, '0.615', 'wadudadamuscores', '6.769');
INSERT INTO `wadudadamuscores` VALUES(9, '2016-04-03', 'Hand Sequence', 'Focus Test', 'Lanre Ibironke', 28, 13, '2.154', 'wadudadamuscores', '8.923');
INSERT INTO `wadudadamuscores` VALUES(10, '2016-04-10', 'Yesterday, Today and Tomorrow', 'Annotation and Silence Half Hour', 'Lanre Ibironke', 54, 13, '4.154', 'wadudadamuscores', '13.077');
INSERT INTO `wadudadamuscores` VALUES(11, '2016-04-17', 'Your Abilities', 'Annotation and Hand Sequence', 'Lanre Ibironke', 18, 13, '1.385', 'wadudadamuscores', '14.462');
INSERT INTO `wadudadamuscores` VALUES(12, '2016-04-24', 'Maximizing Your Most Valuable Asset', 'Home Work', 'Lanre Ibironke', 0, 13, '0.000', 'wadudadamuscores', '14.462');
INSERT INTO `wadudadamuscores` VALUES(13, '2016-05-01', 'Character Custodian of Destiny', 'Quiz', 'Bishop David Oyedepo', 53, 13, '4.077', 'wadudadamuscores', '18.539');
INSERT INTO `wadudadamuscores` VALUES(14, '2016-05-08', 'The Myth of Singleness', 'Questions', 'Dr Myles Munroe', 0, 13, '0.000', 'wadudadamuscores', '18.539');
INSERT INTO `wadudadamuscores` VALUES(15, '2016-05-15', 'Being Still (Psalms 46vs10)', 'Chicken on Egg Scenario', 'Lanre Ibironke', 3, 13, '0.231', 'wadudadamuscores', '18.77');
INSERT INTO `wadudadamuscores` VALUES(16, '2016-05-22', 'Selecting the Most Appropriate Word Replacement', 'Quiz', 'Lanre Ibironke', 45, 13, '3.462', 'wadudadamuscores', '22.232');
INSERT INTO `wadudadamuscores` VALUES(17, '2016-05-29', 'Personalizing Scripture', 'Theory Question', 'Lanre Ibironke', 15, 13, '1.154', 'wadudadamuscores', '23.386');
INSERT INTO `wadudadamuscores` VALUES(18, '2016-06-05', 'Inner Counsel', 'Annotation', 'Lanre Ibironke', 0, 13, '0', 'wadudadamuscores', '23.386');
INSERT INTO `wadudadamuscores` VALUES(19, '2016-06-12', 'Bible Questions', 'General Quiz', 'Lanre Ibironke', 0, 13, '0', 'wadudadamuscores', '23.386');
INSERT INTO `wadudadamuscores` VALUES(20, '2016-06-19', 'Marathon Question', 'General Quiz 2', 'Lanre Ibironke', 0, 13, '0', 'wadudadamuscores', '23.386');
INSERT INTO `wadudadamuscores` VALUES(21, '2016-06-26', 'Uzziah''s Story', 'Annotation', 'Lanre Ibironke', 14, 13, '1.077', 'wadudadamuscores', '24.463');
INSERT INTO `wadudadamuscores` VALUES(22, '2016-07-03', 'Multiple Choice', 'General Quiz 3', 'Lanre Ibironke', 51, 13, '3.923', 'wadudadamuscores', '28.386');
INSERT INTO `wadudadamuscores` VALUES(23, '2016-07-10', '4-Cards', 'Bible Game', 'Lanre Ibironke', 0, 13, '0', 'wadudadamuscores', '28.386');
INSERT INTO `wadudadamuscores` VALUES(24, '2016-07-24', 'Memory Test', 'Theory Questions', 'Lanre Ibironke', 81, 13, '6.231', 'wadudadamuscores', '34.617');
INSERT INTO `wadudadamuscores` VALUES(25, '2016-07-31', 'Scripture Expansion', 'Presentation', 'Lanre Ibironke', 29, 14, '2.071', 'wadudadamuscores', '36.688');
INSERT INTO `wadudadamuscores` VALUES(26, '2016-08-07', 'Multiple Choice', 'General Quiz 4', 'Lanre Ibironke', 0, 14, '0', 'wadudadamuscores', '36.688');
INSERT INTO `wadudadamuscores` VALUES(27, '2016-08-14', 'Tower of Hanoi & Marriage', 'Puzzle  & Annotation', 'Lanre Ibironke', 0, 14, '0', 'wadudadamuscores', '36.688');
INSERT INTO `wadudadamuscores` VALUES(28, '2016-08-21', 'The Innovative Demands of Leadership', 'Quiz 5', 'Myles Munroe', 47, 14, '3.357', 'wadudadamuscores', '40.045');
INSERT INTO `wadudadamuscores` VALUES(29, '2016-08-28', 'The Best Kept Secret', 'Quiz 6 & Annotation', 'Lanre Ibironke', 26, 14, '1.857', 'wadudadamuscores', '41.902');
INSERT INTO `wadudadamuscores` VALUES(30, '2016-09-04', 'Divine Secrets', 'Annotation', 'Lanre Ibironke', 0, 14, '0', 'wadudadamuscores', '41.902');
INSERT INTO `wadudadamuscores` VALUES(31, '2016-09-11', 'Repositioning for Exploits', 'Online Quiz', 'Bishop David Oyedepo', 405, 14, '28.924', 'wadudadamuscores', '70.826');
INSERT INTO `wadudadamuscores` VALUES(33, '2016-09-18', 'Kingdom Keys to Successful Relationships', 'Online Quiz', 'Myles Munroe', 38, 14, '2.715', 'wadudadamuscores', '73.541');
INSERT INTO `wadudadamuscores` VALUES(34, '2016-09-25', 'Heralding the Emergence of World Changers', 'Online Quiz', 'Bishop David Oyedepo', 170, 14, '12.128', 'wadudadamuscores', '85.669');
INSERT INTO `wadudadamuscores` VALUES(35, '2016-10-02', 'The Encounter', 'Online Quiz', 'Pure Flix Entertainment', 51, 14, '3.637', 'wadudadamuscores', '89.306');
INSERT INTO `wadudadamuscores` VALUES(36, '2016-10-9', 'The Ten Attitudes for Leadership Development', 'Online Quiz', 'Myles Munroe & David Oyedepo', 261, 14, '18.643', 'wadudadamuscores', '107.949');
INSERT INTO `wadudadamuscores` VALUES(37, '2016-10-16', 'What is Faith?', 'Online Quiz', 'David Oyedepo', 181, 14, '12.907', 'wadudadamuscores', '120.856');
INSERT INTO `wadudadamuscores` VALUES(38, '2016-10-30', 'Engaging the Armour of Light for Total Deliverance', 'Online Quiz', 'David Oyedepo', 72, 14, '5.132', 'wadudadamuscores', '125.988');
INSERT INTO `wadudadamuscores` VALUES(39, '2016-11-06', 'Vital Keys to Achieving Your Vision', 'Online Quiz', 'Myles Munroe', 425, 14, '30.323', 'wadudadamuscores', '156.311');
INSERT INTO `wadudadamuscores` VALUES(40, '2016-11-13', 'Engaging Violent Faith for Supernatural Turnaround', 'Online Quiz', 'Bishop David Oyedepo', 264, 14, '18.836', 'wadudadamuscores', '175.147');
INSERT INTO `wadudadamuscores` VALUES(42, '2016-11-20', 'The Source of the Leadership Spirit', 'Online Quiz', 'Myles Munroe', 44, 14, '3.14', 'wadudadamuscores', '178.287');
INSERT INTO `wadudadamuscores` VALUES(43, '2016-11-27', 'How to Excel in Your Field', 'Online Quiz', 'Bishop David Oyedepo', 325, 14, '23.187', 'wadudadamuscores', '201.474');
INSERT INTO `wadudadamuscores` VALUES(44, '2017-02-12', 'God''s Kind of Love to You', 'Online Quiz', 'Andrew Wommack', 31, 14, '2.213', 'wadudadamuscores', '203.687');
INSERT INTO `wadudadamuscores` VALUES(45, '2017-02-19', 'Deepening your Relationship with God & 3 Types of Friends', 'Online Quiz', 'TD Jakes', 126, 14, '8.996', 'wadudadamuscores', '212.683');
INSERT INTO `wadudadamuscores` VALUES(46, '2017-02-26', 'Ultimate Myles Munroe 2016 Collection', 'Online Quiz', 'Myles Munroe', 185, 14, '13.207', 'wadudadamuscores', '225.89');
INSERT INTO `wadudadamuscores` VALUES(47, '2017-03-12', 'The Kingdom Power of Self Government', 'Online Quiz', 'Myles Munroe', 121, 14, '8.639', 'wadudadamuscores', '234.529');
INSERT INTO `wadudadamuscores` VALUES(48, '2017-03-19', 'Life 2', 'Online Quiz', 'Bishop David Oyedepo', 702, 14, '50.118', 'wadudadamuscores', '284.647');
INSERT INTO `wadudadamuscores` VALUES(49, '2017-03-26', 'Marriage Prep 101', 'Online Quiz', 'Myles Munroe', 234, 14, '16.706', 'wadudadamuscores', '301.353');
INSERT INTO `wadudadamuscores` VALUES(50, '2017-04-16', 'The Last Reformation 1(0:00-30:27)', 'Online Quiz', 'Akatio Films', 75, 14, '5.355', 'wadudadamuscores', '306.708');

-- --------------------------------------------------------

--
-- Table structure for table `worshipmaterials`
--

CREATE TABLE `worshipmaterials` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `type` varchar(50) NOT NULL,
  `author` varchar(50) NOT NULL,
  `link` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `worshipmaterials`
--


-- --------------------------------------------------------

--
-- Table structure for table `worshipquestions`
--

CREATE TABLE `worshipquestions` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `question` varchar(1000) NOT NULL,
  `type` varchar(50) NOT NULL,
  `options` varchar(300) NOT NULL,
  `answers` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=556 ;

--
-- Dumping data for table `worshipquestions`
--

INSERT INTO `worshipquestions` VALUES(541, 'Before the _______ knew its foundation', 'Single Answer', 'earth,world', 'earth');
INSERT INTO `worshipquestions` VALUES(542, 'You spoke the _______ into creation', 'Single Answer', 'earth,dust', 'dust');
INSERT INTO `worshipquestions` VALUES(543, 'Until the end, when all is _____', 'Single Answer', 'gone,withered,vanished', 'withered');
INSERT INTO `worshipquestions` VALUES(544, 'Then still Your word, will _______ forever', 'Single Answer', 'endure,last,remain', 'endure');
INSERT INTO `worshipquestions` VALUES(545, 'The ______ unto my feet', 'Single Answer', 'lamp,light', 'lamp');
INSERT INTO `worshipquestions` VALUES(546, 'The ______ unto my path', 'Single Answer', 'lamp,light', 'light');
INSERT INTO `worshipquestions` VALUES(547, 'Your Word, will not be _______', 'Single Answer', 'moved,shaken,tottered', 'shaken');
INSERT INTO `worshipquestions` VALUES(548, 'Your Word, will never _______ me', 'Single Answer', 'abandon,disappoint,fail', 'fail');
INSERT INTO `worshipquestions` VALUES(549, 'Like a ______ in my bones', 'Single Answer', 'fire,flame', 'fire');
INSERT INTO `worshipquestions` VALUES(550, 'Like a ________ to my soul', 'Single Answer', 'whisper,word,voice', 'whisper');
INSERT INTO `worshipquestions` VALUES(551, 'Your word, is ______', 'Single Answer', 'insight,revelation,light', 'revelation');
INSERT INTO `worshipquestions` VALUES(552, '_____ calls to _____, within Your Presence', 'Single Answer', 'depth,deep', 'deep');
INSERT INTO `worshipquestions` VALUES(553, 'When I hear You speak, my soul ______', 'Single Answer', 'revives,awakens', 'awakens');
INSERT INTO `worshipquestions` VALUES(554, 'Your Spirit leads, my ______ to worship', 'Single Answer', 'spirit,heart,soul', 'heart');
INSERT INTO `worshipquestions` VALUES(555, 'As Your Word reveals, the _______ of Jesus', 'Single Answer', 'love,grace,light', 'light');
