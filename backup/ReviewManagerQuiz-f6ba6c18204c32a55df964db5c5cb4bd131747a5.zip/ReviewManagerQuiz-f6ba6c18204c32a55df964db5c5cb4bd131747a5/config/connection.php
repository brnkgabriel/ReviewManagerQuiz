<?php

# Database Connection Here...
$dbc = mysqli_connect('localhost', 'lanre', '58995331', 'reviewmanager') OR die('Could not connect because: '.mysqli_connect_error());

?>