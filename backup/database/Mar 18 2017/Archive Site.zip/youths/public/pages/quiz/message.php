<div class="panel-group" id="accordion"> 
	<div class="panel panel-default">
		<div class="panel-heading">
			<h4 class="panel-title"> 
				<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
					<strong>[Attitude]</strong> Actions by Paula White
				</a>
			</h4>
		</div>
		<div id="collapseOne" class="panel-collapse collapse">
			<div class="panel-body">
				<p><iframe width="560" height="315" src="https://www.youtube.com/embed/0hIcT1GQZns" frameborder="0" allowfullscreen></iframe></p>
			</div>
		</div>
	</div>
	<div class="panel panel-default">
		<div class="panel-heading">
			<h4 class="panel-title">
				<a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
					<strong>[Career]</strong> Repositioning for Exploits by Bishop David Oyedepo
				</a>
			</h4>
		</div>
		<div id="collapseTwo" class="panel-collapse collapse">
			<div class="panel-body">
				<p><iframe width="560" height="315" src="https://www.youtube.com/embed/V6i395WNbAA?list=PLFzgN2iKn8bT6SP4MGQ7FHDkT4s_Fj3Qp" frameborder="0" allowfullscreen></iframe></p>
			</div>
		</div>
	</div>
	<div class="panel panel-default">
		<div class="panel-heading">
			<h4 class="panel-title">
				<a data-toggle="collapse" data-parent="#accordion" href="#collapseThree">
					<strong>[Relationship]</strong> Single Again by Myles Munroe
				</a>
			</h4>
		</div>
		<div id="collapseThree" class="panel-collapse collapse">
			<div class="panel-body">
				<p><iframe width="560" height="315" src="https://www.youtube.com/embed/6Frru5jFo6A?list=PLFzgN2iKn8bT6SP4MGQ7FHDkT4s_Fj3Qp" frameborder="0" allowfullscreen></iframe></p>
			</div>
		</div>
	</div>
</div>