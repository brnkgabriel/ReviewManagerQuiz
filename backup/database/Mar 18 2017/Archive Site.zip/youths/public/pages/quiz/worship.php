<p>Title: <strong>Sing to The Lord</strong></p>
<p>By: <strong>Marty Sampson</strong></p>
<p>Location: <strong>Hillsong Church Australia</strong></p>
<p><iframe width="420" height="315" src="https://www.youtube.com/embed/ICwUyLK54vE" frameborder="0" allowfullscreen></iframe></p>