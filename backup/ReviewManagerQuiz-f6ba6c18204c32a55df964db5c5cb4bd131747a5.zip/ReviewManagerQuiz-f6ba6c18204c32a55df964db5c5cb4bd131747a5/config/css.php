<?php
// CSS File: 
	

?>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="resources/bootstrap.min.css" rel="stylesheet">

<!-- Optional theme -->
<link rel="stylesheet" href="resources/bootstrap-theme.min.css">

<!-- jQuery CSS -->
<link rel="stylesheet" href="resources/jquery-ui.css">

<!-- Font Awesome -->
<link rel="stylesheet" href="resources/font-awesome.min.css"> 

<style> 
	#wrap{
		font-family: Ubuntu;
	}
</style>