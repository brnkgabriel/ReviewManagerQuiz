<?php
# Database Connection Here...
$dbc = mysqli_connect('hpmyouths.db.13963234.hostedresource.com', 'hpmyouths', 'DagunduroYouths5899!!!', 'hpmyouths') OR die('Could not connect because: '.mysqli_connect_error());
?>