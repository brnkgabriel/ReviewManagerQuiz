<p>This portion is for typing the bible</p>
<p>
	It will consist a paragraph tag and a text area. The paragraph will show the next verse to be typed.
	The text area is where the student should type the shown verse. Once the verse is
	typed completely. The text area clears and the paragraph tag shows the next verse to be typed
</p>
<textarea class="form-control">
	
</textarea>